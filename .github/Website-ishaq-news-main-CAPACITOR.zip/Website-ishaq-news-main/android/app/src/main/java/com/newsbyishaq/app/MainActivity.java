package com.newsbyishaq.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
