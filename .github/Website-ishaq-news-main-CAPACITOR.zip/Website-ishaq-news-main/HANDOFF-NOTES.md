# Handoff: Capacitor Android wrapper for "News By Ishaq"

Give this file + the zip to the next AI/tool. It explains exactly what's
already done and what's left.

## Goal
Convert the existing React/Vite site (Firebase Auth/Firestore/Storage,
Vercel Analytics, custom hash-based router, admin + article features) into
an installable Android app via Capacitor — **without rebuilding/redesigning
the site or removing any existing functionality.**

## Environment note
This was done in a sandbox with **no network access**, so `npm install`,
`npx cap add android`, and any Gradle/npm commands could not actually be
run or verified. Everything below was hand-authored/checked by reading the
source — it has not been build-tested. Whoever continues should run
`npm install` locally (with network) as the very first step.

## What's already done in this zip
- `package.json` — added `@capacitor/core`, `@capacitor/android`,
  `@capacitor/cli`, `@capacitor/app`, `@capacitor/keyboard`,
  `@capacitor/splash-screen`, `@capacitor/status-bar`, plus scripts
  `android:sync`, `android:open`, `android:run`, `android:build`,
  `android:build:release`. All original scripts/deps untouched.
- `capacitor.config.ts` — appId `com.newsbyishaq.app`, appName
  `News By Ishaq`, `webDir: 'dist'`, `androidScheme: 'https'`.
- `src/capacitor/nativeIntegration.ts` — new file, native-only (guarded by
  `Capacitor.isNativePlatform()`), so it's a no-op on the web/Vercel build.
  Sets status bar color, hides the native splash screen, and maps the
  Android back button to `window.history.back()` (reuses the app's
  existing `pushState` + `hashchange` router in `src/App.tsx` — did not
  touch that router logic itself).
- `src/main.tsx` — one added import + one function call to wire up the
  above on startup. No other lines changed.
- Full hand-built `android/` Gradle project: root `build.gradle`,
  `settings.gradle`, `capacitor.settings.gradle`, `variables.gradle`,
  `gradle.properties`, `app/build.gradle`, `app/capacitor.build.gradle`,
  `app/proguard-rules.pro`, `app/src/main/AndroidManifest.xml` (INTERNET +
  ACCESS_NETWORK_STATE permissions), `MainActivity.java` (plain
  `BridgeActivity`, no custom native code), `res/values/{strings,colors,
  styles}.xml`, `res/xml/file_paths.xml`, generated launcher icons (all
  mipmap densities, square + round, dark-slate/cyan brand look) and a
  splash screen image, and `gradlew` / `gradlew.bat` wrapper scripts
  (syntax-checked with `sh -n`, executable bit set).
- `.gitignore` updated (root + new `android/.gitignore`) for Android build
  artifacts, keystores, `google-services.json`, etc.

## Second pass (this handoff) — what changed
Done in another no-network sandbox, so still build-unverified, but a full
static read-through was done and one real bug was fixed:

- **Native Google Sign-In implemented** (previously just flagged). On
  native platforms, `signInWithGoogle()` in `src/context/AuthContext.tsx`
  now uses `@capacitor-firebase/authentication`'s native Google Sign-In
  sheet, exchanges the ID token via `GoogleAuthProvider.credential()` +
  `signInWithCredential()`, and hands off to the exact same
  profile/Firestore logic as before. Web behavior (`signInWithPopup`) is
  untouched. Added the plugin to `package.json` and its config block to
  `capacitor.config.ts`.
- **Fixed a real gap in `android/build.gradle`**: `app/build.gradle`
  conditionally applies `com.google.gms.google-services`, but the
  `com.google.gms:google-services` classpath was never declared in the
  root `buildscript`, so that plugin would have failed to apply even
  with a `google-services.json` present. Added the classpath.
- Read through the rest of `src/` (App.tsx router, all components,
  services) — no other correctness issues found relevant to the
  Capacitor/Android wrapper.
- Noted, not fixed (pre-existing, unrelated to this migration): in
  `AuthContext.tsx`'s Firestore-direct login fallback, a `foundProfile`
  object is built as `{ uid: snap.docs[0].id, ...docData }` — since
  `docData` is spread *after* the explicit `uid`, if a document's stored
  `uid` field ever differs from its actual Firestore doc ID, the doc ID
  gets silently discarded. Harmless if they always match; worth a look.

## What's still missing / must be done next
1. **`android/gradle/wrapper/gradle-wrapper.jar` is still missing.** Same
   as before — needs network or a local Gradle/Android Studio to
   generate. Pick one:
   - Run `gradle wrapper --gradle-version 8.11.1` from inside `android/`
     using any locally installed Gradle, or
   - Open the `android/` folder in Android Studio — it will offer to
     regenerate the wrapper — or
   - Run `npx cap sync android` after `npm install` on a machine with
     network access.
2. **Nothing has actually been built yet.** Standard next steps:
   ```
   npm install
   npm run build
   npx cap sync android
   npx cap open android      # or open android/ manually in Android Studio
   ```
   Then build/run from Android Studio, or `cd android && ./gradlew assembleDebug`.
3. **`google-services.json` must be added to `android/app/`** for the new
   native Google Sign-In to work — download it from the Firebase console
   for this project (package name `com.newsbyishaq.app`) and register the
   app's debug + release SHA-1/SHA-256 fingerprints there, or Google
   Sign-In will fail on device even though the code path is now correct.
4. **Release signing isn't configured.** `assembleRelease` will currently
   produce an unsigned APK. Configure a signing config in
   `android/app/build.gradle` + a keystore, or use Android Studio's
   "Generate Signed Bundle / APK" wizard.
5. **App icon is a placeholder** (programmatically generated dark
   slate/cyan "N" monogram) — swap for real branding if available.
6. Sanity-check `npm run build` / `tsc --noEmit` actually pass — still
   not verifiable without network/`node_modules`.

## Files worth reading first
- `capacitor.config.ts`
- `package.json` (scripts + new deps)
- `src/capacitor/nativeIntegration.ts` and the two added lines in
  `src/main.tsx`
- `android/app/build.gradle` and `android/app/src/main/AndroidManifest.xml`
- `src/context/AuthContext.tsx` (for the Google Sign-In caveat above)
