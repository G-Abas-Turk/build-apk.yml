import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  increment,
  onSnapshot,
} from 'firebase/firestore';
import { db } from '../firebase';
import { Article, CategoryItem, SiteSettings, UserProfile, FeedPost, FeedComment } from '../types';
import { SEED_ARTICLES } from '../data/seedArticles';

export const DEFAULT_CATEGORIES: CategoryItem[] = [
  { id: 'cat-sindh', slug: 'sindh', name: 'Sindh', description: 'Grassroots affairs, agrarian transformations, and provincial heritage', order: 1 },
  { id: 'cat-pakistan', slug: 'pakistan', name: 'Pakistan', description: 'National policy, federal governance, economic reforms, and judicial analysis', order: 2 },
  { id: 'cat-geopolitics', slug: 'geopolitics', name: 'Geopolitics', description: 'Indian Ocean corridors, multilateral diplomacy, and defense strategies', order: 3 },
  { id: 'cat-world', slug: 'world', name: 'World', description: 'Global developments, bilateral statecraft, and international commerce', order: 4 },
  { id: 'cat-technology', slug: 'technology', name: 'Technology', description: 'Artificial intelligence, semiconductors, digital infrastructure, and future policy', order: 5 },
  { id: 'cat-opinion', slug: 'opinion', name: 'Opinion', description: 'Analytical commentary, longform essays, and intellectual perspectives', order: 6 },
];

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  siteName: 'NEWS BY ISHAQ',
  siteDescription: 'Independent, deeply reported journalism, regional investigations, and global geopolitical analysis.',
  announcement: 'Welcome to the new live Firebase-powered News By Ishaq platform.',
  announcementActive: true,
  heroNotice: 'Published from Masu Bhurgari, Sindh · Grounded Independent Journalism',
  contactEmail: 'ishaqturk91@gmail.com',
};

class FirebaseDataService {
  private seeded = false;

  /**
   * Initializes default categories, settings, and seed articles if Firestore is empty
   */
  async initializeDefaultsIfEmpty(): Promise<void> {
    if (this.seeded) return;
    try {
      // 1. Check categories
      const catSnap = await getDocs(collection(db, 'categories'));
      if (catSnap.empty) {
        for (const cat of DEFAULT_CATEGORIES) {
          await setDoc(doc(db, 'categories', cat.id), {
            ...cat,
            createdAt: new Date().toISOString(),
          });
        }
      }

      // 2. Check site settings
      const settingsRef = doc(db, 'siteSettings', 'global');
      const settingsSnap = await getDoc(settingsRef);
      if (!settingsSnap.exists()) {
        await setDoc(settingsRef, {
          ...DEFAULT_SITE_SETTINGS,
          updatedAt: new Date().toISOString(),
        });
      }

      // 3. Check articles
      const artSnap = await getDocs(query(collection(db, 'articles'), limit(1)));
      if (artSnap.empty) {
        for (const art of SEED_ARTICLES) {
          const articleDoc: Article = {
            ...art,
            authorId: 'founder-ishaq-turk',
            authorEmail: 'ishaqturk91@gmail.com',
            createdAt: art.publishedAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            status: 'published',
            views: Math.floor(Math.random() * 800) + 120,
          };
          await setDoc(doc(db, 'articles', art.id), articleDoc);
        }
      }

      this.seeded = true;
    } catch (err) {
      console.warn('Firebase initialization notice:', err);
    }
  }

  // ==========================================
  // ARTICLES QUERIES
  // ==========================================

  async getPublishedArticles(): Promise<Article[]> {
    await this.initializeDefaultsIfEmpty();
    try {
      const q = query(
        collection(db, 'articles'),
        where('status', '==', 'published')
      );
      const snapshot = await getDocs(q);
      const list: Article[] = [];
      snapshot.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as Article);
      });

      // Sort in memory by publishedAt descending to avoid composite index build requirements
      return list.sort((a, b) => {
        const da = new Date(a.publishedAt || a.createdAt).getTime();
        const dbTime = new Date(b.publishedAt || b.createdAt).getTime();
        return dbTime - da;
      });
    } catch (err) {
      console.error('Error fetching published articles:', err);
      return SEED_ARTICLES.map((a) => ({
        ...a,
        authorId: 'founder-ishaq-turk',
        authorEmail: 'ishaqturk91@gmail.com',
        createdAt: a.publishedAt || new Date().toISOString(),
        views: 240,
      }));
    }
  }

  async getArticleBySlug(slug: string): Promise<Article | null> {
    try {
      const q = query(collection(db, 'articles'), where('slug', '==', slug), limit(1));
      const snap = await getDocs(q);
      if (!snap.empty) {
        const d = snap.docs[0];
        // Increment view count asynchronously
        try {
          await updateDoc(doc(db, 'articles', d.id), {
            views: increment(1),
          });
        } catch {
          // ignore view increment error
        }
        return { id: d.id, ...d.data() } as Article;
      }

      // Check by ID if slug not found
      const direct = await getDoc(doc(db, 'articles', slug));
      if (direct.exists()) {
        return { id: direct.id, ...direct.data() } as Article;
      }
      return null;
    } catch (err) {
      console.error('Error getting article by slug:', err);
      const fallback = SEED_ARTICLES.find((a) => a.slug === slug || a.id === slug);
      return fallback ? ({ ...fallback, authorId: 'founder-ishaq-turk', createdAt: fallback.publishedAt } as Article) : null;
    }
  }

  async getAllArticlesForAdmin(): Promise<Article[]> {
    try {
      const snapshot = await getDocs(collection(db, 'articles'));
      const list: Article[] = [];
      snapshot.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as Article);
      });
      return list.sort((a, b) => {
        const da = new Date(a.updatedAt || a.createdAt).getTime();
        const dbTime = new Date(b.updatedAt || b.createdAt).getTime();
        return dbTime - da;
      });
    } catch (err) {
      console.error('Error getting all articles for admin:', err);
      return [];
    }
  }

  async getUserSubmissions(userId: string): Promise<Article[]> {
    try {
      const q = query(
        collection(db, 'articles'),
        where('authorId', '==', userId)
      );
      const snapshot = await getDocs(q);
      const list: Article[] = [];
      snapshot.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as Article);
      });
      return list.sort((a, b) => {
        const da = new Date(a.createdAt).getTime();
        const dbTime = new Date(b.createdAt).getTime();
        return dbTime - da;
      });
    } catch (err) {
      console.error('Error getting user submissions:', err);
      return [];
    }
  }

  // ==========================================
  // ARTICLE MUTATIONS
  // ==========================================

  async createArticle(data: Omit<Article, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const newDocRef = doc(collection(db, 'articles'));
    const now = new Date().toISOString();

    const newArticle: Article = {
      ...data,
      id: newDocRef.id,
      slug: data.slug || this.slugify(data.title),
      createdAt: now,
      updatedAt: now,
      publishedAt: data.status === 'published' ? (data.publishedAt || now) : undefined,
      views: 0,
    };

    await setDoc(newDocRef, newArticle);
    return newDocRef.id;
  }

  async updateArticle(articleId: string, updates: Partial<Article>): Promise<void> {
    const artRef = doc(db, 'articles', articleId);
    const cleanUpdates: Record<string, any> = {
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    if (updates.status === 'published' && !updates.publishedAt) {
      cleanUpdates.publishedAt = new Date().toISOString();
    }

    await updateDoc(artRef, cleanUpdates);
  }

  async deleteArticle(articleId: string): Promise<void> {
    await deleteDoc(doc(db, 'articles', articleId));
  }

  async approveArticle(articleId: string): Promise<void> {
    await this.updateArticle(articleId, {
      status: 'published',
      publishedAt: new Date().toISOString(),
      rejectionReason: '',
    });
  }

  async rejectArticle(articleId: string, reason: string): Promise<void> {
    await this.updateArticle(articleId, {
      status: 'rejected',
      rejectionReason: reason || 'Does not meet editorial guidelines at this time.',
    });
  }

  // ==========================================
  // CATEGORIES
  // ==========================================

  async getCategories(): Promise<CategoryItem[]> {
    await this.initializeDefaultsIfEmpty();
    try {
      const snap = await getDocs(collection(db, 'categories'));
      if (snap.empty) return DEFAULT_CATEGORIES;
      const list: CategoryItem[] = [];
      snap.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as CategoryItem);
      });
      return list.sort((a, b) => (a.order || 0) - (b.order || 0));
    } catch {
      return DEFAULT_CATEGORIES;
    }
  }

  async createCategory(cat: Omit<CategoryItem, 'id' | 'createdAt'>): Promise<string> {
    const newRef = doc(collection(db, 'categories'));
    await setDoc(newRef, {
      ...cat,
      id: newRef.id,
      slug: this.slugify(cat.slug || cat.name),
      createdAt: new Date().toISOString(),
    });
    return newRef.id;
  }

  async updateCategory(id: string, updates: Partial<CategoryItem>): Promise<void> {
    await updateDoc(doc(db, 'categories', id), updates);
  }

  async deleteCategory(id: string, slug: string): Promise<void> {
    // Check if any articles use this category
    const q = query(collection(db, 'articles'), where('category', '==', slug), limit(1));
    const snap = await getDocs(q);
    if (!snap.empty) {
      throw new Error(`Cannot delete category "${slug}" because articles are currently filed under it. Reassign or delete those articles first.`);
    }
    await deleteDoc(doc(db, 'categories', id));
  }

  // ==========================================
  // USERS MANAGEMENT
  // ==========================================

  async getAllUsers(): Promise<UserProfile[]> {
    try {
      const snap = await getDocs(collection(db, 'users'));
      const list: UserProfile[] = [];
      snap.forEach((d) => {
        list.push({ uid: d.id, ...d.data() } as UserProfile);
      });
      return list;
    } catch (err) {
      console.error('Error fetching users:', err);
      return [];
    }
  }

  async updateUserRole(uid: string, role: 'user' | 'admin'): Promise<void> {
    await updateDoc(doc(db, 'users', uid), {
      role,
      updatedAt: new Date().toISOString(),
    });
  }

  /**
   * Realtime listener for registered users
   */
  subscribeToUsers(callback: (users: UserProfile[]) => void): () => void {
    const unsub = onSnapshot(collection(db, 'users'), (snap) => {
      const list: UserProfile[] = [];
      snap.forEach((d) => {
        list.push({ uid: d.id, ...d.data() } as UserProfile);
      });
      // Sort newest users first
      list.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
      callback(list);
    }, (err) => {
      console.warn('Realtime users listener error:', err);
    });
    return unsub;
  }

  /**
   * Admin verified blue tick toggle
   */
  async toggleVerifiedBadge(uid: string, isVerified: boolean): Promise<void> {
    await updateDoc(doc(db, 'users', uid), {
      isVerified,
      updatedAt: new Date().toISOString(),
    });
  }

  /**
   * Fetches all items uploaded by a specific user (articles and feed posts)
   */
  async getUserUploads(authorId: string): Promise<{ articles: Article[]; posts: FeedPost[]; totalUploads: number }> {
    try {
      const [artSnap, postSnap] = await Promise.all([
        getDocs(query(collection(db, 'articles'), where('authorId', '==', authorId))),
        getDocs(query(collection(db, 'feedPosts'), where('authorId', '==', authorId))),
      ]);

      const articles: Article[] = [];
      artSnap.forEach((d) => articles.push({ id: d.id, ...d.data() } as Article));

      const posts: FeedPost[] = [];
      postSnap.forEach((d) => posts.push({ id: d.id, ...d.data() } as FeedPost));

      return {
        articles,
        posts,
        totalUploads: articles.length + posts.length,
      };
    } catch (err) {
      console.error('Error fetching user uploads:', err);
      return { articles: [], posts: [], totalUploads: 0 };
    }
  }

  // ==========================================
  // REALTIME FACEBOOK-STYLE NEWS FEED & SINDH INCIDENTS
  // ==========================================

  private feedSeeded = false;

  async seedSindhiFeedPostsIfEmpty(): Promise<void> {
    if (this.feedSeeded) return;
    try {
      const snap = await getDocs(query(collection(db, 'feedPosts'), limit(1)));
      if (snap.empty) {
        const seedPosts: Array<Omit<FeedPost, 'id'>> = [
          {
            content: "سکر بئراج ۽ گڊو بئراج وٽ سنڌو درياءَ جي مٿئين حصي مان ايندڙ پاڻي جي وهڪرن بابت آبپاشي اختيارين پاران تازو بليٽن جاري ڪيو ويو آهي. دادو، لاڙڪاڻي، روهڙي ۽ فيض گنج ڪئنالن ۾ پاڻي جي بحالي بعد آبادگارن اطمينان جو اظهار ڪيو آهي. آبپاشي کاتي پاران پاڻي جي منصفاڻي ورهاست يقيني بنائڻ لاءِ ڪنٽرول روم 24 ڪلاڪ فعال رکڻ جو فيصلو ڪيو ويو آهي.",
            category: 'sindh',
            postType: 'incident',
            language: 'sd',
            location: 'سکر بئراج، سنڌ',
            imageUrl: '/assets/images/sindh_culture_heritage_1790362792202.jpg',
            authorId: 'founder-ishaq-turk',
            authorName: 'اسحاق ترڪ (Ishaq Turk)',
            authorRole: 'Founder & Editor-in-Chief',
            authorAvatar: '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
            isVerified: true,
            likesCount: 38,
            likedBy: [],
            commentsCount: 4,
            sharesCount: 12,
            comments: [
              {
                id: 'c1',
                authorId: 'reader_sd1',
                authorName: 'بشير احمد چانڊيو',
                content: 'سنڌ جي زراعت لاءِ درياءَ جو پاڻي زندگي آهي، آبپاشي کاتي کي سخت مانيٽرنگ جاري رکڻ گھرجي.',
                createdAt: new Date(Date.now() - 3600000).toISOString(),
              }
            ],
            createdAt: new Date(Date.now() - 7200000).toISOString(),
          },
          {
            content: "نوري آباد ويجهو ايم نائن (M-9) ڪراچي کان حيدرآباد موٽر وي تي مٽي ۽ تيز هوائن سبب ٿيندڙ ٽريفڪ حادثي بعد موٽر وي پوليس ۽ سنڌ ايمرجنسي ريسڪيو 1122 ٽيمن بروقت امدادي ڪارروائي ڪندي روڊ کي مڪمل طور بحال ڪري ڇڏيو آهي. مسافرن کي موسم صاف ٿيڻ تائين محتاط ڊرائيونگ ۽ فاصلو برقرار رکڻ جي هدايت ڪئي وئي آهي.",
            category: 'sindh',
            postType: 'incident',
            language: 'sd',
            location: 'نوري آباد، ايم نائن موٽر وي سنڌ',
            imageUrl: '/assets/images/hero_geopolitics_summit_1790362774883.jpg',
            authorId: 'founder-ishaq-turk',
            authorName: 'اسحاق ترڪ (Ishaq Turk)',
            authorRole: 'Founder & Editor-in-Chief',
            authorAvatar: '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
            isVerified: true,
            likesCount: 29,
            likedBy: [],
            commentsCount: 2,
            sharesCount: 7,
            comments: [],
            createdAt: new Date(Date.now() - 14400000).toISOString(),
          },
          {
            content: "سنڌ حڪومت جي ثقافت کاتي پاران يونيسڪو (UNESCO) سان سهڪار ڪندي پنج هزار سال پراڻي تاريخي ماڳ موهن جو دڙو (Mohenjo-daro) کي برساتن ۽ موسمي تبديلين جي اثرن کان بچائڻ لاءِ جديد ليزر ڊجيٽل دستاويزي اسڪيننگ جي شروعات ڪئي آهي. مقامي ماهرن ۽ بين الاقوامي آرڪيالاجي ٽيمن ساراهه ڪندي چيو آهي ته موهن جو دڙو سڄي دنيا جي تمدن جو فخر آهي.",
            category: 'sindh',
            postType: 'news',
            language: 'sd',
            location: 'موهن جو دڙو، لاڙڪاڻو سنڌ',
            imageUrl: '/assets/images/sindh_culture_heritage_1790362792202.jpg',
            authorId: 'founder-ishaq-turk',
            authorName: 'اسحاق ترڪ (Ishaq Turk)',
            authorRole: 'Founder & Editor-in-Chief',
            authorAvatar: '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
            isVerified: true,
            likesCount: 54,
            likedBy: [],
            commentsCount: 6,
            sharesCount: 19,
            comments: [],
            createdAt: new Date(Date.now() - 28800000).toISOString(),
          },
          {
            content: "Breaking Ground Report: Semiconductor supply chain negotiations in East Asia reach a decisive phase. Major maritime shipping routes through the Strait of Malacca face renewed strategic positioning as regional navies expand surveillance patrols.",
            category: 'technology',
            postType: 'breaking',
            language: 'en',
            location: 'Singapore & Malacca Strait',
            imageUrl: '/assets/images/tech_semiconductor_ai_1790362808002.jpg',
            authorId: 'founder-ishaq-turk',
            authorName: 'Ishaq Turk',
            authorRole: 'Founder & Editor-in-Chief',
            authorAvatar: '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
            isVerified: true,
            likesCount: 42,
            likedBy: [],
            commentsCount: 3,
            sharesCount: 15,
            comments: [],
            createdAt: new Date(Date.now() - 36000000).toISOString(),
          },
          {
            content: "ٿرپارڪر ۾ مٺي، ڏيپلو ۽ ننگرپارڪر جي ڏورانهن ڳوٺن ۾ پيئڻ جي صاف پاڻي جي کوٽ کي منهن ڏيڻ لاءِ 50 نوان شمسي توانائي (Solar Energy) تي هلندڙ واٽر فلٽريشن آر او پلانٽس فعال ڪيا ويا آهن، جنهن سان مقامي آبادي کي رليف مليو آهي.",
            category: 'sindh',
            postType: 'news',
            language: 'sd',
            location: 'مٺي ۽ ننگرپارڪر، ٿرپارڪر',
            authorId: 'founder-ishaq-turk',
            authorName: 'اسحاق ترڪ (Ishaq Turk)',
            authorRole: 'Founder & Editor-in-Chief',
            authorAvatar: '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
            isVerified: true,
            likesCount: 67,
            likedBy: [],
            commentsCount: 5,
            sharesCount: 21,
            comments: [],
            createdAt: new Date(Date.now() - 50000000).toISOString(),
          }
        ];

        for (const post of seedPosts) {
          const docRef = doc(collection(db, 'feedPosts'));
          await setDoc(docRef, { ...post, id: docRef.id });
        }
      }
      this.feedSeeded = true;
    } catch (err) {
      console.warn('Seed feed posts notice:', err);
    }
  }

  async getFeedPosts(): Promise<FeedPost[]> {
    await this.seedSindhiFeedPostsIfEmpty();
    try {
      const snap = await getDocs(collection(db, 'feedPosts'));
      const list: FeedPost[] = [];
      snap.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as FeedPost);
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      return list;
    } catch (err) {
      console.error('Error fetching feed posts:', err);
      return [];
    }
  }

  subscribeToFeedPosts(callback: (posts: FeedPost[]) => void): () => void {
    this.seedSindhiFeedPostsIfEmpty();
    const unsub = onSnapshot(collection(db, 'feedPosts'), (snap) => {
      const list: FeedPost[] = [];
      snap.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as FeedPost);
      });
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      callback(list);
    }, (err) => {
      console.warn('Realtime feed posts listener warning:', err);
    });
    return unsub;
  }

  async createFeedPost(post: Omit<FeedPost, 'id' | 'likesCount' | 'commentsCount' | 'sharesCount' | 'createdAt'>): Promise<string> {
    const docRef = doc(collection(db, 'feedPosts'));
    const newPost: FeedPost = {
      ...post,
      id: docRef.id,
      likesCount: 0,
      likedBy: [],
      commentsCount: 0,
      comments: [],
      sharesCount: 0,
      createdAt: new Date().toISOString(),
    };
    await setDoc(docRef, newPost);

    // Update user postsCount in Firestore
    if (post.authorId) {
      try {
        await updateDoc(doc(db, 'users', post.authorId), {
          postsCount: increment(1),
          updatedAt: new Date().toISOString(),
        });
      } catch {
        // ignore if doc missing
      }
    }

    return docRef.id;
  }

  async likeFeedPost(postId: string, userId: string): Promise<{ likesCount: number; isLiked: boolean }> {
    const postRef = doc(db, 'feedPosts', postId);
    const snap = await getDoc(postRef);
    if (!snap.exists()) throw new Error('Post not found');

    const data = snap.data() as FeedPost;
    const likedBy = data.likedBy || [];
    const isAlreadyLiked = likedBy.includes(userId);

    let newLikedBy: string[];
    let newLikesCount: number;

    if (isAlreadyLiked) {
      newLikedBy = likedBy.filter((id) => id !== userId);
      newLikesCount = Math.max(0, (data.likesCount || 1) - 1);
    } else {
      newLikedBy = [...likedBy, userId];
      newLikesCount = (data.likesCount || 0) + 1;
    }

    await updateDoc(postRef, {
      likedBy: newLikedBy,
      likesCount: newLikesCount,
    });

    return { likesCount: newLikesCount, isLiked: !isAlreadyLiked };
  }

  async addFeedComment(postId: string, commentData: Omit<FeedComment, 'id' | 'createdAt'>): Promise<FeedComment> {
    const postRef = doc(db, 'feedPosts', postId);
    const snap = await getDoc(postRef);
    if (!snap.exists()) throw new Error('Post not found');

    const data = snap.data() as FeedPost;
    const existingComments = data.comments || [];

    const newComment: FeedComment = {
      ...commentData,
      id: `c_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toISOString(),
    };

    const updatedComments = [...existingComments, newComment];

    await updateDoc(postRef, {
      comments: updatedComments,
      commentsCount: updatedComments.length,
    });

    return newComment;
  }

  async deleteFeedPost(postId: string): Promise<void> {
    await deleteDoc(doc(db, 'feedPosts', postId));
  }

  // ==========================================
  // SITE SETTINGS & ANNOUNCEMENTS
  // ==========================================

  async getSiteSettings(): Promise<SiteSettings> {
    try {
      const snap = await getDoc(doc(db, 'siteSettings', 'global'));
      if (snap.exists()) {
        return snap.data() as SiteSettings;
      }
      return DEFAULT_SITE_SETTINGS;
    } catch {
      return DEFAULT_SITE_SETTINGS;
    }
  }

  async updateSiteSettings(settings: Partial<SiteSettings>): Promise<void> {
    await setDoc(
      doc(db, 'siteSettings', 'global'),
      {
        ...settings,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  }

  private slugify(text: string): string {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }
}

export const firebaseData = new FirebaseDataService();
