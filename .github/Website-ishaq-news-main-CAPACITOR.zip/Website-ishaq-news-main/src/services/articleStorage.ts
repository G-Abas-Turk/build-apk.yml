import { Article, Category, ArticleType } from '../types';
import { SEED_ARTICLES } from '../data/seedArticles';

const STORAGE_KEY = 'news_by_ishaq_articles_v3';
const ADMIN_AUTH_KEY = 'news_by_ishaq_admin_auth';

class ArticleStorageService {
  private articles: Article[] = [];
  private listeners: Array<() => void> = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.articles = parsed;
          return;
        }
      }
    } catch (e) {
      console.error('Failed to load articles from localStorage', e);
    }
    // Default to seed articles
    this.articles = [...SEED_ARTICLES];
    this.saveToStorage();
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.articles));
    } catch (e) {
      console.error('Failed to write articles to localStorage', e);
    }
    this.notify();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify(): void {
    this.listeners.forEach(l => l());
  }

  public calculateReadTime(text: string): string {
    const words = text.trim().split(/\s+/).length;
    const minutes = Math.max(1, Math.ceil(words / 200));
    return `${minutes} min read`;
  }

  public generateSlug(title: string): string {
    return title
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  // Public View: ONLY published articles
  public getPublishedArticles(): Article[] {
    return this.articles.filter(a => a.status === 'published');
  }

  // Admin View: ALL articles including drafts
  public getAllArticles(): Article[] {
    return [...this.articles];
  }

  public getArticleBySlug(slug: string, includeDrafts = false): Article | undefined {
    return this.articles.find(a => a.slug === slug && (includeDrafts || a.status === 'published'));
  }

  public getArticleById(id: string): Article | undefined {
    return this.articles.find(a => a.id === id);
  }

  public getArticlesByCategory(category: Category, includeDrafts = false): Article[] {
    return this.articles.filter(
      a => a.category === category && (includeDrafts || a.status === 'published')
    );
  }

  public getFeaturedArticle(): Article | undefined {
    const published = this.getPublishedArticles();
    return published.find(a => a.isFeatured) || published[0];
  }

  public getTrendingArticles(): Article[] {
    const published = this.getPublishedArticles();
    const trending = published.filter(a => a.isTrending);
    if (trending.length > 0) {
      return trending.sort((a, b) => (a.trendingRank || 99) - (b.trendingRank || 99)).slice(0, 5);
    }
    return published.slice(0, 5);
  }

  public searchArticles(query: string, categoryFilter?: string, includeDrafts = false): Article[] {
    const q = query.trim().toLowerCase();
    const base = includeDrafts ? this.articles : this.getPublishedArticles();
    
    return base.filter(a => {
      if (categoryFilter && categoryFilter !== 'all' && a.category !== categoryFilter) {
        return false;
      }
      if (!q) return true;
      return (
        a.title.toLowerCase().includes(q) ||
        a.subtitle?.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q) ||
        a.content.toLowerCase().includes(q) ||
        a.tags.some(tag => tag.toLowerCase().includes(q))
      );
    });
  }

  public saveArticle(input: Partial<Article> & { title: string; category: Category; content: string }): Article {
    const isNew = !input.id;
    const now = new Date().toISOString();
    const slug = input.slug || this.generateSlug(input.title);
    const readTime = this.calculateReadTime(input.content);

    if (isNew) {
      const newArticle: Article = {
        id: `art-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        slug: this.ensureUniqueSlug(slug),
        title: input.title.trim(),
        subtitle: input.subtitle?.trim() || '',
        summary: input.summary?.trim() || input.content.slice(0, 160) + '...',
        content: input.content,
        category: input.category,
        type: input.type || 'news',
        author: input.author?.trim() || 'Ishaq Turk',
        authorRole: input.authorRole || 'Founder & Editor',
        authorAvatar: input.authorAvatar || '/src/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
        publishedAt: input.publishedAt || now,
        readTime,
        imageUrl: input.imageUrl || '/src/assets/images/hero_geopolitics_summit_1790362774883.jpg',
        imageCaption: input.imageCaption || '',
        sources: input.sources || [],
        tags: input.tags || [input.category],
        status: input.status || 'published',
        isFeatured: !!input.isFeatured,
        isTrending: !!input.isTrending,
        trendingRank: input.trendingRank || 99,
        isSample: false
      };

      if (newArticle.isFeatured) {
        // Unfeature other articles
        this.articles.forEach(a => { a.isFeatured = false; });
      }

      this.articles.unshift(newArticle);
      this.saveToStorage();
      return newArticle;
    } else {
      const index = this.articles.findIndex(a => a.id === input.id);
      if (index === -1) {
        throw new Error('Article not found to update');
      }

      const existing = this.articles[index];
      const updatedArticle: Article = {
        ...existing,
        ...input,
        updatedAt: now,
        readTime: input.content ? this.calculateReadTime(input.content) : existing.readTime,
        slug: input.title && input.title !== existing.title ? this.generateSlug(input.title) : existing.slug
      };

      if (updatedArticle.isFeatured) {
        this.articles.forEach(a => {
          if (a.id !== updatedArticle.id) a.isFeatured = false;
        });
      }

      this.articles[index] = updatedArticle;
      this.saveToStorage();
      return updatedArticle;
    }
  }

  private ensureUniqueSlug(slug: string, currentId?: string): string {
    let candidate = slug;
    let counter = 1;
    while (this.articles.some(a => a.slug === candidate && a.id !== currentId)) {
      candidate = `${slug}-${counter}`;
      counter++;
    }
    return candidate;
  }

  public deleteArticle(id: string): boolean {
    const initialLength = this.articles.length;
    this.articles = this.articles.filter(a => a.id !== id);
    if (this.articles.length !== initialLength) {
      this.saveToStorage();
      return true;
    }
    return false;
  }

  public togglePublishStatus(id: string): Article | null {
    const article = this.articles.find(a => a.id === id);
    if (!article) return null;
    article.status = article.status === 'published' ? 'draft' : 'published';
    article.updatedAt = new Date().toISOString();
    this.saveToStorage();
    return article;
  }

  public exportArticlesJSON(): string {
    return JSON.stringify(this.articles, null, 2);
  }

  public importArticlesJSON(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (Array.isArray(parsed) && parsed.length > 0) {
        this.articles = parsed;
        this.saveToStorage();
        return true;
      }
    } catch (e) {
      console.error('Failed to import JSON', e);
    }
    return false;
  }

  public resetToDefaults(): void {
    this.articles = [...SEED_ARTICLES];
    this.saveToStorage();
  }

  // Admin authentication state helper
  public isAdminAuthenticated(): boolean {
    return localStorage.getItem(ADMIN_AUTH_KEY) === 'true';
  }

  public loginAdmin(password: string): boolean {
    // Default master pass key is 'ishaq2026' or custom set
    const customPass = localStorage.getItem('news_by_ishaq_admin_pass') || 'ishaq2026';
    if (password === customPass) {
      localStorage.setItem(ADMIN_AUTH_KEY, 'true');
      return true;
    }
    return false;
  }

  public logoutAdmin(): void {
    localStorage.removeItem(ADMIN_AUTH_KEY);
  }

  public updateAdminPassword(newPassword: string): void {
    localStorage.setItem('news_by_ishaq_admin_pass', newPassword);
  }
}

export const articleStorage = new ArticleStorageService();
