import { Capacitor } from '@capacitor/core';

/**
 * Native-shell-only integration hooks for the Android app.
 *
 * Everything in this file is guarded by Capacitor.isNativePlatform(), so it
 * is a strict no-op on the existing web build (Vercel). It does not alter
 * any existing component, route, or Firebase logic — it only wires up
 * Android-specific chrome (status bar color, native splash screen, and the
 * hardware/gesture back button) on top of the app's existing hash router.
 */
export async function initNativeIntegration(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;

  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    await StatusBar.setBackgroundColor({ color: '#020617' });
    await StatusBar.setStyle({ style: Style.Dark });
  } catch {
    // Status bar plugin unavailable — safe to ignore.
  }

  try {
    const { SplashScreen } = await import('@capacitor/splash-screen');
    window.setTimeout(() => {
      SplashScreen.hide().catch(() => {});
    }, 300);
  } catch {
    // Splash screen plugin unavailable — safe to ignore.
  }

  try {
    const { App } = await import('@capacitor/app');
    App.addListener('backButton', ({ canGoBack }) => {
      // The app already tracks navigation via window.history.pushState +
      // 'hashchange' (see src/App.tsx). Reusing history.back() keeps that
      // existing routing logic as the single source of truth.
      if (canGoBack && window.history.length > 1) {
        window.history.back();
      } else {
        App.exitApp();
      }
    });
  } catch {
    // App plugin unavailable — safe to ignore.
  }
}
