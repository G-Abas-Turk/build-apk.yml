import React from 'react';
import { ViewRoute } from '../types';
import { Terminal, ArrowUp, Share2, Mail } from 'lucide-react';

interface FooterProps {
  onNavigate: (route: ViewRoute) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="mt-20 border-t border-[#d4af37]/15 bg-[#0c0d0e] text-[#8c887e] text-sm">
      {/* Editorial Distinction Banner */}
      <div className="border-b border-[#292723] bg-gradient-to-r from-[#1c1a16] via-[#121210] to-[#1a1815] py-5 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-[#d4af37] animate-pulse" />
            <span className="text-xs uppercase font-bold tracking-wider text-[#e6e2d8]">
              Editorial Integrity Standards
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-xs text-[#cfcac0]">
            <div>
              <strong className="text-[#d4af37] uppercase mr-1.5 font-bold">NEWS:</strong>
              <span>Factual reporting and verifiable sourcing</span>
            </div>
            <div>
              <strong className="text-[#e5c46b] uppercase mr-1.5 font-bold">ANALYSIS:</strong>
              <span>Context, structure, and strategic explanation</span>
            </div>
            <div>
              <strong className="text-[#cfc39f] uppercase mr-1.5 font-bold">OPINION:</strong>
              <span>Perspectives, essays, and reflective commentary</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Col 1 & 2: Brand Identity */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <img
                src="/assets/images/ishaq_turk_suit_exact_1790364183317.jpg"
                alt="Ishaq Turk"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-[#d4af37]/50 shadow"
              />
              <span className="text-xl font-black tracking-tight text-white font-display uppercase">
                NEWS BY ISHAQ
              </span>
            </div>

            <p className="text-[#cfcac0] text-sm leading-relaxed max-w-sm font-editorial">
              "News, geopolitics, ideas and stories."
            </p>

            <p className="text-xs text-[#8c887e] leading-relaxed max-w-sm">
              An independent digital news publication founded by Ishaq Turk from Masu Bhurgari, Sindh. Dedicated to in-depth coverage of Sindh, Pakistan, global affairs, technology, and international strategy.
            </p>

            <div className="pt-2 flex items-center gap-3 text-[#8c887e]">
              <a
                href="https://x.com"
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg bg-[#1a1918] hover:text-[#d4af37] hover:bg-[#252320] transition-colors border border-[#292723]"
                title="Follow on X"
              >
                <Share2 className="w-4 h-4" />
              </a>
              <button
                onClick={() => onNavigate({ type: 'contact' })}
                className="p-2 rounded-lg bg-[#1a1918] hover:text-[#d4af37] hover:bg-[#252320] transition-colors border border-[#292723] cursor-pointer"
                title="Email Desk"
              >
                <Mail className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Col 3: Desks / Subjects */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-display">
              Subjects & Desks
            </h3>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigate({ type: 'category', category: 'sindh' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Sindh News & Culture
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'category', category: 'pakistan' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Pakistan National Affairs
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'category', category: 'geopolitics' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Geopolitics & Strategy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'category', category: 'world' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  World & Global Affairs
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'category', category: 'technology' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Technology & Sovereign Silicon
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'category', category: 'opinion' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Opinion & Perspectives
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Publication & Founder */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-display">
              About & Ethics
            </h3>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigate({ type: 'about' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  About Ishaq Turk
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'about' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Publication Mission
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'contact' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Contact & Corrections
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'privacy' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate({ type: 'terms' })}
                  className="hover:text-[#f5e6b3] transition-colors cursor-pointer"
                >
                  Terms of Service
                </button>
              </li>
            </ul>
          </div>

          {/* Col 5: Independent Portal */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-display">
              Publisher Desk
            </h3>
            <p className="text-xs text-[#8c887e] mb-3 leading-relaxed">
              Real-time independent journalism powered by Cloud Firestore.
            </p>
            <div className="space-y-2">
              <button
                onClick={() => onNavigate({ type: 'submit-article' })}
                className="inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold text-[#d4af37] bg-[#1a1918] hover:bg-[#252320] border border-[#d4af37]/30 rounded-lg transition-colors w-full justify-center cursor-pointer"
              >
                <span>Submit an Article</span>
              </button>
              <button
                onClick={() => onNavigate({ type: 'admin-login' })}
                className="inline-flex items-center gap-2 px-3 py-2 text-xs font-bold text-[#0c0d0e] bg-gradient-to-r from-[#d4af37] to-[#b38820] hover:brightness-110 rounded-lg transition-colors w-full justify-center cursor-pointer shadow-md shadow-[#d4af37]/15"
              >
                <span>Editorial Admin Login</span>
                <Terminal className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="mt-4 text-[11px] text-[#706c62]">
              Domain: <span className="text-[#d4af37]">newsbyishaq.com</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar with Back to Top */}
        <div className="pt-8 border-t border-[#232220] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#706c62]">
          <div>
            © 2026 News By Ishaq. All rights reserved. Founded & curated by Ishaq Turk.
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-[#a09a8e] hover:text-[#f5e6b3] transition-colors py-1 px-2.5 rounded hover:bg-[#1a1918] cursor-pointer"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
