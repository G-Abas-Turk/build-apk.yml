import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ViewRoute } from '../types';
import { Mail, Lock, User, ArrowRight, AlertCircle, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface RegisterViewProps {
  onNavigate: (route: ViewRoute) => void;
}

export const RegisterView: React.FC<RegisterViewProps> = ({ onNavigate }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { registerWithEmail, signInWithGoogle, setGuestDismissed } = useAuth();
  const { addToast } = useToast();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Please provide your full name.');
      return;
    }
    if (!email.trim()) {
      setError('Please enter your email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    try {
      setLoading(true);
      const res = await registerWithEmail(name.trim(), email.trim(), password);
      setGuestDismissed(true);

      addToast({
        type: 'success',
        title: 'Account Created & Verified',
        message: `Welcome to News By Ishaq, ${res.profile.name}! Your account has been registered in Cloud Firestore.`,
      });

      onNavigate({ type: 'home' });
    } catch (err: unknown) {
      const fbErr = err as { code?: string; message?: string };
      let msg = 'Failed to create account. Please check your details.';
      if (fbErr.code === 'auth/email-already-in-use') {
        msg = 'An account with this email address already exists. Please log in instead.';
      } else if (fbErr.code === 'auth/invalid-email') {
        msg = 'The email address format is invalid.';
      } else if (fbErr.code === 'auth/weak-password') {
        msg = 'Password is too weak. Please use at least 6 characters.';
      } else if (fbErr.message) {
        msg = fbErr.message;
      }
      setError(msg);
      addToast({ type: 'error', title: 'Registration Notice', message: msg });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignUp = async () => {
    try {
      setGoogleLoading(true);
      setError(null);
      const profile = await signInWithGoogle();
      setGuestDismissed(true);
      addToast({
        type: 'success',
        title: 'Google Sign-In Successful',
        message: `Welcome back, ${profile.name}!`,
      });
      onNavigate({ type: 'home' });
    } catch (err: any) {
      console.warn('Google sign-in error:', err);
      if (err?.code !== 'auth/popup-closed-by-user') {
        setError(err?.message || 'Google Sign-In failed.');
      }
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Header Icon / Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center mb-4">
            <img
              src="/assets/images/ishaq_turk_suit_exact_1790364183317.jpg"
              alt="Ishaq Turk"
              className="w-14 h-14 rounded-full object-cover ring-2 ring-amber-500/50 shadow-md shadow-amber-950/20"
            />
          </div>
          <p className="text-[10px] tracking-[0.25em] font-serif uppercase text-amber-600 dark:text-amber-400 font-bold mb-1">
            Official Reader Registration
          </p>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-slate-900 dark:text-[#f4efe6]">
            Join News By Ishaq
          </h1>
          <p className="text-xs text-slate-600 dark:text-[#a39e93] mt-2">
            Participate in news discussions, real-time dispatches, and receive verified contributor privileges.
          </p>
        </div>

        {/* Card */}
        <div className="bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723] rounded-2xl p-6 sm:p-8 shadow-xl backdrop-blur-md">
          {error && (
            <div className="mb-6 p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 flex items-start gap-3 text-red-700 dark:text-red-300 text-xs leading-relaxed animate-fadeIn">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* 1-Click Google Sign-In */}
          <button
            type="button"
            onClick={handleGoogleSignUp}
            disabled={googleLoading}
            className="w-full mb-5 py-2.5 px-4 bg-white dark:bg-[#1b1c1e] hover:bg-slate-50 dark:hover:bg-[#232428] border border-slate-300 dark:border-[#33312c] text-slate-800 dark:text-[#f4efe6] rounded-xl font-medium text-xs shadow-sm transition-all flex items-center justify-center gap-3 cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>{googleLoading ? 'Connecting Google Account...' : 'Continue with Google'}</span>
          </button>

          <div className="relative flex items-center justify-center my-4">
            <div className="border-t border-slate-200 dark:border-[#2a2723] w-full" />
            <span className="bg-white dark:bg-[#141517] px-3 text-[11px] uppercase tracking-wider text-slate-400 font-serif">
              or register with email
            </span>
            <div className="border-t border-slate-200 dark:border-[#2a2723] w-full" />
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-[#c4beaf] mb-1.5 font-serif uppercase tracking-wider">
                Full Name
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Tariq Mehmood"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#0c0d0e] border border-slate-300 dark:border-[#2a2723] rounded-xl text-sm text-slate-900 dark:text-[#f4efe6] placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all font-sans"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-[#c4beaf] mb-1.5 font-serif uppercase tracking-wider">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="reader@example.com"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#0c0d0e] border border-slate-300 dark:border-[#2a2723] rounded-xl text-sm text-slate-900 dark:text-[#f4efe6] placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all font-sans"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-[#c4beaf] mb-1.5 font-serif uppercase tracking-wider">
                Password (min 6 characters)
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#0c0d0e] border border-slate-300 dark:border-[#2a2723] rounded-xl text-sm text-slate-900 dark:text-[#f4efe6] placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all font-sans"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-[#c4beaf] mb-1.5 font-serif uppercase tracking-wider">
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#0c0d0e] border border-slate-300 dark:border-[#2a2723] rounded-xl text-sm text-slate-900 dark:text-[#f4efe6] placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all font-sans"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all transform active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-stone-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Create Account</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Direct Firestore Sync Assurance */}
          <div className="mt-4 p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 flex items-center gap-2 text-[11px] text-emerald-800 dark:text-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Direct Real-Time Firestore Sync · Your data persists securely across sessions.</span>
          </div>

          {/* Guest Action */}
          <div className="mt-5 pt-5 border-t border-slate-200 dark:border-[#22211e]">
            <button
              type="button"
              onClick={() => {
                setGuestDismissed(true);
                onNavigate({ type: 'home' });
              }}
              className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-[#1b1c1e] dark:hover:bg-[#222428] border border-slate-300 dark:border-[#2e2b26] text-xs font-medium text-slate-700 dark:text-[#c4beaf] hover:text-slate-900 dark:hover:text-[#f4efe6] rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-amber-500" />
              <span>Browse Without Registering</span>
            </button>
          </div>
        </div>

        {/* Footer Links */}
        <div className="mt-6 text-center">
          <p className="text-xs text-slate-600 dark:text-[#8c867a]">
            Already have an account?{' '}
            <button
              onClick={() => onNavigate({ type: 'login' })}
              className="text-amber-600 dark:text-amber-400 hover:underline font-semibold transition-colors cursor-pointer"
            >
              Sign In
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
