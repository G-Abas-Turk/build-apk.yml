import React from 'react';
import { ViewRoute } from '../types';
import { BookOpen, MapPin, CheckCircle2, Mail, ArrowRight, Quote } from 'lucide-react';

interface AboutViewProps {
  onNavigate: (route: ViewRoute) => void;
}

export const AboutView: React.FC<AboutViewProps> = ({ onNavigate }) => {
  const ishaqPortrait = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="mb-12 text-center">
        <span className="text-[11px] font-serif uppercase tracking-[0.25em] text-amber-400 font-bold mb-2 block">
          The Independent Voice & Editorial Charter
        </span>
        <h1 className="text-4xl sm:text-5xl font-serif font-bold text-[#f4efe6] tracking-tight mb-4">
          About Ishaq Turk
        </h1>
        <div className="w-16 h-0.5 bg-gradient-to-r from-amber-500/20 via-amber-400 to-amber-500/20 mx-auto" />
      </div>

      {/* Founder Profile Card */}
      <div className="mb-14 p-6 sm:p-10 rounded-2xl bg-[#141517] border border-[#2a2723] shadow-2xl flex flex-col md:flex-row items-center md:items-start gap-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative shrink-0">
          <div className="w-44 h-44 sm:w-52 sm:h-52 rounded-2xl overflow-hidden ring-2 ring-amber-400/60 shadow-2xl shadow-amber-950/40 bg-[#0c0d0e]">
            <img
              src={ishaqPortrait}
              alt="Ishaq Turk"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-[#1b1c1e] text-amber-300 border border-amber-500/40 text-[10px] font-serif uppercase tracking-widest px-3 py-1 rounded-full whitespace-nowrap shadow-lg">
            Founder & Editor
          </div>
        </div>

        <div className="flex-1 text-center md:text-left">
          <div className="inline-flex items-center gap-1.5 text-xs font-serif text-amber-400 mb-2">
            <MapPin className="w-3.5 h-3.5" />
            <span>Masu Bhurgari, Sindh, Pakistan</span>
          </div>

          <h2 className="text-3xl font-serif font-bold text-[#f4efe6] mb-1">
            Ishaq Turk
          </h2>
          <div className="text-xs font-serif uppercase tracking-wider text-[#a39e93] mb-6">
            Founder · Investigative Journalist · Independent Publisher
          </div>

          <div className="space-y-4 text-sm sm:text-base text-[#d8d3c7] leading-relaxed">
            <div className="p-5 rounded-xl bg-[#0e0f11] border border-[#2e2a24] italic font-serif text-[#ebe5d8] text-base sm:text-lg relative">
              <Quote className="w-6 h-6 text-amber-400/30 mb-1" />
              "My name is Ishaq Turk. I come from a village called Masu Bhurgari in Sindh, Pakistan.
              I've always been passionate about geopolitics, world affairs, current events, discussions, ideas, and understanding what is unfolding across the globe."
            </div>

            <p className="font-serif text-[#c4beaf] leading-relaxed">
              "News By Ishaq is my personal platform where I explore Sindh, Pakistan, global affairs, geopolitics, technology, opinions, and substantive discussions without corporate editorial filter."
            </p>

            <p className="font-serif text-[#a39e93] leading-relaxed">
              "This publication exists to share stories, perspectives, and verifiable truths that matter to the region and the wider world."
            </p>
          </div>
        </div>
      </div>

      {/* Editorial Identity & Charter */}
      <section className="mb-14 space-y-6">
        <div className="border-b border-[#2a2723] pb-3">
          <h2 className="text-2xl font-serif font-bold text-[#f4efe6] tracking-tight flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <span>Publication Charter</span>
          </h2>
        </div>

        <div className="text-sm sm:text-base text-[#c4beaf] space-y-4 leading-relaxed font-serif">
          <p>
            <strong className="text-[#f4efe6]">News By Ishaq</strong> is an independent digital news and geopolitical publication. It was built with a specific vision: to offer honest, grounded reporting and rigorous analysis free from the pressures of corporate conglomerates or partisan noise.
          </p>
          <p>
            Whether examining local water governance in the rural canals of Sindh, or the maritime balance of power across the Indian Ocean, our commitment is to clarity, historical context, and respect for the reader's intellect.
          </p>
        </div>

        {/* 3 Pillars: News vs Analysis vs Opinion */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-6">
          <div className="p-5 rounded-xl bg-[#141517] border border-[#2a2723]">
            <div className="text-amber-400 font-serif font-bold uppercase text-xs tracking-wider mb-2">
              01 · Verified News
            </div>
            <p className="text-xs text-[#a39e93] leading-relaxed font-sans">
              Factual reporting, verified local dispatches, and sourced information with citations. No sensationalist spin.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-[#141517] border border-[#2a2723]">
            <div className="text-amber-300 font-serif font-bold uppercase text-xs tracking-wider mb-2">
              02 · Strategic Analysis
            </div>
            <p className="text-xs text-[#a39e93] leading-relaxed font-sans">
              Context, structural explanations, economic data, and geopolitical implications of unfolding global and regional events.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-[#141517] border border-[#2a2723]">
            <div className="text-[#d4af37] font-serif font-bold uppercase text-xs tracking-wider mb-2">
              03 · Commentary & Essays
            </div>
            <p className="text-xs text-[#a39e93] leading-relaxed font-sans">
              Personal viewpoints, essays, ethical reflections, and discussions. Transparently labeled so opinions are never confused with facts.
            </p>
          </div>
        </div>
      </section>

      {/* Topics Covered */}
      <section className="mb-14 p-6 sm:p-8 rounded-2xl bg-[#141517] border border-[#2a2723]">
        <h3 className="text-lg font-serif font-bold text-[#f4efe6] mb-5">
          Core Desks Covered at News By Ishaq
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-[#c4beaf]">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span><strong className="text-[#f4efe6]">Sindh:</strong> Hyderabad, Karachi, Matiari, agriculture & culture</span>
          </div>
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span><strong className="text-[#f4efe6]">Pakistan:</strong> Energy grid, federal policies, economic shifts</span>
          </div>
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span><strong className="text-[#f4efe6]">Geopolitics:</strong> Indian Ocean, alliances, Middle East, Gwadar</span>
          </div>
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span><strong className="text-[#f4efe6]">World:</strong> Multilateral diplomacy, UN reform, global south</span>
          </div>
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span><strong className="text-[#f4efe6]">Technology:</strong> AI, sovereign silicon, networks, open compute</span>
          </div>
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span><strong className="text-[#f4efe6]">Discussions:</strong> Thoughtful essays and reader inquiries</span>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <div className="text-center p-8 sm:p-10 rounded-2xl border border-[#2e2a24] bg-gradient-to-b from-[#161719] to-[#0e0f11]">
        <h3 className="text-2xl font-serif font-bold text-[#f4efe6] mb-2">
          Have an Inquiry, Story Tip, or Correction?
        </h3>
        <p className="text-xs sm:text-sm text-[#a39e93] max-w-lg mx-auto mb-6 font-serif">
          I read every dispatch and message from our readers and colleagues. Feel free to reach out directly through our contact desk.
        </p>
        <button
          onClick={() => onNavigate({ type: 'contact' })}
          className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-amber-950/40 transition-all cursor-pointer"
        >
          <Mail className="w-4 h-4" />
          <span>Contact News By Ishaq</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
