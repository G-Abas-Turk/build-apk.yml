import React, { useState } from 'react';
import { ViewRoute } from '../types';
import { Mail, Send, CheckCircle2, MessageSquare, AlertCircle } from 'lucide-react';

interface ContactViewProps {
  onNavigate: (route: ViewRoute) => void;
}

export const ContactView: React.FC<ContactViewProps> = ({ onNavigate: _onNavigate }) => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    subject: 'general',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSubmitted(true);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-in fade-in duration-300">
      <div className="text-center mb-10">
        <span className="text-[11px] font-serif uppercase tracking-[0.25em] text-amber-400 font-bold mb-2 block">
          Editorial & Reader Desk
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#f4efe6] tracking-tight mb-3">
          Contact News By Ishaq
        </h1>
        <p className="text-sm text-[#a39e93] font-serif max-w-lg mx-auto">
          We welcome reader inquiries, factual corrections, suggestions, and primary story leads.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
        <div className="p-5 rounded-2xl bg-[#141517] border border-[#2a2723] text-center">
          <Mail className="w-5 h-5 text-amber-400 mx-auto mb-2" />
          <div className="text-xs font-serif font-bold text-[#f4efe6] uppercase mb-1">Direct Inquiries</div>
          <a
            href="mailto:ishaqturk91@gmail.com"
            className="text-xs text-amber-400 hover:text-amber-300 underline font-mono break-all"
          >
            ishaqturk91@gmail.com
          </a>
        </div>

        <div className="p-5 rounded-2xl bg-[#141517] border border-[#2a2723] text-center">
          <AlertCircle className="w-5 h-5 text-amber-400 mx-auto mb-2" />
          <div className="text-xs font-serif font-bold text-[#f4efe6] uppercase mb-1">Corrections</div>
          <div className="text-xs text-[#a39e93]">
            We review and correct confirmed inaccuracies within 24 hours.
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#141517] border border-[#2a2723] text-center">
          <MessageSquare className="w-5 h-5 text-amber-400 mx-auto mb-2" />
          <div className="text-xs font-serif font-bold text-[#f4efe6] uppercase mb-1">Editorial Home</div>
          <div className="text-xs text-[#a39e93]">
            Official publication home: <span className="text-amber-400 font-mono">newsbyishaq.com</span>
          </div>
        </div>
      </div>

      {submitted ? (
        <div className="p-8 sm:p-10 rounded-2xl bg-[#141517] border border-[#2a2723] text-center">
          <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
          <h3 className="text-2xl font-serif font-bold text-[#f4efe6] mb-2">Message Received</h3>
          <p className="text-sm text-[#a39e93] font-serif max-w-md mx-auto mb-6">
            Thank you, {form.name}. Your correspondence has been delivered to Ishaq Turk's editorial desk.
          </p>
          <button
            onClick={() => {
              setSubmitted(false);
              setForm({ name: '', email: '', subject: 'general', message: '' });
            }}
            className="px-5 py-2.5 bg-[#1f2023] hover:bg-[#282a2e] text-[#f4efe6] border border-[#33302a] rounded-xl text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer"
          >
            Send Another Note
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 rounded-2xl bg-[#141517] border border-[#2a2723] space-y-5 shadow-2xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-1.5">
                Your Name
              </label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Tariq Solangi"
                className="w-full bg-[#0c0d0e] border border-[#2a2723] rounded-xl px-4 py-2.5 text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 transition-all font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-1.5">
                Your Email
              </label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="name@example.com"
                className="w-full bg-[#0c0d0e] border border-[#2a2723] rounded-xl px-4 py-2.5 text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 transition-all font-sans"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-1.5">
              Subject / Nature of Inquiry
            </label>
            <select
              value={form.subject}
              onChange={(e) => setForm({ ...form, subject: e.target.value })}
              className="w-full bg-[#0c0d0e] border border-[#2a2723] rounded-xl px-4 py-2.5 text-sm text-[#f4efe6] focus:outline-none focus:border-amber-400 transition-all font-sans"
            >
              <option value="general">General Question</option>
              <option value="correction">Factual Correction</option>
              <option value="suggestion">Story Suggestion or Lead</option>
              <option value="business">Business / Media Inquiry</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-1.5">
              Message
            </label>
            <textarea
              required
              rows={5}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Write your note or information here..."
              className="w-full bg-[#0c0d0e] border border-[#2a2723] rounded-xl px-4 py-2.5 text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 transition-all font-sans"
            />
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 rounded-xl text-xs font-serif font-bold uppercase tracking-wider shadow-lg shadow-amber-950/40 transition-all cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send Message</span>
          </button>
        </form>
      )}
    </div>
  );
};
