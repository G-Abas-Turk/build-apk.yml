import React from 'react';
import { ViewRoute } from '../types';
import { ArrowLeft, Shield } from 'lucide-react';

interface LegalViewProps {
  type: 'privacy' | 'terms';
  onNavigate: (route: ViewRoute) => void;
}

export const LegalView: React.FC<LegalViewProps> = ({ type, onNavigate }) => {
  const isPrivacy = type === 'privacy';

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-in fade-in duration-300">
      <button
        onClick={() => onNavigate({ type: 'home' })}
        className="inline-flex items-center gap-1.5 text-xs font-serif font-bold text-amber-400 hover:text-amber-300 transition-colors mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Back to Home</span>
      </button>

      <div className="flex items-center gap-3 mb-3">
        <Shield className="w-6 h-6 text-amber-400" />
        <h1 className="text-3xl sm:text-4xl font-serif font-bold uppercase text-[#f4efe6] tracking-tight">
          {isPrivacy ? 'Privacy Policy' : 'Terms of Service'}
        </h1>
      </div>

      <div className="text-xs text-[#a39e93] font-serif mb-8">
        Last updated: September 2026 · News By Ishaq (newsbyishaq.com)
      </div>

      <div className="p-6 sm:p-10 rounded-2xl bg-[#141517] border border-[#2a2723] text-sm leading-relaxed space-y-5 text-[#c4beaf] font-serif shadow-2xl">
        {isPrivacy ? (
          <>
            <p>
              At <strong className="text-[#f4efe6]">News By Ishaq</strong>, accessible from <strong className="text-[#f4efe6]">newsbyishaq.com</strong>, we hold reader privacy in the highest regard. This publication is committed to data transparency, ethical reader engagement, and zero invasive tracking.
            </p>
            <h3 className="text-lg font-serif font-bold text-[#f4efe6] pt-2">1. What Information We Collect</h3>
            <p>
              We do not require user accounts or personal registration to read our stories. If you reach out to us via our contact desk, your submitted email address and name are used solely to reply to your inquiry.
            </p>
            <h3 className="text-lg font-serif font-bold text-[#f4efe6] pt-2">2. Local Storage & Preferences</h3>
            <p>
              We utilize minimal client-side local storage exclusively to remember your selected theme (dark or light mode) and facilitate administrator article publishing states. No third-party data broker access is permitted.
            </p>
            <h3 className="text-lg font-serif font-bold text-[#f4efe6] pt-2">3. External Links</h3>
            <p>
              Our analysis and news reports include direct citations to external documents and news agencies. We are not responsible for the privacy practices of external domains.
            </p>
          </>
        ) : (
          <>
            <p>
              Welcome to <strong className="text-[#f4efe6]">News By Ishaq</strong>. By browsing this website, you agree to comply with and be bound by the following editorial terms and conditions.
            </p>
            <h3 className="text-lg font-serif font-bold text-[#f4efe6] pt-2">1. Intellectual Property & Fair Use</h3>
            <p>
              All original commentary, essays, and investigative reporting published on newsbyishaq.com are authored by Ishaq Turk unless otherwise credited. Short excerpts may be quoted with explicit attribution and a canonical backlink to the original article on newsbyishaq.com.
            </p>
            <h3 className="text-lg font-serif font-bold text-[#f4efe6] pt-2">2. Editorial Independence</h3>
            <p>
              News By Ishaq operates as an independent, personally curated platform. Opinions expressed in labeled "OPINION" articles reflect the perspectives of the author and do not constitute legal or financial advice.
            </p>
            <h3 className="text-lg font-serif font-bold text-[#f4efe6] pt-2">3. Corrections & Accountability</h3>
            <p>
              We strive for rigorous accuracy. Readers who notice factual errors may report them to ishaqturk91@gmail.com for prompt editorial review.
            </p>
          </>
        )}
      </div>
    </div>
  );
};
