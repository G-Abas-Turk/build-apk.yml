import React, { useState, useEffect } from 'react';
import { Article, ViewRoute } from '../types';
import { firebaseData } from '../services/firebaseDataService';
import { ArticleCard } from './ArticleCard';
import {
  Clock,
  Calendar,
  Share2,
  Check,
  ArrowLeft,
  AlertCircle
} from 'lucide-react';

interface ArticleViewProps {
  slug: string;
  onNavigate: (route: ViewRoute) => void;
}

export const ArticleView: React.FC<ArticleViewProps> = ({ slug, onNavigate }) => {
  const [article, setArticle] = useState<Article | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    firebaseData.getArticleBySlug(slug).then((found) => {
      if (!isMounted) return;
      setArticle(found);
      setLoading(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });

      if (found) {
        document.title = `${found.title} — NEWS BY ISHAQ`;
        // Fetch related articles from same category
        firebaseData.getPublishedArticles().then((all) => {
          if (!isMounted) return;
          const related = all
            .filter((a) => a.category === found.category && a.id !== found.id)
            .slice(0, 3);
          setRelatedArticles(related);
        });
      }
    });

    return () => {
      isMounted = false;
    };
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <div className="inline-block w-8 h-8 border-2 border-[#d4af37] border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-xs text-[#a09a8e] uppercase tracking-widest">Loading dispatch from Firestore...</p>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-24 text-center">
        <AlertCircle className="w-12 h-12 text-[#d4af37] mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-white mb-2 font-display">Story Not Found</h1>
        <p className="text-sm text-[#8c887e] mb-6">
          The requested article may have been unpublished, revised, or moved.
        </p>
        <button
          onClick={() => onNavigate({ type: 'home' })}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#d4af37] hover:bg-[#b89528] text-[#0c0d0e] rounded-lg text-xs font-bold uppercase tracking-wider cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          Return to Homepage
        </button>
      </div>
    );
  }

  const formattedPublished = article.publishedAt
    ? new Date(article.publishedAt).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      })
    : new Date(article.createdAt || Date.now()).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      });

  const authorName = article.authorName || article.author || 'Ishaq Turk';
  const authorAvatar = article.authorAvatar || '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';

  const currentUrl = typeof window !== 'undefined' ? window.location.href : `https://newsbyishaq.com/#/article/${article.slug}`;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  // Simple Markdown Body Renderer
  const renderMarkdown = (content: string) => {
    const blocks = content.split('\n\n');
    return blocks.map((block, i) => {
      const trimmed = block.trim();
      if (!trimmed) return null;

      if (trimmed.startsWith('## ')) {
        return (
          <h2 key={i} className="text-2xl sm:text-3xl font-bold font-display text-white mt-10 mb-4 tracking-tight">
            {trimmed.replace('## ', '')}
          </h2>
        );
      }

      if (trimmed.startsWith('### ')) {
        return (
          <h3 key={i} className="text-xl sm:text-2xl font-semibold font-display text-[#f5e6b3] mt-8 mb-3">
            {trimmed.replace('### ', '')}
          </h3>
        );
      }

      if (trimmed.startsWith('> ')) {
        return (
          <blockquote key={i} className="my-6 p-4 border-l-2 border-[#d4af37] bg-[#1a1917]/50 rounded-r-xl italic text-lg text-[#f3efe6] font-editorial">
            {trimmed.replace(/^>\s*/, '').replace(/"/g, '')}
          </blockquote>
        );
      }

      if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
        const items = trimmed.split('\n').map((line) => line.replace(/^[\*\-]\s*/, '').trim());
        return (
          <ul key={i} className="my-4 space-y-2 list-disc list-inside text-[#cfcac0] leading-relaxed">
            {items.map((it, idx) => (
              <li key={idx} className="pl-1">
                <span dangerouslySetInnerHTML={{ __html: it.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>') }} />
              </li>
            ))}
          </ul>
        );
      }

      return (
        <p
          key={i}
          className="text-base sm:text-lg text-[#cfcac0] leading-relaxed font-editorial font-light my-5"
          dangerouslySetInnerHTML={{ __html: trimmed.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>') }}
        />
      );
    });
  };

  return (
    <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      {/* Breadcrumb / Back button */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => onNavigate({ type: 'home' })}
          className="inline-flex items-center gap-2 text-xs font-semibold text-[#8c887e] hover:text-[#f5e6b3] transition-colors uppercase tracking-wider cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Headlines</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs uppercase font-bold text-[#d4af37] px-2.5 py-0.5 rounded bg-[#1e1c18] border border-[#d4af37]/25">
            {article.category}
          </span>
          <span className="text-[11px] uppercase font-bold text-[#b8b3a7] tracking-wider px-2 py-0.5 rounded bg-[#161514]">
            {article.type}
          </span>
        </div>
      </div>

      {/* Headline & Subtitle */}
      <h1 className="text-3xl sm:text-5xl font-black text-white font-display tracking-tight leading-tight mb-4">
        {article.title}
      </h1>

      {article.subtitle && (
        <p className="text-lg sm:text-xl text-[#cfcac0] font-editorial leading-snug mb-6 border-b border-[#292723] pb-6">
          {article.subtitle}
        </p>
      )}

      {/* Byline and metadata */}
      <div className="flex flex-wrap items-center justify-between gap-4 py-4 mb-6 border-b border-[#292723] text-xs text-[#8c887e]">
        <div className="flex items-center gap-3">
          <img
            src={authorAvatar}
            alt={authorName}
            className="w-10 h-10 rounded-full object-cover ring-2 ring-[#d4af37]/40"
          />
          <div>
            <div className="text-white font-bold text-sm">{authorName}</div>
            <div className="text-[11px] text-[#d4af37]">{article.authorRole}</div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <div className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-[#8c887e]" />
            <span>{formattedPublished}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-[#8c887e]" />
            <span>{article.readTime}</span>
          </div>
          {article.views !== undefined && (
            <span className="hidden sm:inline">· {article.views} reads</span>
          )}
        </div>
      </div>

      {/* Main Cover Image */}
      {article.imageUrl && (
        <div className="my-8 rounded-2xl overflow-hidden border border-[#2b2825] shadow-2xl relative">
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-auto max-h-[500px] object-cover"
          />
          {article.imageCaption && (
            <div className="p-3 bg-[#0c0d0e]/85 backdrop-blur-sm text-xs text-[#8c887e] border-t border-[#292723]">
              {article.imageCaption}
            </div>
          )}
        </div>
      )}

      {/* Article Body */}
      <div className="prose prose-invert max-w-none">
        {renderMarkdown(article.content)}
      </div>

      {/* Tags */}
      {article.tags && article.tags.length > 0 && (
        <div className="my-8 pt-6 border-t border-[#292723] flex flex-wrap items-center gap-2">
          <span className="text-xs uppercase font-bold text-[#8c887e] mr-2">Filed Under:</span>
          {article.tags.map((t) => (
            <span
              key={t}
              className="text-xs px-3 py-1 rounded-full bg-[#1a1918] border border-[#292723] text-[#cfcac0]"
            >
              #{t}
            </span>
          ))}
        </div>
      )}

      {/* Share strip */}
      <div className="p-4 rounded-xl glass-panel border border-[#d4af37]/15 flex flex-col sm:flex-row sm:items-center justify-between gap-4 my-8">
        <span className="text-xs font-bold uppercase tracking-wider text-[#cfcac0]">
          Share this investigation:
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={copyLink}
            className="py-1.5 px-3 rounded-lg bg-[#1a1918] hover:bg-[#252320] text-xs font-semibold text-white flex items-center gap-1.5 border border-[#2b2825] cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'Link Copied!' : 'Copy Link'}</span>
          </button>
        </div>
      </div>

      {/* Author Card Footer */}
      <div className="p-6 sm:p-7 rounded-2xl glass-panel border border-[#d4af37]/20 my-10 flex flex-col sm:flex-row items-center sm:items-start gap-5">
        <img
          src={authorAvatar}
          alt={authorName}
          className="w-16 h-16 rounded-2xl object-cover ring-2 ring-[#d4af37]/50 shrink-0"
        />
        <div className="text-center sm:text-left">
          <div className="text-xs font-bold text-[#d4af37] uppercase tracking-wider">About the Author</div>
          <h3 className="text-lg font-black text-white font-display mt-0.5">{authorName}</h3>
          <p className="text-xs sm:text-sm text-[#b8b3a7] mt-1.5 leading-relaxed font-editorial">
            {authorName === 'Ishaq Turk'
              ? 'Independent journalist and founder of News By Ishaq. Reporting on Sindh grassroots transformations, regional infrastructure corridors, and international power politics from Masu Bhurgari.'
              : `${article.authorRole} contributing original field reports and analytical columns to News By Ishaq.`}
          </p>
        </div>
      </div>

      {/* Related Stories */}
      {relatedArticles.length > 0 && (
        <div className="mt-12 pt-8 border-t border-[#292723]">
          <h3 className="text-xl font-black text-white font-display mb-6 uppercase">
            Related Dispatches in {article.category}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedArticles.map((rel) => (
              <ArticleCard
                key={rel.id}
                article={rel as any}
                onClick={() => onNavigate({ type: 'article', slug: rel.slug || rel.id })}
                variant="compact"
              />
            ))}
          </div>
        </div>
      )}
    </article>
  );
};
