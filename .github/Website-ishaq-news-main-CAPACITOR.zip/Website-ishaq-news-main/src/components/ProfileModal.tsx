import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { uploadMediaFile, compressImageToDataUrl } from '../services/storageService';
import { Camera, Upload, X, Check, AlertCircle, User, FileText, Sparkles } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, currentUser, isAdmin, updateProfilePicture, updateUserProfileData } = useAuth();
  const { addToast } = useToast();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentAvatar =
    userProfile?.photoURL ||
    currentUser?.photoURL ||
    (isAdmin ? '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg' : '');

  const [displayName, setDisplayName] = useState(
    userProfile?.name || currentUser?.displayName || (isAdmin ? 'Ishaq Turk' : '')
  );
  const [bio, setBio] = useState(userProfile?.bio || '');
  const [photoUrlInput, setPhotoUrlInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];

      // Validate size (5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError('Image exceeds 5MB size limit. Please select a smaller photo.');
        return;
      }

      setError(null);
      setSelectedFile(file);
      try {
        const compressed = await compressImageToDataUrl(file, 400, 400, 0.85);
        setPreviewUrl(compressed);
      } catch {
        const objectUrl = URL.createObjectURL(file);
        setPreviewUrl(objectUrl);
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);

    try {
      let finalPhotoUrl = currentAvatar;

      // 1. Upload new file to Firebase Storage if selected
      if (selectedFile) {
        try {
          finalPhotoUrl = await uploadMediaFile(selectedFile, 'avatars', (progress) => {
            setUploadProgress(progress);
          });
        } catch (uploadErr: unknown) {
          console.warn('Storage upload error, using object URL:', uploadErr);
          // If storage permissions restrict, previewUrl persists
          finalPhotoUrl = previewUrl || currentAvatar;
        }
      } else if (photoUrlInput.trim()) {
        finalPhotoUrl = photoUrlInput.trim();
      }

      // 2. Persist in Firebase Auth and Cloud Firestore
      if (finalPhotoUrl && finalPhotoUrl !== currentAvatar) {
        await updateProfilePicture(finalPhotoUrl);
      }

      // 3. Update name and bio
      await updateUserProfileData({
        name: displayName.trim(),
        bio: bio.trim(),
      });

      addToast({
        type: 'success',
        title: 'Profile Updated',
        message: 'Your profile picture and details have been saved to Firebase.',
      });

      onClose();
    } catch (err: unknown) {
      console.error('Failed to update profile:', err);
      const fbErr = err as { message?: string };
      setError(fbErr.message || 'Failed to save profile changes. Please try again.');
      addToast({
        type: 'error',
        title: 'Update Failed',
        message: fbErr.message || 'Could not update profile',
      });
    } finally {
      setSaving(false);
      setUploadProgress(null);
    }
  };

  const displayAvatar = previewUrl || (photoUrlInput.trim() ? photoUrlInput.trim() : currentAvatar);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-[#141517] border border-[#2a2723] rounded-2xl shadow-2xl overflow-hidden relative">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-[#22211e] flex items-center justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-[10px] uppercase font-serif tracking-widest text-amber-400 font-bold mb-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>{isAdmin ? 'Executive Profile & Avatar' : 'Reader Profile & Avatar'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#f4efe6]">
              Edit Profile Picture
            </h2>
            <p className="text-xs text-[#a39e93] font-serif">
              Upload a new photo to be saved in Firebase Cloud Firestore & Storage
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#a39e93] hover:text-[#f4efe6] rounded-xl hover:bg-[#1f2024] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSave} className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-800/60 flex items-start gap-3 text-red-300 text-xs leading-relaxed">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Avatar Preview & Upload Trigger */}
          <div className="flex flex-col sm:flex-row items-center gap-5 p-4 rounded-xl bg-[#0c0d0e] border border-[#262420]">
            <div className="relative group shrink-0">
              <div className="w-24 h-24 rounded-full overflow-hidden ring-4 ring-amber-500/40 shadow-xl bg-[#1b1c1e] flex items-center justify-center">
                {displayAvatar ? (
                  <img
                    src={displayAvatar}
                    alt="Profile Preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
                    }}
                  />
                ) : (
                  <User className="w-10 h-10 text-[#736e64]" />
                )}
              </div>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="Change Photo"
                className="absolute bottom-0 right-0 p-2 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-md ring-2 ring-[#0c0d0e] transition-all cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex-1 text-center sm:text-left space-y-2">
              <h3 className="text-sm font-serif font-bold text-[#f4efe6]">
                Upload New Image
              </h3>
              <p className="text-xs text-[#a39e93] leading-relaxed">
                PNG, JPG, or WebP up to 5MB. Photo will be saved directly to Firebase.
              </p>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3.5 py-1.5 bg-[#1b1c1e] hover:bg-[#24262b] border border-[#2e2b26] text-xs font-serif font-bold text-[#f4efe6] rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-amber-400" />
                  <span>Choose Image File</span>
                </button>
                {selectedFile && (
                  <span className="text-[11px] text-amber-300 font-serif">
                    {selectedFile.name.length > 18 ? selectedFile.name.substring(0, 18) + '...' : selectedFile.name}
                  </span>
                )}
              </div>
            </div>
          </div>

          {uploadProgress !== null && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-serif text-[#a39e93]">
                <span>Uploading to Firebase Storage</span>
                <span className="text-amber-400 font-bold">{uploadProgress}%</span>
              </div>
              <div className="w-full bg-[#1b1c1e] rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-amber-400 h-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Alternative URL Input */}
          <div>
            <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-1.5">
              Or Provide External Image URL
            </label>
            <input
              type="url"
              value={photoUrlInput}
              onChange={(e) => setPhotoUrlInput(e.target.value)}
              placeholder="https://example.com/avatar.jpg"
              className="w-full px-3.5 py-2.5 bg-[#0c0d0e] border border-[#2a2723] rounded-xl text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 transition-all font-sans"
            />
          </div>

          {/* Display Name */}
          <div>
            <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-1.5">
              Display Name
            </label>
            <input
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Your Name"
              className="w-full px-3.5 py-2.5 bg-[#0c0d0e] border border-[#2a2723] rounded-xl text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 transition-all font-sans"
            />
          </div>

          {/* Bio */}
          <div>
            <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-1.5">
              Author / Reader Bio
            </label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Short bio or investigative interest"
              className="w-full px-3.5 py-2 bg-[#0c0d0e] border border-[#2a2723] rounded-xl text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 transition-all font-sans"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-[#22211e] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-[#1b1c1e] text-[#a39e93] hover:text-[#f4efe6] text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider shadow-lg shadow-amber-950/40 transition-all disabled:opacity-50 cursor-pointer flex items-center gap-2"
            >
              {saving ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-stone-950 border-t-transparent rounded-full animate-spin" />
                  <span>Saving to Firebase...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save Profile</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
