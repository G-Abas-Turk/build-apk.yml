import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { firebaseData } from '../services/firebaseDataService';
import { uploadMediaFile } from '../services/storageService';
import { ViewRoute, CategoryItem } from '../types';
import { PenTool, ArrowRight, AlertCircle, FileText, CheckCircle2 } from 'lucide-react';

interface SubmitArticleViewProps {
  onNavigate: (route: ViewRoute) => void;
}

export const SubmitArticleView: React.FC<SubmitArticleViewProps> = ({ onNavigate }) => {
  const { currentUser, userProfile, isRegistered } = useAuth();
  const { addToast } = useToast();

  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('sindh');
  const [type, setType] = useState<'news' | 'analysis' | 'opinion'>('opinion');
  const [tagsInput, setTagsInput] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    firebaseData.getCategories().then((cats) => {
      setCategories(cats);
      if (cats.length > 0) setCategory(cats[0].slug);
    });
  }, []);

  if (!isRegistered || !currentUser) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
        <div className="max-w-md w-full p-8 rounded-2xl bg-[#141517] border border-[#2a2723] text-center shadow-2xl">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto mb-4 text-amber-400">
            <PenTool className="w-6 h-6" />
          </div>
          <p className="text-[10px] font-serif uppercase tracking-[0.25em] text-amber-400 font-bold mb-1">
            Community & Contributor Desk
          </p>
          <h2 className="text-2xl font-serif font-bold text-[#f4efe6]">Reader Submissions</h2>
          <p className="text-xs text-[#a39e93] mt-2 leading-relaxed font-serif">
            You must be signed in to submit investigative pitches, opinion essays, or regional dispatches to News By Ishaq.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => onNavigate({ type: 'login' })}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={() => onNavigate({ type: 'register' })}
              className="flex-1 py-3 px-4 rounded-xl bg-[#1b1c1e] hover:bg-[#232529] text-[#f4efe6] font-serif font-bold text-xs uppercase tracking-wider border border-[#2e2b26] transition-all cursor-pointer"
            >
              Create Account
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim() || !summary.trim() || !content.trim()) {
      setError('Please provide a title, short description, and full article content.');
      return;
    }

    try {
      setSubmitting(true);
      let uploadedImageUrl = '/assets/images/hero_geopolitics_summit_1790362774883.jpg';

      if (imageFile) {
        uploadedImageUrl = await uploadMediaFile(imageFile, 'articles', (p) => {
          setUploadProgress(p);
        });
      }

      const tags = tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      const wordCount = content.trim().split(/\s+/).length;
      const readMinutes = Math.max(1, Math.ceil(wordCount / 200));

      await firebaseData.createArticle({
        title: title.trim(),
        slug: '',
        subtitle: subtitle.trim(),
        summary: summary.trim(),
        content: content.trim(),
        category,
        type,
        authorId: currentUser.uid,
        authorName: userProfile?.name || currentUser.displayName || 'Reader Contributor',
        authorEmail: currentUser.email || '',
        authorRole: 'Community Contributor',
        authorAvatar: userProfile?.photoURL || undefined,
        imageUrl: uploadedImageUrl,
        readTime: `${readMinutes} min read`,
        tags: tags.length > 0 ? tags : [category],
        status: 'pending',
      });

      addToast({
        type: 'success',
        title: 'Article Submitted',
        message: 'Your piece has been sent to Editor Ishaq Turk for review. Track it under My Submissions.',
      });

      onNavigate({ type: 'my-submissions' });
    } catch (err: unknown) {
      console.error('Article submission error:', err);
      const fbErr = err as { message?: string };
      setError(fbErr.message || 'Failed to submit article. Please try again.');
      addToast({ type: 'error', title: 'Submission Failed', message: fbErr.message || 'Error occurred' });
    } finally {
      setSubmitting(false);
      setUploadProgress(null);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <span className="text-[11px] font-serif uppercase tracking-[0.25em] text-amber-400 font-bold block mb-1">
          Editorial Submission Desk
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#f4efe6] tracking-tight">
          Submit an Article
        </h1>
        <p className="text-sm text-[#a39e93] mt-2 leading-relaxed font-serif">
          Contribute investigative field reports, regional analyses from Sindh and Pakistan, or thoughtful geopolitical columns. Every submission is reviewed by the editorial team prior to publication.
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-xl bg-red-950/40 border border-red-800/60 flex items-start gap-3 text-red-300 text-xs leading-relaxed animate-fadeIn">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 p-6 sm:p-8 rounded-2xl bg-[#141517] border border-[#2a2723] shadow-2xl">
        <div>
          <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
            Article Title <span className="text-amber-400">*</span>
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Grounded Realities: Solar Microgrids in Rural Matiari"
            className="w-full px-4 py-2.5 rounded-xl bg-[#0c0d0e] border border-[#2a2723] focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 text-[#f4efe6] placeholder-[#555149] text-sm outline-none transition-all font-sans"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
              Category Desk <span className="text-amber-400">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#0c0d0e] border border-[#2a2723] focus:border-amber-400 text-[#f4efe6] text-sm outline-none transition-all cursor-pointer font-sans"
            >
              {categories.map((c) => (
                <option key={c.id} value={c.slug}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
              Article Format
            </label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as any)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#0c0d0e] border border-[#2a2723] focus:border-amber-400 text-[#f4efe6] text-sm outline-none transition-all cursor-pointer font-sans"
            >
              <option value="opinion">Opinion & Commentary</option>
              <option value="news">News & Field Report</option>
              <option value="analysis">Deep Strategic Analysis</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
            Subtitle (Optional)
          </label>
          <input
            type="text"
            value={subtitle}
            onChange={(e) => setSubtitle(e.target.value)}
            placeholder="A supporting one-sentence explanation"
            className="w-full px-4 py-2.5 rounded-xl bg-[#0c0d0e] border border-[#2a2723] focus:border-amber-400 text-[#f4efe6] placeholder-[#555149] text-sm outline-none transition-all font-sans"
          />
        </div>

        <div>
          <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
            Excerpt / Summary <span className="text-amber-400">*</span>
          </label>
          <textarea
            required
            rows={2}
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            placeholder="A concise 2-3 sentence overview that appears on article cards"
            className="w-full px-4 py-2.5 rounded-xl bg-[#0c0d0e] border border-[#2a2723] focus:border-amber-400 text-[#f4efe6] placeholder-[#555149] text-sm outline-none transition-all resize-y font-sans"
          />
        </div>

        <div>
          <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
            Full Content (Markdown Supported) <span className="text-amber-400">*</span>
          </label>
          <textarea
            required
            rows={10}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write your article body here... Use ## for section headings, - for lists, and > for quotes."
            className="w-full px-4 py-2.5 rounded-xl bg-[#0c0d0e] border border-[#2a2723] focus:border-amber-400 text-[#f4efe6] placeholder-[#555149] text-sm font-mono outline-none transition-all resize-y"
          />
        </div>

        <div>
          <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
            Cover Image (JPG, PNG, WebP · Up to 5MB)
          </label>
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={handleImageChange}
            className="block w-full text-xs text-[#a39e93] file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-serif file:font-bold file:bg-amber-500/10 file:text-amber-300 hover:file:bg-amber-500/20 cursor-pointer"
          />
          {imagePreview && (
            <div className="mt-3 relative w-48 h-28 rounded-xl overflow-hidden border border-[#2a2723]">
              <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
            </div>
          )}
          {uploadProgress !== null && (
            <div className="mt-2 text-xs text-amber-400">
              Uploading to Firebase Storage: {uploadProgress}%
            </div>
          )}
        </div>

        <div>
          <label className="block text-xs font-serif uppercase tracking-wider text-[#c4beaf] mb-2">
            Tags (Comma separated)
          </label>
          <input
            type="text"
            value={tagsInput}
            onChange={(e) => setTagsInput(e.target.value)}
            placeholder="Sindh, Agriculture, Economy, Rural"
            className="w-full px-4 py-2.5 rounded-xl bg-[#0c0d0e] border border-[#2a2723] focus:border-amber-400 text-[#f4efe6] placeholder-[#555149] text-sm outline-none transition-all font-sans"
          />
        </div>

        <div className="pt-4 border-t border-[#22211e] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs text-[#a39e93] font-serif">
            Status on submission: <span className="font-semibold text-amber-400">Pending Review</span>
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="w-full sm:w-auto py-3 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider shadow-lg shadow-amber-950/40 transition-all disabled:opacity-60 cursor-pointer flex items-center justify-center gap-2"
          >
            {submitting ? (
              'Submitting to Firestore...'
            ) : (
              <>
                <span>Submit for Editorial Review</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
