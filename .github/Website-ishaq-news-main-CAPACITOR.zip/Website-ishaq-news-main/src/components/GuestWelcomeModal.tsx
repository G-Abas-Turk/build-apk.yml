import React from 'react';
import { useAuth } from '../context/AuthContext';
import { ViewRoute } from '../types';

interface GuestWelcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: ViewRoute) => void;
}

export const GuestWelcomeModal: React.FC<GuestWelcomeModalProps> = ({ isOpen, onClose, onNavigate }) => {
  const { setGuestDismissed } = useAuth();

  if (!isOpen) return null;

  const handleContinueAsGuest = () => {
    setGuestDismissed(true);
    onClose();
  };

  const handleAction = (route: ViewRoute) => {
    setGuestDismissed(true);
    onClose();
    onNavigate(route);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md p-6 sm:p-8 rounded-2xl glass-panel border border-[#d4af37]/35 shadow-2xl text-center relative overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-[#d4af37]/15 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-[#b38820]/15 rounded-full blur-2xl pointer-events-none" />

        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#d4af37] via-[#b88c1c] to-[#996b10] flex items-center justify-center mx-auto mb-4 shadow-lg shadow-black/60 ring-2 ring-[#d4af37]/40 p-0.5">
          <img
            src="/assets/images/ishaq_turk_suit_exact_1790364183317.jpg"
            alt="Ishaq Turk"
            className="w-full h-full object-cover rounded-[14px]"
          />
        </div>

        <h3 className="text-2xl font-black text-white font-display uppercase tracking-tight">
          Welcome to News By Ishaq
        </h3>
        <p className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold mt-1">
          Independent Journalism & Field Reporting
        </p>

        <p className="text-sm text-[#cfcac0] mt-4 leading-relaxed font-editorial">
          Read investigative dispatches from Sindh, national analysis across Pakistan, and geopolitical strategy without corporate interference.
        </p>

        <div className="mt-6 flex flex-col gap-3">
          <button
            onClick={() => handleAction({ type: 'login' })}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#c59b27] to-[#b38820] hover:brightness-110 text-[#0c0d0e] font-black text-sm tracking-wide shadow-lg shadow-[#d4af37]/20 transition-all cursor-pointer uppercase"
          >
            Log In
          </button>

          <button
            onClick={() => handleAction({ type: 'register' })}
            className="w-full py-3 px-4 rounded-xl bg-[#1c1a17] hover:bg-[#252320] border border-[#d4af37]/30 text-white font-bold text-sm tracking-wide transition-all cursor-pointer"
          >
            Create Account
          </button>

          <button
            onClick={handleContinueAsGuest}
            className="w-full py-2.5 px-4 rounded-xl text-[#8c887e] hover:text-white font-medium text-xs tracking-wider uppercase transition-colors cursor-pointer"
          >
            Continue as Guest
          </button>
        </div>

        <div className="mt-4 pt-4 border-t border-[#232220] text-[11px] text-[#706c62]">
          Guests can browse and read all published investigations freely.
        </div>
      </div>
    </div>
  );
};
