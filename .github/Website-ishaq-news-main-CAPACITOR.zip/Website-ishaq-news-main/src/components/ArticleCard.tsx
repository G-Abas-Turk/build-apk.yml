import React from 'react';
import { Article } from '../types';
import { Clock } from 'lucide-react';

interface ArticleCardProps {
  article: Article;
  onClick: () => void;
  variant?: 'featured' | 'standard' | 'compact' | 'horizontal';
}

export const ArticleCard: React.FC<ArticleCardProps> = ({
  article,
  onClick,
  variant = 'standard'
}) => {
  const formattedDate = new Date(article.publishedAt || article.createdAt || Date.now()).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  const authorName = article.authorName || article.author || 'Ishaq Turk';

  const typeLabels: Record<string, { label: string; color: string }> = {
    news: { label: 'NEWS', color: 'text-[#d4af37]' },
    analysis: { label: 'ANALYSIS', color: 'text-[#e5c46b]' },
    opinion: { label: 'OPINION', color: 'text-[#cfa444]' }
  };

  const typeInfo = typeLabels[article.type] || typeLabels.news;

  if (variant === 'compact') {
    return (
      <article
        onClick={onClick}
        className="group cursor-pointer py-3.5 border-b border-[#292723] last:border-b-0 hover:bg-[#1a1918]/50 px-2 rounded-lg transition-colors"
      >
        <div className="flex items-center gap-2 text-xs text-[#8c887e] mb-1.5">
          <span className={`font-semibold tracking-wider ${typeInfo.color}`}>{typeInfo.label}</span>
          <span aria-hidden="true" className="text-[#524e47]">·</span>
          <span className="capitalize">{article.category}</span>
          <span aria-hidden="true" className="text-[#524e47]">·</span>
          <span>{article.readTime}</span>
        </div>
        <h4 className="text-sm font-semibold text-[#f5f2eb] group-hover:text-[#f3e7b8] transition-colors line-clamp-2 leading-snug font-display">
          {article.title}
        </h4>
      </article>
    );
  }

  if (variant === 'horizontal') {
    return (
      <article
        onClick={onClick}
        className="group cursor-pointer flex flex-col sm:flex-row gap-5 p-5 rounded-2xl glass-panel glass-panel-hover border border-[#d4af37]/15"
      >
        <div className="sm:w-56 sm:h-36 shrink-0 rounded-xl overflow-hidden relative bg-[#0c0d0e] border border-[#2b2825]">
          <img
            src={article.imageUrl}
            alt={article.title}
            referrerPolicy="no-referrer"
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <div className="flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#8c887e] mb-2">
              <span className={`font-semibold tracking-wider ${typeInfo.color}`}>{typeInfo.label}</span>
              <span aria-hidden="true" className="text-[#524e47]">·</span>
              <span className="capitalize text-[#cfcac0]">{article.category}</span>
              <span aria-hidden="true" className="text-[#524e47]">·</span>
              <span>{formattedDate}</span>
              <span aria-hidden="true" className="text-[#524e47]">·</span>
              <span className="flex items-center gap-1 text-[#a09a8e]">
                <Clock className="w-3 h-3 text-[#d4af37]" />
                {article.readTime}
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-[#f5f2eb] group-hover:text-[#f3e7b8] transition-colors line-clamp-2 mb-2 leading-snug font-display">
              {article.title}
            </h3>
            <p className="text-xs sm:text-sm text-[#b8b3a7] line-clamp-2 leading-relaxed font-editorial">
              {article.summary}
            </p>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-[#8c887e]">
            <span>By {authorName}</span>
            <span className="text-[#d4af37] group-hover:translate-x-1 transition-transform inline-flex items-center gap-1 font-semibold">
              Read story →
            </span>
          </div>
        </div>
      </article>
    );
  }

  // Standard vertical card
  return (
    <article
      onClick={onClick}
      className="group cursor-pointer flex flex-col rounded-2xl overflow-hidden glass-panel glass-panel-hover border border-[#d4af37]/15"
    >
      <div className="aspect-[16/10] w-full overflow-hidden relative bg-[#0c0d0e] border-b border-[#292723]">
        <img
          src={article.imageUrl}
          alt={article.title}
          referrerPolicy="no-referrer"
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0c0d0e]/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
      </div>

      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Zero-Pill Metadata Line */}
          <div className="flex items-center gap-2 text-xs text-[#8c887e] mb-2.5">
            <span className={`font-semibold tracking-wider ${typeInfo.color}`}>{typeInfo.label}</span>
            <span aria-hidden="true" className="text-[#524e47]">·</span>
            <span className="capitalize text-[#cfcac0] font-medium">{article.category}</span>
            <span aria-hidden="true" className="text-[#524e47]">·</span>
            <span>{formattedDate}</span>
          </div>

          <h3 className="text-lg font-bold text-[#f5f2eb] group-hover:text-[#f3e7b8] transition-colors line-clamp-2 leading-snug mb-2 font-display">
            {article.title}
          </h3>

          <p className="text-sm text-[#b8b3a7] line-clamp-3 leading-relaxed mb-4 font-editorial">
            {article.summary}
          </p>
        </div>

        <div className="pt-3 border-t border-[#292723] flex items-center justify-between text-xs text-[#8c887e]">
          <span>By {authorName}</span>
          <span className="flex items-center gap-1 text-[#a09a8e]">
            <Clock className="w-3 h-3 text-[#d4af37]" />
            {article.readTime}
          </span>
        </div>
      </div>
    </article>
  );
};
