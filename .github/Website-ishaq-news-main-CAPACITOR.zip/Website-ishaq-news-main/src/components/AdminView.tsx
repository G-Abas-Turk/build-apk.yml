import React, { useState, useEffect } from 'react';
import { Article, Category, ArticleType, ArticleSource, ViewRoute } from '../types';
import { articleStorage } from '../services/articleStorage';
import {
  Lock,
  Unlock,
  Plus,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
  CheckCircle2,
  Download,
  Upload,
  RefreshCw,
  LogOut,
  Globe,
  FileText,
  Key,
  HelpCircle,
  Image as ImageIcon,
  ArrowLeft,
  ExternalLink,
  Save,
  Send
} from 'lucide-react';

interface AdminViewProps {
  onNavigate: (route: ViewRoute) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ onNavigate }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() =>
    articleStorage.isAdminAuthenticated()
  );
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [articles, setArticles] = useState<Article[]>([]);
  const [filterStatus, setFilterStatus] = useState<'all' | 'published' | 'draft'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showDeploymentGuide, setShowDeploymentGuide] = useState(false);

  // Editor modal state
  const [isEditing, setIsEditing] = useState(false);
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);

  // Form fields
  const [formTitle, setFormTitle] = useState('');
  const [formSubtitle, setFormSubtitle] = useState('');
  const [formCategory, setFormCategory] = useState<Category>('geopolitics');
  const [formType, setFormType] = useState<ArticleType>('news');
  const [formAuthor, setFormAuthor] = useState('Ishaq Turk');
  const [formAuthorRole, setFormAuthorRole] = useState('Founder & Editor');
  const [formSummary, setFormSummary] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formImageUrl, setFormImageUrl] = useState('/src/assets/images/hero_geopolitics_summit_1790362774883.jpg');
  const [formImageCaption, setFormImageCaption] = useState('');
  const [formTags, setFormTags] = useState('Geopolitics, Sindh, News');
  const [formSources, setFormSources] = useState<ArticleSource[]>([]);
  const [newSourceName, setNewSourceName] = useState('');
  const [newSourceUrl, setNewSourceUrl] = useState('');
  const [formIsFeatured, setFormIsFeatured] = useState(false);
  const [formIsTrending, setFormIsTrending] = useState(false);
  const [formTrendingRank, setFormTrendingRank] = useState(1);
  const [previewTab, setPreviewTab] = useState<'write' | 'preview'>('write');

  // Notification message
  const [notification, setNotification] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const refreshArticles = () => {
    setArticles(articleStorage.getAllArticles());
  };

  useEffect(() => {
    refreshArticles();
    const unsub = articleStorage.subscribe(() => {
      refreshArticles();
    });
    return unsub;
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (articleStorage.loginAdmin(passwordInput)) {
      setIsAuthenticated(true);
      setLoginError('');
      setPasswordInput('');
      refreshArticles();
    } else {
      setLoginError('Invalid administrator password. Try: ishaq2026');
    }
  };

  const handleLogout = () => {
    articleStorage.logoutAdmin();
    setIsAuthenticated(false);
  };

  const handleOpenEditor = (article?: Article) => {
    if (article) {
      setEditingArticleId(article.id);
      setFormTitle(article.title);
      setFormSubtitle(article.subtitle || '');
      setFormCategory(article.category);
      setFormType(article.type);
      setFormAuthor(article.author);
      setFormAuthorRole(article.authorRole);
      setFormSummary(article.summary);
      setFormContent(article.content);
      setFormImageUrl(article.imageUrl);
      setFormImageCaption(article.imageCaption || '');
      setFormTags(article.tags.join(', '));
      setFormSources(article.sources || []);
      setFormIsFeatured(!!article.isFeatured);
      setFormIsTrending(!!article.isTrending);
      setFormTrendingRank(article.trendingRank || 1);
    } else {
      setEditingArticleId(null);
      setFormTitle('');
      setFormSubtitle('');
      setFormCategory('geopolitics');
      setFormType('news');
      setFormAuthor('Ishaq Turk');
      setFormAuthorRole('Founder & Editor');
      setFormSummary('');
      setFormContent('## Overview\n\nWrite your initial paragraph here...\n\n### Key Context\n\nDetail the background and strategic importance here.\n\n> "Add an insightful quote here."');
      setFormImageUrl('/src/assets/images/hero_geopolitics_summit_1790362774883.jpg');
      setFormImageCaption('');
      setFormTags('Geopolitics, News, Analysis');
      setFormSources([]);
      setFormIsFeatured(false);
      setFormIsTrending(false);
      setFormTrendingRank(1);
    }
    setPreviewTab('write');
    setIsEditing(true);
  };

  const handleSaveArticle = (status: 'published' | 'draft') => {
    if (!formTitle.trim()) {
      alert('Please enter an article title.');
      return;
    }
    if (!formContent.trim()) {
      alert('Please write article content.');
      return;
    }

    const tagsArray = formTags
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    const saved = articleStorage.saveArticle({
      id: editingArticleId || undefined,
      title: formTitle,
      subtitle: formSubtitle,
      category: formCategory,
      type: formType,
      author: formAuthor,
      authorRole: formAuthorRole,
      summary: formSummary || formContent.slice(0, 160) + '...',
      content: formContent,
      imageUrl: formImageUrl,
      imageCaption: formImageCaption,
      tags: tagsArray,
      sources: formSources,
      status,
      isFeatured: formIsFeatured,
      isTrending: formIsTrending,
      trendingRank: Number(formTrendingRank) || 99
    });

    setIsEditing(false);
    refreshArticles();
    showToast(status === 'published' ? 'Story published live!' : 'Saved as private draft');
  };

  const handleTogglePublish = (article: Article) => {
    const updated = articleStorage.togglePublishStatus(article.id);
    if (updated) {
      refreshArticles();
      showToast(
        updated.status === 'published'
          ? `"${article.title.slice(0, 30)}..." published live!`
          : `"${article.title.slice(0, 30)}..." moved to drafts`
      );
    }
  };

  const handleDelete = (article: Article) => {
    if (window.confirm(`Are you sure you want to permanently delete "${article.title}"?`)) {
      articleStorage.deleteArticle(article.id);
      refreshArticles();
      showToast('Article deleted successfully');
    }
  };

  const handleAddSource = () => {
    if (!newSourceName.trim() || !newSourceUrl.trim()) return;
    setFormSources([...formSources, { name: newSourceName.trim(), url: newSourceUrl.trim() }]);
    setNewSourceName('');
    setNewSourceUrl('');
  };

  const handleRemoveSource = (index: number) => {
    setFormSources(formSources.filter((_, i) => i !== index));
  };

  // Image Upload Handler (reads base64 DataURL so works 100% offline & without server)
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setFormImageUrl(reader.result);
          showToast('Image uploaded successfully');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleExportJSON = () => {
    const dataStr = articleStorage.exportArticlesJSON();
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `news-by-ishaq-articles-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('Exported articles.json for Netlify backup');
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result;
        if (typeof text === 'string') {
          if (articleStorage.importArticlesJSON(text)) {
            refreshArticles();
            showToast('Articles imported and synced successfully!');
          } else {
            alert('Invalid JSON file format.');
          }
        }
      };
      reader.readAsText(file);
    }
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset all stories back to the original demo articles? Any custom modifications will be replaced.')) {
      articleStorage.resetToDefaults();
      refreshArticles();
      showToast('Reset to original demo articles');
    }
  };

  // Filtered articles list
  const filteredArticles = articles.filter(a => {
    if (filterStatus !== 'all' && a.status !== filterStatus) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        a.title.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q) ||
        a.author.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // If not authenticated, render login gate
  if (!isAuthenticated) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-md p-8 rounded-2xl glass-panel border border-amber-500/25 shadow-2xl">
          <div className="text-center mb-6">
            <div className="w-12 h-12 rounded-xl bg-amber-950 border border-amber-500/30 flex items-center justify-center mx-auto mb-3">
              <Lock className="w-6 h-6 text-amber-400" />
            </div>
            <h1 className="text-xl font-bold uppercase text-white font-display tracking-tight">
              Publisher Admin Portal
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Restricted to Ishaq Turk for publishing on newsbyishaq.com
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Admin Security Key / Passcode
              </label>
              <input
                type="password"
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter password..."
                className="w-full bg-slate-900 border border-amber-500/25 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
              />
              <p className="text-[11px] text-amber-400/80 mt-1.5 flex items-center gap-1">
                <span>Default setup passcode:</span>
                <code className="bg-slate-900 px-1.5 py-0.5 rounded text-white font-mono">ishaq2026</code>
              </p>
            </div>

            {loginError && (
              <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs">
                {loginError}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold uppercase tracking-wider shadow-lg shadow-amber-950/50 transition-colors flex items-center justify-center gap-2"
            >
              <Unlock className="w-4 h-4" />
              <span>Unlock Publishing Desk</span>
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-slate-800 text-center">
            <button
              onClick={() => onNavigate({ type: 'home' })}
              className="text-xs text-slate-400 hover:text-amber-300 inline-flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Return to public website</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Authenticated Admin Dashboard
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 bg-amber-600 text-white px-4 py-2.5 rounded-xl shadow-xl shadow-amber-950/50 text-xs font-semibold flex items-center gap-2 animate-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{notification}</span>
        </div>
      )}

      {/* Admin Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-8 border-b border-amber-500/20">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Admin Active · newsbyishaq.com</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black uppercase text-white font-display">
            Editorial Publishing Desk
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowDeploymentGuide(!showDeploymentGuide)}
            className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/20 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Netlify & Architecture Guide</span>
          </button>

          <button
            onClick={() => handleOpenEditor()}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-amber-900/30 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create Story</span>
          </button>

          <button
            onClick={handleLogout}
            title="Log out"
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Deployment & Architecture Guide Modal/Drawer */}
      {showDeploymentGuide && (
        <div className="mb-10 p-6 sm:p-8 rounded-2xl glass-panel border border-amber-400/40 relative">
          <button
            onClick={() => setShowDeploymentGuide(false)}
            className="absolute top-4 right-4 text-slate-400 hover:text-white text-xs font-bold"
          >
            ✕ Close
          </button>
          <div className="flex items-center gap-2 text-amber-300 font-bold uppercase text-sm mb-3">
            <Globe className="w-5 h-5 text-amber-400" />
            <span>Deployment to Netlify & Custom Domain Setup (newsbyishaq.com)</span>
          </div>
          <div className="text-xs sm:text-sm text-slate-300 space-y-3 leading-relaxed">
            <p>
              <strong>How data storage works:</strong> Articles are maintained in a high-speed local reactive cache synced with browser storage. When you click <strong>PUBLISH</strong>, the story is immediately active and visible in all public routes (Homepage, Category pages, Search).
            </p>
            <p>
              <strong>Deploying to Netlify (Free & Permanent):</strong>
            </p>
            <ol className="list-decimal pl-5 space-y-1.5">
              <li>Push this project to your GitHub account (or drag the built <code>dist</code> folder into Netlify Drop).</li>
              <li>In Netlify, select <strong>Add new site &gt; Import an existing project</strong>.</li>
              <li>Build command: <code>npm run build</code> | Publish directory: <code>dist</code></li>
              <li>In Netlify Site Settings &gt; Domain management, click <strong>Add a custom domain</strong> and enter <code>newsbyishaq.com</code>.</li>
              <li>Add the DNS records (CNAME or A record pointing to Netlify) provided in your domain registrar (Namecheap, GoDaddy, Cloudflare, etc.).</li>
            </ol>
            <div className="pt-2 flex flex-wrap gap-2">
              <button
                onClick={handleExportJSON}
                className="px-3 py-1.5 bg-amber-950 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-semibold flex items-center gap-1.5 hover:bg-amber-900/60"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Backup Articles (JSON)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="p-4 rounded-xl glass-panel border border-amber-500/20">
          <div className="text-xs text-slate-400 mb-1">Total Stories</div>
          <div className="text-2xl font-black text-white font-display tabular-nums">
            {articles.length}
          </div>
        </div>

        <div className="p-4 rounded-xl glass-panel border border-emerald-500/20">
          <div className="text-xs text-emerald-400 mb-1">Published Live</div>
          <div className="text-2xl font-black text-emerald-300 font-display tabular-nums">
            {articles.filter(a => a.status === 'published').length}
          </div>
        </div>

        <div className="p-4 rounded-xl glass-panel border border-amber-500/20">
          <div className="text-xs text-amber-400 mb-1">Drafts (Private)</div>
          <div className="text-2xl font-black text-amber-300 font-display tabular-nums">
            {articles.filter(a => a.status === 'draft').length}
          </div>
        </div>

        <div className="p-4 rounded-xl glass-panel border border-amber-500/20 flex items-center gap-3">
          <img
            src="/src/assets/images/ishaq_turk_suit_exact_1790364183317.jpg"
            alt="Ishaq Turk"
            className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/40 shrink-0"
          />
          <div className="min-w-0">
            <div className="text-xs text-slate-400 mb-0.5">Author</div>
            <div className="text-sm font-bold text-white font-display truncate">
              Ishaq Turk
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Controls Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {(['all', 'published', 'draft'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-colors ${
                filterStatus === status
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-slate-400 hover:text-white bg-slate-900'
              }`}
            >
              {status}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filter by title, category..."
            className="bg-slate-900 border border-amber-500/20 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 w-full sm:w-60"
          />

          <button
            onClick={handleExportJSON}
            title="Download articles.json backup"
            className="p-2 bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/20 rounded-lg text-xs"
          >
            <Download className="w-4 h-4" />
          </button>

          <label
            title="Import articles.json"
            className="p-2 bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/20 rounded-lg text-xs cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
          </label>

          <button
            onClick={handleResetDefaults}
            title="Reset to seed demo articles"
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700 rounded-lg text-xs"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Articles Management Table */}
      <div className="rounded-2xl glass-panel border border-amber-500/20 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-amber-500/15 text-slate-400 uppercase tracking-wider font-semibold">
              <tr>
                <th className="py-3.5 px-4">Headline / Topic</th>
                <th className="py-3.5 px-4">Subject</th>
                <th className="py-3.5 px-4">Type</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-950/60">
              {filteredArticles.map((article) => {
                const isPublished = article.status === 'published';
                const formattedDate = new Date(article.publishedAt).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                });

                return (
                  <tr key={article.id} className="hover:bg-amber-950/20 transition-colors">
                    <td className="py-3 px-4 max-w-xs sm:max-w-md">
                      <div className="font-bold text-white line-clamp-1 mb-0.5">
                        {article.title}
                      </div>
                      <div className="text-slate-400 text-[11px] line-clamp-1">
                        {article.subtitle || article.summary}
                      </div>
                    </td>
                    <td className="py-3 px-4 capitalize text-slate-300 font-medium">
                      {article.category}
                    </td>
                    <td className="py-3 px-4">
                      <span className="uppercase text-[11px] font-bold text-amber-400">
                        {article.type}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          isPublished
                            ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/30'
                            : 'bg-amber-950/80 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {isPublished ? 'Published' : 'Draft'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                      {formattedDate}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Toggle Publish / Unpublish */}
                        <button
                          onClick={() => handleTogglePublish(article)}
                          title={isPublished ? 'Unpublish (hide from public)' : 'Publish immediately'}
                          className={`p-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                            isPublished
                              ? 'bg-slate-900 border-amber-500/30 text-amber-400 hover:bg-amber-950/50'
                              : 'bg-emerald-950/80 border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/60'
                          }`}
                        >
                          {isPublished ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>

                        {/* Edit */}
                        <button
                          onClick={() => handleOpenEditor(article)}
                          title="Edit article"
                          className="p-1.5 rounded-lg bg-slate-900 border border-amber-500/20 text-amber-300 hover:bg-slate-800"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        {/* View Live (if published) */}
                        {isPublished && (
                          <button
                            onClick={() => onNavigate({ type: 'article', slug: article.slug })}
                            title="Preview story"
                            className="p-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Delete */}
                        <button
                          onClick={() => handleDelete(article)}
                          title="Delete article"
                          className="p-1.5 rounded-lg bg-slate-900 border border-rose-500/20 text-rose-400 hover:bg-rose-950/50"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredArticles.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    No articles found matching criteria. Click "Create Story" to draft a new piece.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Editor Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="w-full max-w-4xl bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-amber-500/20 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-400" />
                <h2 className="text-lg font-bold uppercase text-white font-display">
                  {editingArticleId ? 'Edit Article' : 'Write New Story'}
                </h2>
              </div>
              <button
                onClick={() => setIsEditing(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg text-sm font-bold"
              >
                ✕
              </button>
            </div>

            {/* Modal Form Body */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              {/* Title & Subtitle */}
              <div>
                <label className="block font-semibold text-slate-200 mb-1">
                  Headline <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="Enter strong, compelling headline..."
                  className="w-full bg-slate-950 border border-amber-500/25 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-200 mb-1">Subtitle / Deck</label>
                <input
                  type="text"
                  value={formSubtitle}
                  onChange={(e) => setFormSubtitle(e.target.value)}
                  placeholder="Secondary deck providing immediate context..."
                  className="w-full bg-slate-950 border border-amber-500/25 rounded-lg px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Category & Type & Author */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-200 mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as Category)}
                    className="w-full bg-slate-950 border border-amber-500/25 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="sindh">Sindh</option>
                    <option value="pakistan">Pakistan</option>
                    <option value="world">World</option>
                    <option value="geopolitics">Geopolitics</option>
                    <option value="technology">Technology</option>
                    <option value="opinion">Opinion</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-200 mb-1">Article Type</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as ArticleType)}
                    className="w-full bg-slate-950 border border-amber-500/25 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="news">News (Factual & Sourced)</option>
                    <option value="analysis">Analysis (Context & Structure)</option>
                    <option value="opinion">Opinion (Personal Commentary)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-200 mb-1">Author Name</label>
                  <input
                    type="text"
                    value={formAuthor}
                    onChange={(e) => setFormAuthor(e.target.value)}
                    className="w-full bg-slate-950 border border-amber-500/25 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Featured Image */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-amber-500/20 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-amber-400" />
                    Featured Image
                  </span>
                  <label className="text-amber-400 hover:text-amber-300 cursor-pointer font-semibold underline">
                    <span>Upload image from computer/phone</span>
                    <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Image URL</label>
                    <input
                      type="text"
                      value={formImageUrl}
                      onChange={(e) => setFormImageUrl(e.target.value)}
                      placeholder="Image URL or preset path..."
                      className="w-full bg-slate-900 border border-amber-500/20 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Image Caption / Credit</label>
                    <input
                      type="text"
                      value={formImageCaption}
                      onChange={(e) => setFormImageCaption(e.target.value)}
                      placeholder="e.g. Delegates gather during regional maritime talks."
                      className="w-full bg-slate-900 border border-amber-500/20 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* Image preview thumbnail */}
                {formImageUrl && (
                  <div className="flex items-center gap-3 pt-1">
                    <img
                      src={formImageUrl}
                      alt="Preview"
                      className="w-24 h-16 object-cover rounded-lg border border-amber-500/30"
                    />
                    <div className="text-[11px] text-slate-400">
                      Thumbnail preview. Responsive across mobile and desktop.
                    </div>
                  </div>
                )}
              </div>

              {/* Summary */}
              <div>
                <label className="block font-semibold text-slate-200 mb-1">Short Summary (for homepage cards)</label>
                <textarea
                  rows={2}
                  value={formSummary}
                  onChange={(e) => setFormSummary(e.target.value)}
                  placeholder="A concise 2-sentence summary that appears on cards..."
                  className="w-full bg-slate-950 border border-amber-500/25 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Article Content with Markdown formatting helpers */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-semibold text-slate-200">
                    Article Body <span className="text-rose-400">*</span>
                  </label>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setPreviewTab('write')}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold ${
                        previewTab === 'write' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Editor
                    </button>
                    <button
                      type="button"
                      onClick={() => setPreviewTab('preview')}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold ${
                        previewTab === 'preview' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Live Preview
                    </button>
                  </div>
                </div>

                {previewTab === 'write' ? (
                  <div>
                    {/* Formatting toolbar helpers */}
                    <div className="bg-slate-950/80 border border-amber-500/20 border-b-0 rounded-t-lg p-1.5 flex flex-wrap items-center gap-1 text-[11px]">
                      <button
                        type="button"
                        onClick={() => setFormContent(prev => prev + '\n\n## Section Heading\n')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded"
                      >
                        H2
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormContent(prev => prev + '\n\n### Subheading\n')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded"
                      >
                        H3
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormContent(prev => prev + ' **bold text** ')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-bold"
                      >
                        B
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormContent(prev => prev + ' *italic text* ')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded italic"
                      >
                        I
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormContent(prev => prev + '\n\n> "Important quote here"\n')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded"
                      >
                        Quote
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormContent(prev => prev + '\n* Bullet point 1\n* Bullet point 2\n')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded"
                      >
                        • List
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormContent(prev => prev + ' [Link Title](https://example.com) ')}
                        className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded"
                      >
                        🔗 Link
                      </button>
                    </div>
                    <textarea
                      rows={10}
                      required
                      value={formContent}
                      onChange={(e) => setFormContent(e.target.value)}
                      placeholder="Write your article in Markdown. Supports paragraphs, headings, bullet lists, quotes, and links..."
                      className="w-full bg-slate-950 border border-amber-500/25 rounded-b-lg p-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-mono leading-relaxed"
                    />
                  </div>
                ) : (
                  <div className="p-4 rounded-lg bg-slate-950 border border-amber-500/25 min-h-[220px] max-h-[350px] overflow-y-auto article-prose text-xs">
                    <p className="text-slate-400 italic mb-2">[Rendered Article Preview]</p>
                    <div className="whitespace-pre-wrap">{formContent}</div>
                  </div>
                )}
              </div>

              {/* Sources Section */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-amber-500/20">
                <div className="font-semibold text-slate-200 mb-2">Sources & Verifiable Citations</div>
                <div className="flex flex-col sm:flex-row gap-2 mb-2">
                  <input
                    type="text"
                    value={newSourceName}
                    onChange={(e) => setNewSourceName(e.target.value)}
                    placeholder="Source Document / Publication Name"
                    className="flex-1 bg-slate-900 border border-amber-500/20 rounded px-2.5 py-1.5 text-xs text-white"
                  />
                  <input
                    type="url"
                    value={newSourceUrl}
                    onChange={(e) => setNewSourceUrl(e.target.value)}
                    placeholder="https://..."
                    className="flex-1 bg-slate-900 border border-amber-500/20 rounded px-2.5 py-1.5 text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={handleAddSource}
                    className="px-3 py-1.5 bg-amber-700 hover:bg-amber-600 text-white rounded text-xs font-semibold"
                  >
                    Add Source
                  </button>
                </div>

                {formSources.length > 0 && (
                  <ul className="space-y-1">
                    {formSources.map((s, idx) => (
                      <li key={idx} className="flex items-center justify-between text-[11px] bg-slate-900/60 px-2 py-1 rounded">
                        <span className="text-slate-200">{s.name} ({s.url})</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveSource(idx)}
                          className="text-rose-400 hover:text-rose-300 ml-2"
                        >
                          ✕
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Tags & Highlights Checkboxes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block font-semibold text-slate-200 mb-1">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={formTags}
                    onChange={(e) => setFormTags(e.target.value)}
                    placeholder="Sindh, Geopolitics, Economy..."
                    className="w-full bg-slate-950 border border-amber-500/20 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>

                <div className="flex flex-col justify-end gap-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsFeatured}
                      onChange={(e) => setFormIsFeatured(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-400"
                    />
                    <span className="text-slate-200">Set as Homepage Lead Story (Featured)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formIsTrending}
                      onChange={(e) => setFormIsTrending(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-400"
                    />
                    <span className="text-slate-200">Include in Trending (01-05) Bar</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Modal Actions Footer */}
            <div className="p-4 sm:p-5 border-t border-amber-500/20 bg-slate-950/80 flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveArticle('draft')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save as Draft</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveArticle('published')}
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold uppercase tracking-wider shadow-lg shadow-amber-950/60 flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Publish Now</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
