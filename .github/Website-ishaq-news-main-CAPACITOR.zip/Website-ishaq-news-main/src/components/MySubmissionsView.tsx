import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { firebaseData } from '../services/firebaseDataService';
import { Article, ViewRoute } from '../types';
import { ProfileModal } from './ProfileModal';
import { Plus, Camera, FileText, User } from 'lucide-react';

interface MySubmissionsViewProps {
  onNavigate: (route: ViewRoute) => void;
}

export const MySubmissionsView: React.FC<MySubmissionsViewProps> = ({ onNavigate }) => {
  const { currentUser, userProfile, isRegistered, isAdmin } = useAuth();
  const [submissions, setSubmissions] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  useEffect(() => {
    if (currentUser) {
      loadSubmissions();
    } else {
      setLoading(false);
    }
  }, [currentUser]);

  const loadSubmissions = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const list = await firebaseData.getUserSubmissions(currentUser.uid);
      setSubmissions(list);
    } catch (err) {
      console.error('Error loading submissions:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!isRegistered || !currentUser) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
        <div className="max-w-md w-full p-8 rounded-2xl bg-[#141517] border border-[#2a2723] text-center shadow-2xl">
          <p className="text-[10px] font-serif uppercase tracking-[0.25em] text-amber-400 font-bold mb-1">
            Author & Reader Account
          </p>
          <h2 className="text-2xl font-serif font-bold text-[#f4efe6]">My Submissions</h2>
          <p className="text-xs text-[#a39e93] mt-2 font-serif">
            Please log in with your reader account to view your pitch history and editorial status.
          </p>
          <button
            onClick={() => onNavigate({ type: 'login' })}
            className="mt-6 w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const userAvatar =
    userProfile?.photoURL ||
    currentUser?.photoURL ||
    (isAdmin ? '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg' : null);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Contributor Profile Card Banner */}
      <div className="p-6 rounded-2xl bg-[#141517] border border-[#2a2723] shadow-xl mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
        <div className="flex items-center gap-4">
          <div className="relative group shrink-0">
            <div className="w-16 h-16 rounded-full overflow-hidden ring-2 ring-amber-500/50 shadow-lg bg-[#0c0d0e] flex items-center justify-center">
              {userAvatar ? (
                <img
                  src={userAvatar}
                  alt={userProfile?.name || 'User'}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
                  }}
                />
              ) : (
                <User className="w-8 h-8 text-[#736e64]" />
              )}
            </div>
            <button
              onClick={() => setIsProfileModalOpen(true)}
              title="Change Profile Photo"
              className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-md ring-2 ring-[#0c0d0e] transition-all cursor-pointer"
            >
              <Camera className="w-3 h-3" />
            </button>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-serif font-bold text-[#f4efe6]">
                {userProfile?.name || currentUser.displayName || 'Reader Contributor'}
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-serif uppercase tracking-widest bg-amber-500/15 text-amber-300 border border-amber-500/30">
                {userProfile?.role || 'user'}
              </span>
            </div>
            <p className="text-xs text-[#a39e93] font-serif mt-0.5">
              {currentUser.email}
            </p>
            {userProfile?.bio && (
              <p className="text-xs text-[#c4beaf] italic font-serif mt-1 line-clamp-1">
                "{userProfile.bio}"
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto">
          <button
            onClick={() => setIsProfileModalOpen(true)}
            className="flex-1 sm:flex-initial py-2.5 px-4 rounded-xl bg-[#1b1c1e] hover:bg-[#25272c] border border-[#2e2b26] text-amber-300 font-serif font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Camera className="w-3.5 h-3.5 text-amber-400" />
            <span>Change PFP / Bio</span>
          </button>
          <button
            onClick={() => onNavigate({ type: 'submit-article' })}
            className="flex-1 sm:flex-initial py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs tracking-wider uppercase transition-all shadow-md shadow-amber-950/40 cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Submit Piece</span>
          </button>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-2xl font-serif font-bold text-[#f4efe6] tracking-tight">
          Submissions History
        </h3>
        <p className="text-xs text-[#a39e93] mt-1 font-serif">
          Track the real-time review status of your investigative pieces, opinion columns, and field dispatches.
        </p>
      </div>

      {loading ? (
        <div className="py-20 text-center">
          <div className="inline-block w-8 h-8 border-2 border-amber-400 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs text-[#a39e93] uppercase tracking-widest font-serif">Loading submissions from Firestore...</p>
        </div>
      ) : submissions.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-[#141517] border border-[#2a2723]">
          <FileText className="w-12 h-12 text-amber-400/40 mx-auto mb-3" />
          <h3 className="text-xl font-serif font-bold text-[#f4efe6]">No articles submitted yet</h3>
          <p className="text-xs text-[#a39e93] max-w-sm mx-auto mt-2 leading-relaxed font-serif">
            Have an investigation, local reporting insight from Sindh, or policy perspective to share? Pitch your piece to the editorial board.
          </p>
          <button
            onClick={() => onNavigate({ type: 'submit-article' })}
            className="mt-6 py-2.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider transition-all"
          >
            Start First Submission
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {submissions.map((sub) => (
            <div
              key={sub.id}
              className="p-6 rounded-2xl bg-[#141517] border border-[#2a2723] hover:border-[#38332c] transition-all flex flex-col md:flex-row md:items-center justify-between gap-5 shadow-xl"
            >
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-serif uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#1e1f23] text-amber-300 border border-amber-500/20">
                    {sub.category}
                  </span>
                  <span className="text-[11px] text-[#736e64] font-serif">
                    Submitted: {new Date(sub.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <h3 className="text-xl font-serif font-bold text-[#f4efe6] leading-snug">
                  {sub.title}
                </h3>
                <p className="text-xs text-[#a39e93] line-clamp-2 font-serif">{sub.summary}</p>

                {sub.status === 'rejected' && sub.rejectionReason && (
                  <div className="mt-3 p-3.5 rounded-xl bg-red-950/40 border border-red-800/60 text-xs text-red-200">
                    <span className="font-bold block mb-0.5">Editorial Feedback:</span>
                    {sub.rejectionReason}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-serif font-bold uppercase tracking-wider ${
                    sub.status === 'published'
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      : sub.status === 'pending'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : sub.status === 'rejected'
                      ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                      : 'bg-[#1e1f23] text-[#a39e93] border border-[#2a2723]'
                  }`}
                >
                  {sub.status === 'published'
                    ? '✓ Published'
                    : sub.status === 'pending'
                    ? '⏳ In Review'
                    : sub.status === 'rejected'
                    ? '✕ Needs Revision'
                    : 'Draft'}
                </span>

                {sub.status === 'published' && (
                  <button
                    onClick={() => onNavigate({ type: 'article', slug: sub.slug || sub.id })}
                    className="py-1.5 px-3 rounded-lg bg-[#1f2023] hover:bg-[#27292e] text-xs text-amber-300 font-serif font-semibold border border-[#33302a] transition-colors"
                  >
                    View Public Post →
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Profile & Avatar Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </div>
  );
};
