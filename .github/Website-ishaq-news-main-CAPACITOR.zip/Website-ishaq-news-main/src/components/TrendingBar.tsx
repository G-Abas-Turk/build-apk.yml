import React from 'react';
import { Article } from '../types';
import { TrendingUp, Clock } from 'lucide-react';

interface TrendingBarProps {
  articles: Article[];
  onSelectArticle: (slug: string) => void;
}

export const TrendingBar: React.FC<TrendingBarProps> = ({ articles, onSelectArticle }) => {
  if (!articles || articles.length === 0) return null;

  return (
    <section className="my-12 relative">
      <div className="flex items-center gap-2 mb-4 text-xs font-semibold uppercase tracking-widest text-[#d4af37]">
        <TrendingUp className="w-4 h-4 text-[#d4af37]" />
        <span>Trending Briefings</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
        {articles.slice(0, 5).map((article, index) => {
          const rank = String(index + 1).padStart(2, '0');
          const author = article.authorName || article.author || 'Ishaq Turk';
          return (
            <div
              key={article.id}
              onClick={() => onSelectArticle(article.slug || article.id)}
              className="group cursor-pointer p-4 rounded-xl glass-panel glass-panel-hover flex flex-col justify-between border border-[#d4af37]/15"
            >
              <div>
                <span className="text-2xl font-bold font-display text-[#d4af37]/35 group-hover:text-[#d4af37] transition-colors tabular-nums">
                  {rank}
                </span>
                <div className="flex items-center gap-1.5 text-[11px] text-[#8c887e] mt-2 mb-1.5">
                  <span className="uppercase text-[#d4af37] font-semibold">{article.type}</span>
                  <span aria-hidden="true" className="text-[#524e47]">·</span>
                  <span className="capitalize">{article.category}</span>
                </div>
                <h4 className="text-sm font-bold text-[#f5f2eb] group-hover:text-[#f3e7b8] transition-colors line-clamp-3 leading-snug font-display">
                  {article.title}
                </h4>
              </div>

              <div className="mt-3 pt-2 border-t border-[#292723] flex items-center justify-between text-[11px] text-[#8c887e]">
                <span className="truncate max-w-[100px]">{author}</span>
                <span className="flex items-center gap-1 shrink-0 text-[#a09a8e]">
                  <Clock className="w-3 h-3 text-[#d4af37]" />
                  {article.readTime}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
