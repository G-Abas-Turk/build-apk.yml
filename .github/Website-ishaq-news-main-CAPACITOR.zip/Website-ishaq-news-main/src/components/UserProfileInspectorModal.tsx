import React, { useState, useEffect } from 'react';
import { UserProfile, Article, FeedPost } from '../types';
import { firebaseData } from '../services/firebaseDataService';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import {
  X,
  Check,
  ShieldAlert,
  FileText,
  MessageSquare,
  Calendar,
  Mail,
  User,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

interface UserProfileInspectorModalProps {
  user: UserProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectArticle?: (slug: string) => void;
}

export const UserProfileInspectorModal: React.FC<UserProfileInspectorModalProps> = ({
  user,
  isOpen,
  onClose,
  onSelectArticle,
}) => {
  const { isAdmin, toggleVerifiedBadge } = useAuth();
  const { addToast } = useToast();

  const [articles, setArticles] = useState<Article[]>([]);
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [totalUploads, setTotalUploads] = useState(0);
  const [loading, setLoading] = useState(true);
  const [togglingBadge, setTogglingBadge] = useState(false);
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    if (user && isOpen) {
      setIsVerified(!!user.isVerified);
      loadUploads(user.uid);
    }
  }, [user, isOpen]);

  const loadUploads = async (uid: string) => {
    setLoading(true);
    try {
      const data = await firebaseData.getUserUploads(uid);
      setArticles(data.articles);
      setPosts(data.posts);
      setTotalUploads(data.totalUploads);
    } catch (err) {
      console.error('Error fetching user uploads:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleBadge = async () => {
    if (!user || !isAdmin) return;
    try {
      setTogglingBadge(true);
      const nextStatus = !isVerified;
      await toggleVerifiedBadge(user.uid, nextStatus);
      setIsVerified(nextStatus);
      addToast({
        type: 'success',
        title: nextStatus ? 'Blue Tick Granted' : 'Blue Tick Revoked',
        message: nextStatus
          ? `${user.name} now has the verified blue tick badge across the platform.`
          : `Verified status removed for ${user.name}.`,
      });
    } catch (err: any) {
      addToast({ type: 'error', title: 'Action failed', message: err.message });
    } finally {
      setTogglingBadge(false);
    }
  };

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723] rounded-2xl shadow-2xl p-6 sm:p-8 animate-in fade-in duration-200 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-[#22211e] mb-6">
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold font-display uppercase text-slate-900 dark:text-white">
              User Profile & Activity Inspector
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Profile Card */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 p-5 rounded-2xl bg-slate-50 dark:bg-[#0c0d0e] border border-slate-200 dark:border-[#22211e] mb-6">
          <div className="relative shrink-0">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.name}
                className="w-20 h-20 rounded-full object-cover ring-2 ring-amber-500/40 shadow-md"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center text-2xl font-bold font-display ring-2 ring-amber-500/40">
                {user.name?.charAt(0) || 'U'}
              </div>
            )}
            {isVerified && (
              <span
                className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-sky-500 text-white flex items-center justify-center ring-2 ring-white dark:ring-[#0c0d0e] shadow-sm"
                title="Verified Account"
              >
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </span>
            )}
          </div>

          <div className="flex-1 text-center sm:text-left space-y-1">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white font-display">
                {user.name}
              </h2>
              {isVerified && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30">
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                  Verified Blue Tick
                </span>
              )}
              <span
                className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                  user.role === 'admin'
                    ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/40'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                {user.role}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs text-slate-500 dark:text-[#a09a8e] pt-1">
              <span className="inline-flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5" />
                {user.email}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                Registered {new Date(user.createdAt).toLocaleDateString()}
              </span>
            </div>

            {/* Admin Blue Tick Control */}
            {isAdmin && (
              <div className="pt-3">
                <button
                  onClick={handleToggleBadge}
                  disabled={togglingBadge}
                  className={`py-1.5 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-sm ${
                    isVerified
                      ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-500/40 text-rose-700 dark:text-rose-300 hover:bg-rose-100'
                      : 'bg-sky-500 hover:bg-sky-400 text-white'
                  }`}
                >
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                  <span>
                    {togglingBadge
                      ? 'Updating...'
                      : isVerified
                      ? 'Revoke Blue Tick'
                      : 'Grant Verified Blue Tick'}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Uploads Statistics Counters */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#0c0d0e] border border-slate-200 dark:border-[#22211e] text-center">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-[#8e8a80] uppercase tracking-wider block mb-1">
              Total Uploads
            </span>
            <span className="text-2xl font-black text-amber-600 dark:text-amber-400 font-display">
              {loading ? '...' : totalUploads === 0 ? 'None' : totalUploads}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#0c0d0e] border border-slate-200 dark:border-[#22211e] text-center">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-[#8e8a80] uppercase tracking-wider block mb-1">
              Articles
            </span>
            <span className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {loading ? '...' : articles.length === 0 ? 'None' : articles.length}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#0c0d0e] border border-slate-200 dark:border-[#22211e] text-center">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-[#8e8a80] uppercase tracking-wider block mb-1">
              Feed Posts
            </span>
            <span className="text-2xl font-black text-slate-900 dark:text-white font-display">
              {loading ? '...' : posts.length === 0 ? 'None' : posts.length}
            </span>
          </div>
        </div>

        {/* Uploaded Items List */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-[#a09a8e] mb-3">
            Uploaded Content by {user.name} ({totalUploads})
          </h4>

          {loading ? (
            <div className="py-8 text-center text-xs text-slate-400">Loading uploads...</div>
          ) : totalUploads === 0 ? (
            <div className="p-6 rounded-xl border border-dashed border-slate-300 dark:border-[#2a2723] text-center text-xs text-slate-500">
              This user has not uploaded any articles or news posts yet.
            </div>
          ) : (
            <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
              {/* Articles */}
              {articles.map((art) => (
                <div
                  key={art.id}
                  className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#0c0d0e] border border-slate-200 dark:border-[#22211e] flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-amber-500 shrink-0" />
                    <div>
                      <h5 className="font-bold text-slate-900 dark:text-white line-clamp-1">{art.title}</h5>
                      <span className="text-[10px] text-slate-500">
                        Article · {art.category} · Status: <strong>{art.status}</strong>
                      </span>
                    </div>
                  </div>
                  {onSelectArticle && (
                    <button
                      onClick={() => {
                        onClose();
                        onSelectArticle(art.slug || art.id);
                      }}
                      className="p-1.5 text-slate-400 hover:text-amber-500 cursor-pointer"
                      title="View Article"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}

              {/* Feed posts */}
              {posts.map((post) => (
                <div
                  key={post.id}
                  className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#0c0d0e] border border-slate-200 dark:border-[#22211e] flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <MessageSquare className="w-4 h-4 text-blue-500 shrink-0" />
                    <div>
                      <p className="font-medium text-slate-800 dark:text-slate-200 line-clamp-1">{post.content}</p>
                      <span className="text-[10px] text-slate-500">
                        Feed Dispatch · {post.postType} · {post.likesCount || 0} likes
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
