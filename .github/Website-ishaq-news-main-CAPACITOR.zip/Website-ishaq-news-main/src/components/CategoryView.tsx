import React, { useState, useEffect } from 'react';
import { Article, ArticleType, ViewRoute } from '../types';
import { firebaseData } from '../services/firebaseDataService';
import { ArticleCard } from './ArticleCard';
import { MapPin, Landmark, Globe, Compass, Cpu, MessageSquareQuote, ArrowLeft } from 'lucide-react';

interface CategoryViewProps {
  category: string;
  onNavigate: (route: ViewRoute) => void;
}

export const CategoryView: React.FC<CategoryViewProps> = ({ category, onNavigate }) => {
  const [typeFilter, setTypeFilter] = useState<'all' | ArticleType>('all');
  const [displayCount, setDisplayCount] = useState<number>(8);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    firebaseData.getPublishedArticles().then((all) => {
      if (!isMounted) return;
      const matched = all.filter((a) => a.category.toLowerCase() === category.toLowerCase());
      setArticles(matched);
      setLoading(false);
    });

    return () => {
      isMounted = false;
    };
  }, [category]);

  const categoryMeta: Record<string, { title: string; subtitle: string; icon: React.ReactNode }> = {
    sindh: {
      title: 'Sindh News & Culture',
      subtitle: 'Comprehensive regional reporting covering Hyderabad, Karachi, Matiari, agrarian reforms, local politics, and cultural heritage across Sindh.',
      icon: <MapPin className="w-8 h-8 text-[#d4af37]" />
    },
    pakistan: {
      title: 'Pakistan National Affairs',
      subtitle: 'In-depth coverage of Pakistan’s economy, governance, energy infrastructure, security developments, and technological modernization.',
      icon: <Landmark className="w-8 h-8 text-[#e5c46b]" />
    },
    world: {
      title: 'World & International Affairs',
      subtitle: 'Global reporting on multilateral institutions, diplomatic summits, major continental shifts, and cross-border environmental and economic policies.',
      icon: <Globe className="w-8 h-8 text-[#d4af37]" />
    },
    geopolitics: {
      title: 'Geopolitics & Strategy',
      subtitle: 'Rigorous strategic analysis of international corridors, naval choke points, middle-power alignments, defense doctrines, and global security shifts.',
      icon: <Compass className="w-8 h-8 text-[#f5e6b3]" />
    },
    technology: {
      title: 'Technology & Computing',
      subtitle: 'Frontier insights into artificial intelligence, sovereign silicon, distributed networks, space missions, and computational infrastructure.',
      icon: <Cpu className="w-8 h-8 text-[#d4af37]" />
    },
    opinion: {
      title: 'Opinion & Analysis',
      subtitle: 'Thoughtful commentary, reflective essays, and deep personal perspectives on the forces shaping modern society and international affairs.',
      icon: <MessageSquareQuote className="w-8 h-8 text-[#e5c46b]" />
    }
  };

  const currentMeta = categoryMeta[category] || {
    title: `${category.toUpperCase()} Dispatch`,
    subtitle: `Live articles filed under ${category}.`,
    icon: <Globe className="w-8 h-8 text-[#d4af37]" />
  };

  const filteredArticles = typeFilter === 'all'
    ? articles
    : articles.filter(a => a.type === typeFilter);

  const featuredStory = filteredArticles[0];
  const remainingStories = filteredArticles.slice(1, displayCount);
  const hasMore = filteredArticles.length > displayCount;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      <button
        onClick={() => onNavigate({ type: 'home' })}
        className="inline-flex items-center gap-2 text-xs font-semibold text-[#8c887e] hover:text-[#f5e6b3] transition-colors uppercase tracking-wider mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Return to Headlines</span>
      </button>

      <div className="p-8 rounded-2xl glass-panel border border-[#d4af37]/20 mb-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            {currentMeta.icon}
            <h1 className="text-3xl sm:text-4xl font-black text-white font-display uppercase tracking-tight">
              {currentMeta.title}
            </h1>
          </div>
          <p className="text-sm text-[#b8b3a7] max-w-3xl leading-relaxed font-editorial">
            {currentMeta.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-1 bg-[#141412] p-1 rounded-xl border border-[#2b2825] text-xs">
          {(['all', 'news', 'analysis', 'opinion'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setTypeFilter(filter)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-colors cursor-pointer ${
                typeFilter === filter
                  ? 'bg-[#d4af37] text-[#0c0d0e] font-bold'
                  : 'text-[#8c887e] hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="py-20 text-center">
          <div className="inline-block w-8 h-8 border-2 border-[#d4af37] border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs text-[#a09a8e] uppercase tracking-widest">Loading {category} dispatches from Firestore...</p>
        </div>
      ) : filteredArticles.length === 0 ? (
        <div className="py-20 text-center rounded-2xl glass-panel border border-[#2b2825]">
          <p className="text-sm text-[#8c887e]">No published articles in this category format yet.</p>
          <button
            onClick={() => onNavigate({ type: 'submit-article' })}
            className="mt-4 px-4 py-2 bg-[#d4af37] hover:bg-[#b89528] text-[#0c0d0e] rounded-xl text-xs font-bold uppercase tracking-wider"
          >
            Be the First to Submit
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          {featuredStory && (
            <div className="mb-8">
              <span className="text-[11px] font-bold text-[#d4af37] uppercase tracking-widest block mb-2">
                Featured in this Section
              </span>
              <ArticleCard
                article={featuredStory as any}
                onClick={() => onNavigate({ type: 'article', slug: featuredStory.slug || featuredStory.id })}
                variant="horizontal"
              />
            </div>
          )}

          {remainingStories.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {remainingStories.map((story) => (
                <ArticleCard
                  key={story.id}
                  article={story as any}
                  onClick={() => onNavigate({ type: 'article', slug: story.slug || story.id })}
                  variant="standard"
                />
              ))}
            </div>
          )}

          {hasMore && (
            <div className="text-center pt-8">
              <button
                onClick={() => setDisplayCount((prev) => prev + 6)}
                className="py-3 px-8 rounded-xl bg-[#1a1918] hover:bg-[#252320] border border-[#2b2825] text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                Load More Stories
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
