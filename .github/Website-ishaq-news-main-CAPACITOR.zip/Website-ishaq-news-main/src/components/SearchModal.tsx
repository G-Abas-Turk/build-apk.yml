import React, { useState, useEffect, useRef } from 'react';
import { Article } from '../types';
import { firebaseData } from '../services/firebaseDataService';
import { Search, X, Clock, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectArticle: (slug: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectArticle
}) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [allArticles, setAllArticles] = useState<Article[]>([]);
  const [results, setResults] = useState<Article[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      firebaseData.getPublishedArticles().then((arts) => {
        setAllArticles(arts);
        filterArticles(arts, query, selectedCategory);
      });
    } else {
      setQuery('');
      setSelectedCategory('all');
    }
  }, [isOpen]);

  const filterArticles = (source: Article[], q: string, cat: string) => {
    let filtered = source;
    if (cat !== 'all') {
      filtered = filtered.filter((a) => a.category.toLowerCase() === cat.toLowerCase());
    }

    if (q.trim()) {
      const lower = q.toLowerCase();
      filtered = filtered.filter((a) =>
        a.title.toLowerCase().includes(lower) ||
        a.summary.toLowerCase().includes(lower) ||
        (a.tags && a.tags.some((t) => t.toLowerCase().includes(lower)))
      );
    }

    setResults(filtered.slice(0, 10));
  };

  useEffect(() => {
    if (isOpen) {
      filterArticles(allArticles, query, selectedCategory);
    }
  }, [query, selectedCategory, isOpen, allArticles]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const categories: Array<{ id: string; label: string }> = [
    { id: 'all', label: 'All Subjects' },
    { id: 'sindh', label: 'Sindh' },
    { id: 'pakistan', label: 'Pakistan' },
    { id: 'world', label: 'World' },
    { id: 'geopolitics', label: 'Geopolitics' },
    { id: 'technology', label: 'Technology' },
    { id: 'opinion', label: 'Opinion' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-2xl bg-[#141412] border border-[#d4af37]/30 rounded-2xl shadow-2xl overflow-hidden text-[#e6e2d8] flex flex-col max-h-[80vh]"
        role="dialog"
        aria-modal="true"
      >
        <div className="p-4 border-b border-[#292723] flex items-center gap-3">
          <Search className="w-5 h-5 text-[#d4af37] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search investigative stories, Sindh affairs, geopolitics..."
            className="w-full bg-transparent text-sm sm:text-base text-white placeholder-[#706c62] focus:outline-none"
          />
          {query && (
            <button 
              onClick={() => setQuery('')}
              className="text-[#a09a8e] hover:text-white p-1 text-xs cursor-pointer"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#a09a8e] hover:text-white hover:bg-[#252320] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-4 py-2.5 bg-[#0c0d0e]/60 border-b border-[#292723] flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-[#d4af37] text-[#0c0d0e] font-bold'
                  : 'text-[#8c887e] hover:text-white hover:bg-[#252320]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="p-4 overflow-y-auto flex-1 divide-y divide-[#232220]">
          {results.length === 0 ? (
            <div className="py-12 text-center text-[#8c887e]">
              <p className="text-sm">No stories match your criteria.</p>
              <p className="text-xs text-[#706c62] mt-1">Try broader terms or select another subject category.</p>
            </div>
          ) : (
            results.map((article) => (
              <div
                key={article.id}
                onClick={() => {
                  onSelectArticle(article.slug || article.id);
                  onClose();
                }}
                className="py-3 px-3 rounded-xl hover:bg-[#1a1918] transition-colors cursor-pointer group flex items-start justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-[#d4af37] px-1.5 py-0.5 rounded bg-[#211f1a] border border-[#d4af37]/20">
                      {article.category}
                    </span>
                    <span className="text-[10px] text-[#8c887e] flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#d4af37]" />
                      {article.readTime}
                    </span>
                  </div>
                  <h4 className="text-sm sm:text-base font-bold text-white group-hover:text-[#f5e6b3] font-display transition-colors">
                    {article.title}
                  </h4>
                  <p className="text-xs text-[#a09a8e] line-clamp-1">{article.summary}</p>
                </div>
                <ArrowRight className="w-4 h-4 text-[#706c62] group-hover:text-[#d4af37] shrink-0 self-center group-hover:translate-x-1 transition-all" />
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
