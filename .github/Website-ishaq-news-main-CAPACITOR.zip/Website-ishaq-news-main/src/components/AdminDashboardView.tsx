import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { firebaseData } from '../services/firebaseDataService';
import { uploadMediaFile } from '../services/storageService';
import { Article, CategoryItem, SiteSettings, UserProfile, ViewRoute } from '../types';
import { ProfileModal } from './ProfileModal';
import { UserProfileInspectorModal } from './UserProfileInspectorModal';
import { Check } from 'lucide-react';

interface AdminDashboardViewProps {
  initialSubSection?: string;
  onNavigate: (route: ViewRoute) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({ initialSubSection, onNavigate }) => {
  const { isAdmin, currentUser, userProfile, signOut, toggleVerifiedBadge } = useAuth();
  const { addToast } = useToast();

  const [activeTab, setActiveTab] = useState<string>(initialSubSection || 'dashboard');
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);

  // Edit / Create modal states
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [inspectingUser, setInspectingUser] = useState<UserProfile | null>(null);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [deleteConfirmArticle, setDeleteConfirmArticle] = useState<Article | null>(null);
  const [rejectModalArticle, setRejectModalArticle] = useState<Article | null>(null);
  const [rejectionReasonText, setRejectionReasonText] = useState('');

  // Article Form State
  const [formTitle, setFormTitle] = useState('');
  const [formSubtitle, setFormSubtitle] = useState('');
  const [formSummary, setFormSummary] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formCategory, setFormCategory] = useState('sindh');
  const [formType, setFormType] = useState<'news' | 'analysis' | 'opinion'>('news');
  const [formStatus, setFormStatus] = useState<'published' | 'pending' | 'draft' | 'rejected'>('published');
  const [formIsFeatured, setFormIsFeatured] = useState(false);
  const [formIsTrending, setFormIsTrending] = useState(false);
  const [formTags, setFormTags] = useState('');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formAuthorName, setFormAuthorName] = useState('Ishaq Turk');
  const [formAuthorRole, setFormAuthorRole] = useState('Founder & Editor');
  const [formImageFile, setFormImageFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [savingArticle, setSavingArticle] = useState(false);

  // Category modal
  const [newCatName, setNewCatName] = useState('');
  const [newCatSlug, setNewCatSlug] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [creatingCategory, setCreatingCategory] = useState(false);

  // Settings State
  const [settingsSiteName, setSettingsSiteName] = useState('');
  const [settingsSiteDesc, setSettingsSiteDesc] = useState('');
  const [settingsAnnouncement, setSettingsAnnouncement] = useState('');
  const [settingsAnnounceActive, setSettingsAnnounceActive] = useState(true);
  const [settingsNotice, setSettingsNotice] = useState('');
  const [settingsContact, setSettingsContact] = useState('');
  const [savingSettings, setSavingSettings] = useState(false);

  // Strict route protection
  useEffect(() => {
    if (!isAdmin) {
      addToast({
        type: 'error',
        title: 'Access Restricted',
        message: 'Only authorized administrators can access this executive console.',
      });
      onNavigate({ type: 'admin-login' });
    }
  }, [isAdmin, onNavigate]);

  useEffect(() => {
    loadAllData();
    const unsubUsers = firebaseData.subscribeToUsers((realtimeUsers) => {
      setUsers(realtimeUsers);
    });
    return () => unsubUsers();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [artList, catList, userList, settings] = await Promise.all([
        firebaseData.getAllArticlesForAdmin(),
        firebaseData.getCategories(),
        firebaseData.getAllUsers(),
        firebaseData.getSiteSettings(),
      ]);

      setArticles(artList);
      setCategories(catList);
      setUsers(userList);
      setSiteSettings(settings);

      // Populate settings form
      setSettingsSiteName(settings.siteName);
      setSettingsSiteDesc(settings.siteDescription);
      setSettingsAnnouncement(settings.announcement || '');
      setSettingsAnnounceActive(settings.announcementActive ?? true);
      setSettingsNotice(settings.heroNotice || '');
      setSettingsContact(settings.contactEmail);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenCreate = () => {
    setEditingArticle(null);
    setFormTitle('');
    setFormSubtitle('');
    setFormSummary('');
    setFormContent('');
    setFormCategory(categories[0]?.slug || 'sindh');
    setFormType('news');
    setFormStatus('published');
    setFormIsFeatured(false);
    setFormIsTrending(false);
    setFormTags('');
    setFormImageUrl('/assets/images/hero_geopolitics_summit_1790362774883.jpg');
    setFormAuthorName('Ishaq Turk');
    setFormAuthorRole('Founder & Editor');
    setFormImageFile(null);
    setIsEditorOpen(true);
  };

  const handleOpenEdit = (art: Article) => {
    setEditingArticle(art);
    setFormTitle(art.title);
    setFormSubtitle(art.subtitle || '');
    setFormSummary(art.summary || '');
    setFormContent(art.content || '');
    setFormCategory(art.category || 'sindh');
    setFormType(art.type || 'news');
    setFormStatus(art.status || 'published');
    setFormIsFeatured(!!art.isFeatured);
    setFormIsTrending(!!art.isTrending);
    setFormTags(art.tags?.join(', ') || '');
    setFormImageUrl(art.imageUrl || '');
    setFormAuthorName(art.authorName || 'Ishaq Turk');
    setFormAuthorRole(art.authorRole || 'Founder & Editor');
    setFormImageFile(null);
    setIsEditorOpen(true);
  };

  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      addToast({ type: 'error', title: 'Missing Information', message: 'Title and content are required.' });
      return;
    }

    try {
      setSavingArticle(true);
      let imgUrl = formImageUrl;

      if (formImageFile) {
        imgUrl = await uploadMediaFile(formImageFile, 'articles', (p) => setUploadProgress(p));
      }

      const tags = formTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      const wordCount = formContent.trim().split(/\s+/).length;
      const readMinutes = Math.max(1, Math.ceil(wordCount / 200));

      if (editingArticle) {
        await firebaseData.updateArticle(editingArticle.id, {
          title: formTitle.trim(),
          subtitle: formSubtitle.trim(),
          summary: formSummary.trim(),
          content: formContent.trim(),
          category: formCategory,
          type: formType,
          status: formStatus,
          isFeatured: formIsFeatured,
          isTrending: formIsTrending,
          tags: tags.length ? tags : [formCategory],
          imageUrl: imgUrl,
          authorName: formAuthorName.trim(),
          authorRole: formAuthorRole.trim(),
          readTime: `${readMinutes} min read`,
        });
        addToast({ type: 'success', title: 'Article Updated', message: 'Changes committed to Firestore.' });
      } else {
        await firebaseData.createArticle({
          title: formTitle.trim(),
          slug: '',
          subtitle: formSubtitle.trim(),
          summary: formSummary.trim(),
          content: formContent.trim(),
          category: formCategory,
          type: formType,
          authorId: currentUser?.uid || 'founder-ishaq-turk',
          authorName: formAuthorName.trim() || 'Ishaq Turk',
          authorEmail: currentUser?.email || 'ishaqturk91@gmail.com',
          authorRole: formAuthorRole.trim() || 'Founder & Editor',
          authorAvatar: '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
          imageUrl: imgUrl,
          readTime: `${readMinutes} min read`,
          tags: tags.length ? tags : [formCategory],
          status: formStatus,
          isFeatured: formIsFeatured,
          isTrending: formIsTrending,
        });
        addToast({ type: 'success', title: 'Article Created', message: 'Published directly into Firestore.' });
      }

      setIsEditorOpen(false);
      await loadAllData();
    } catch (err: any) {
      console.error('Error saving article:', err);
      addToast({ type: 'error', title: 'Save Failed', message: err.message });
    } finally {
      setSavingArticle(false);
      setUploadProgress(null);
    }
  };

  const handleQuickApprove = async (art: Article) => {
    try {
      await firebaseData.approveArticle(art.id);
      addToast({ type: 'success', title: 'Article Approved', message: `"${art.title}" is now published live!` });
      await loadAllData();
    } catch (err: any) {
      addToast({ type: 'error', title: 'Approval Failed', message: err.message });
    }
  };

  const handleOpenReject = (art: Article) => {
    setRejectModalArticle(art);
    setRejectionReasonText('Please verify facts and provide primary sources before resubmitting.');
  };

  const handleConfirmReject = async () => {
    if (!rejectModalArticle) return;
    try {
      await firebaseData.rejectArticle(rejectModalArticle.id, rejectionReasonText);
      addToast({ type: 'info', title: 'Article Rejected', message: 'Author informed of required revisions.' });
      setRejectModalArticle(null);
      await loadAllData();
    } catch (err: any) {
      addToast({ type: 'error', title: 'Rejection Failed', message: err.message });
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteConfirmArticle) return;
    try {
      await firebaseData.deleteArticle(deleteConfirmArticle.id);
      addToast({ type: 'success', title: 'Article Deleted', message: 'Article permanently removed from Firestore.' });
      setDeleteConfirmArticle(null);
      await loadAllData();
    } catch (err: any) {
      addToast({ type: 'error', title: 'Deletion Failed', message: err.message });
    }
  };

  const handleToggleFeatured = async (art: Article) => {
    try {
      await firebaseData.updateArticle(art.id, { isFeatured: !art.isFeatured });
      addToast({
        type: 'info',
        title: !art.isFeatured ? 'Pinned to Featured' : 'Removed from Featured',
      });
      await loadAllData();
    } catch (err: any) {
      addToast({ type: 'error', title: 'Action Failed', message: err.message });
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      setCreatingCategory(true);
      await firebaseData.createCategory({
        name: newCatName.trim(),
        slug: newCatSlug.trim() || newCatName.toLowerCase().replace(/\s+/g, '-'),
        description: newCatDesc.trim(),
        order: categories.length + 1,
      });
      addToast({ type: 'success', title: 'Category Created', message: `Added "${newCatName}" to taxonomy.` });
      setNewCatName('');
      setNewCatSlug('');
      setNewCatDesc('');
      await loadAllData();
    } catch (err: any) {
      addToast({ type: 'error', title: 'Failed to create category', message: err.message });
    } finally {
      setCreatingCategory(false);
    }
  };

  const handleDeleteCategory = async (cat: CategoryItem) => {
    try {
      await firebaseData.deleteCategory(cat.id, cat.slug);
      addToast({ type: 'success', title: 'Category Removed', message: `Deleted ${cat.name}` });
      await loadAllData();
    } catch (err: any) {
      addToast({ type: 'error', title: 'Cannot Delete Category', message: err.message });
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSavingSettings(true);
      await firebaseData.updateSiteSettings({
        siteName: settingsSiteName.trim(),
        siteDescription: settingsSiteDesc.trim(),
        announcement: settingsAnnouncement.trim(),
        announcementActive: settingsAnnounceActive,
        heroNotice: settingsNotice.trim(),
        contactEmail: settingsContact.trim(),
      });
      addToast({ type: 'success', title: 'Settings Saved', message: 'Platform global metadata updated in Firestore.' });
      await loadAllData();
    } catch (err: any) {
      addToast({ type: 'error', title: 'Failed to save settings', message: err.message });
    } finally {
      setSavingSettings(false);
    }
  };

  const pendingArticles = articles.filter((a) => a.status === 'pending');
  const publishedArticles = articles.filter((a) => a.status === 'published');
  const draftArticles = articles.filter((a) => a.status === 'draft');
  const rejectedArticles = articles.filter((a) => a.status === 'rejected');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-200">
      {/* Top Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#2a2723]">
        <div className="flex items-center gap-3.5">
          <div className="relative group shrink-0">
            <img
              src={userProfile?.photoURL || '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg'}
              alt="Ishaq Turk"
              className="w-14 h-14 rounded-2xl object-cover ring-2 ring-amber-400/80 shadow-md shadow-amber-950/40"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
              }}
            />
            <button
              onClick={() => setIsProfileModalOpen(true)}
              title="Change Profile Picture"
              className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-md ring-2 ring-[#0c0d0e] transition-all cursor-pointer"
            >
              <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24">
                <path d="M4 4h3l2-2h6l2 2h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zm8 3a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 2a3 3 0 1 1 0 6 3 3 0 0 1 0-6z" />
              </svg>
            </button>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-white font-display uppercase tracking-tight">
                Editorial Control Room
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest bg-amber-500/20 text-amber-300 border border-amber-500/40">
                Admin
              </span>
            </div>
            <div className="flex items-center gap-3 mt-0.5">
              <p className="text-xs text-[#a39e93] font-serif">
                {userProfile?.name || 'Ishaq Turk'} · News By Ishaq Cloud Firestore
              </p>
              <button
                onClick={() => setIsProfileModalOpen(true)}
                className="text-xs text-amber-400 hover:text-amber-300 underline font-serif cursor-pointer"
              >
                Change Avatar / PFP
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={() => setIsProfileModalOpen(true)}
            className="py-2.5 px-3.5 rounded-xl bg-[#1b1c1e] hover:bg-[#25272c] border border-[#2e2b26] text-amber-300 font-serif font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5"
          >
            <span>Change PFP</span>
          </button>
          <button
            onClick={handleOpenCreate}
            className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider shadow-md shadow-amber-950/40 transition-all cursor-pointer"
          >
            + Compose Article
          </button>
          <button
            onClick={() => onNavigate({ type: 'home' })}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs transition-colors"
          >
            View Site
          </button>
          <button
            onClick={async () => {
              await signOut();
              onNavigate({ type: 'home' });
            }}
            className="py-2.5 px-3.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/60 border border-rose-500/40 text-rose-200 font-medium text-xs transition-colors"
          >
            Exit Portal
          </button>
        </div>
      </div>

      {/* Navigation Sub-sections */}
      <div className="flex items-center gap-1 overflow-x-auto py-4 scrollbar-none border-b border-slate-800/80 text-xs">
        {[
          { id: 'dashboard', label: 'Dashboard', icon: '📊' },
          { id: 'articles', label: `All Articles (${articles.length})`, icon: '📰' },
          { id: 'pending', label: `Pending (${pendingArticles.length})`, icon: '⏳', badge: pendingArticles.length },
          { id: 'published', label: `Published (${publishedArticles.length})`, icon: '✓' },
          { id: 'drafts', label: `Drafts (${draftArticles.length})`, icon: '📝' },
          { id: 'rejected', label: `Rejected (${rejectedArticles.length})`, icon: '✕' },
          { id: 'categories', label: `Taxonomy (${categories.length})`, icon: '📁' },
          { id: 'users', label: `Users (${users.length === 0 ? 'None' : users.length})`, icon: '👥' },
          { id: 'settings', label: 'Site Settings', icon: '⚙️' },
          { id: 'announcements', label: 'Announcements', icon: '📢' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 py-2 px-3.5 rounded-xl font-semibold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
            {tab.badge && tab.badge > 0 ? (
              <span className="w-5 h-5 rounded-full bg-rose-500 text-white font-bold text-[10px] flex items-center justify-center">
                {tab.badge}
              </span>
            ) : null}
          </button>
        ))}
      </div>

      {/* Main Tab Content */}
      <div className="py-6">
        {loading ? (
          <div className="py-20 text-center">
            <div className="inline-block w-8 h-8 border-2 border-amber-400 border-t-transparent rounded-full animate-spin mb-3" />
            <p className="text-xs text-slate-400 uppercase tracking-widest">Synchronizing with Firestore Database...</p>
          </div>
        ) : (
          <>
            {/* TAB: DASHBOARD OVERVIEW */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-5 rounded-2xl glass-panel border border-slate-800">
                    <span className="text-xs text-slate-400 uppercase tracking-wider block mb-1">Total Stories</span>
                    <span className="text-3xl font-black text-white font-display">{articles.length}</span>
                  </div>
                  <div className="p-5 rounded-2xl glass-panel border border-amber-500/30 bg-amber-500/5">
                    <span className="text-xs text-amber-300 uppercase tracking-wider block mb-1">Pending Approval</span>
                    <span className="text-3xl font-black text-amber-400 font-display">{pendingArticles.length}</span>
                  </div>
                  <div className="p-5 rounded-2xl glass-panel border border-emerald-500/30 bg-emerald-500/5">
                    <span className="text-xs text-emerald-300 uppercase tracking-wider block mb-1">Live Published</span>
                    <span className="text-3xl font-black text-emerald-400 font-display">{publishedArticles.length}</span>
                  </div>
                  <div className="p-5 rounded-2xl glass-panel border border-slate-800">
                    <span className="text-xs text-slate-400 uppercase tracking-wider block mb-1">Registered Users</span>
                    <span className="text-3xl font-black text-amber-400 font-display">
                      {users.length === 0 ? 'None' : users.length}
                    </span>
                  </div>
                </div>

                {/* Pending Submissions Quick Action Box */}
                {pendingArticles.length > 0 && (
                  <div className="p-6 rounded-2xl bg-amber-950/40 border border-amber-500/40">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-black text-amber-200 font-display">
                          Submissions Awaiting Your Review ({pendingArticles.length})
                        </h3>
                        <p className="text-xs text-slate-300">
                          These articles were submitted by readers and require editorial authorization before going live.
                        </p>
                      </div>
                      <button
                        onClick={() => setActiveTab('pending')}
                        className="text-xs text-amber-300 hover:text-amber-200 font-bold underline"
                      >
                        View All Pending →
                      </button>
                    </div>

                    <div className="space-y-3">
                      {pendingArticles.slice(0, 3).map((art) => (
                        <div key={art.id} className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 px-2 py-0.5 rounded bg-amber-500/10">
                              {art.category}
                            </span>
                            <h4 className="text-sm font-bold text-white mt-1">{art.title}</h4>
                            <p className="text-xs text-slate-400">By {art.authorName} · {new Date(art.createdAt).toLocaleDateString()}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleQuickApprove(art)}
                              className="py-1.5 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                            >
                              ✓ Approve
                            </button>
                            <button
                              onClick={() => handleOpenReject(art)}
                              className="py-1.5 px-3 rounded-lg bg-rose-950 text-rose-200 border border-rose-500/40 text-xs font-semibold"
                            >
                              ✕ Reject
                            </button>
                            <button
                              onClick={() => handleOpenEdit(art)}
                              className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs"
                            >
                              Review
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Recent Articles Stream */}
                <div>
                  <h3 className="text-lg font-black text-white font-display mb-3">Recently Updated Content</h3>
                  <div className="space-y-3">
                    {articles.slice(0, 5).map((art) => (
                      <div key={art.id} className="p-4 rounded-xl glass-panel border border-slate-800 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <img src={art.imageUrl} alt="" className="w-12 h-12 rounded-lg object-cover" />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-bold uppercase text-amber-400">{art.category}</span>
                              <span className={`text-[10px] font-bold uppercase px-2 py-0.2 rounded ${
                                art.status === 'published' ? 'text-emerald-400 bg-emerald-500/10' : 'text-amber-400 bg-amber-500/10'
                              }`}>
                                {art.status}
                              </span>
                            </div>
                            <h4 className="text-sm font-bold text-white font-display line-clamp-1">{art.title}</h4>
                            <span className="text-[11px] text-slate-400">By {art.authorName} · {art.views || 0} views</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleOpenEdit(art)}
                            className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
                          >
                            Edit
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: ALL ARTICLES & STATUS FILTERS */}
            {['articles', 'pending', 'published', 'drafts', 'rejected'].includes(activeTab) && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-black text-white font-display uppercase">
                    {activeTab === 'articles' ? 'All Publications & Submissions' : `${activeTab} Articles`}
                  </h2>
                  <button
                    onClick={handleOpenCreate}
                    className="py-2 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider"
                  >
                    + New Article
                  </button>
                </div>

                <div className="space-y-3">
                  {(activeTab === 'pending'
                    ? pendingArticles
                    : activeTab === 'published'
                    ? publishedArticles
                    : activeTab === 'drafts'
                    ? draftArticles
                    : activeTab === 'rejected'
                    ? rejectedArticles
                    : articles
                  ).map((art) => (
                    <div
                      key={art.id}
                      className="p-5 rounded-2xl glass-panel border border-slate-800 hover:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="flex items-start gap-4">
                        <img
                          src={art.imageUrl}
                          alt=""
                          className="w-20 h-20 rounded-xl object-cover shrink-0 border border-slate-700"
                        />
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#1e1f23] text-amber-300 border border-amber-500/20">
                              {art.category}
                            </span>
                            <span
                              className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                                art.status === 'published'
                                  ? 'bg-emerald-500/15 text-emerald-400'
                                  : art.status === 'pending'
                                  ? 'bg-amber-500/15 text-amber-400'
                                  : art.status === 'rejected'
                                  ? 'bg-rose-500/15 text-rose-400'
                                  : 'bg-slate-700 text-slate-300'
                              }`}
                            >
                              {art.status}
                            </span>
                            {art.isFeatured && (
                              <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                                ⭐ Featured
                              </span>
                            )}
                          </div>

                          <h3 className="text-base font-bold text-white font-display leading-snug">
                            {art.title}
                          </h3>
                          <p className="text-xs text-slate-400 line-clamp-1">{art.summary}</p>
                          <div className="text-[11px] text-slate-400 flex items-center gap-3">
                            <span>Author: <strong className="text-slate-300">{art.authorName}</strong></span>
                            <span>·</span>
                            <span>{art.readTime}</span>
                            <span>·</span>
                            <span>{art.views || 0} views</span>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {art.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleQuickApprove(art)}
                              className="py-1.5 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                            >
                              Approve & Publish
                            </button>
                            <button
                              onClick={() => handleOpenReject(art)}
                              className="py-1.5 px-3 rounded-lg bg-rose-950 text-rose-200 border border-rose-500/30 text-xs"
                            >
                              Reject
                            </button>
                          </>
                        )}

                        <button
                          onClick={() => handleToggleFeatured(art)}
                          className={`py-1.5 px-3 rounded-lg text-xs font-semibold border ${
                            art.isFeatured
                              ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                              : 'bg-slate-800 border-slate-700 text-slate-300'
                          }`}
                        >
                          {art.isFeatured ? '★ Featured' : '☆ Feature'}
                        </button>

                        <button
                          onClick={() => handleOpenEdit(art)}
                          className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold"
                        >
                          Edit
                        </button>

                        <button
                          onClick={() => setDeleteConfirmArticle(art)}
                          className="py-1.5 px-3 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 text-xs font-semibold"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: TAXONOMY / CATEGORIES */}
            {activeTab === 'categories' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                  <h3 className="text-lg font-black text-white font-display">Current Categories</h3>
                  <div className="space-y-3">
                    {categories.map((c) => (
                      <div key={c.id} className="p-4 rounded-xl glass-panel border border-slate-800 flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm">{c.name}</h4>
                            <span className="text-[11px] text-amber-400 font-mono">/{c.slug}</span>
                          </div>
                          {c.description && <p className="text-xs text-slate-400 mt-1">{c.description}</p>}
                        </div>
                        <button
                          onClick={() => handleDeleteCategory(c)}
                          className="text-xs text-rose-400 hover:text-rose-300 py-1 px-2.5 rounded bg-rose-950/40 border border-rose-500/30"
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-6 rounded-2xl glass-panel border border-slate-800">
                  <h3 className="text-base font-black text-white font-display mb-4">Add New Category</h3>
                  <form onSubmit={handleCreateCategory} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Name</label>
                      <input
                        type="text"
                        required
                        value={newCatName}
                        onChange={(e) => setNewCatName(e.target.value)}
                        placeholder="e.g. Economy"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Slug</label>
                      <input
                        type="text"
                        value={newCatSlug}
                        onChange={(e) => setNewCatSlug(e.target.value)}
                        placeholder="e.g. economy"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Description</label>
                      <textarea
                        rows={2}
                        value={newCatDesc}
                        onChange={(e) => setNewCatDesc(e.target.value)}
                        placeholder="Short overview for section headers"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={creatingCategory}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-bold text-xs uppercase tracking-wider transition-all"
                    >
                      {creatingCategory ? 'Saving...' : '+ Add Category'}
                    </button>
                  </form>
                </div>
              </div>
            )}

            {/* TAB: USERS LIST */}
            {activeTab === 'users' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-black text-white font-display">
                    Registered Platform Users ({users.length === 0 ? 'None' : users.length})
                  </h3>
                  <span className="text-xs text-amber-400 font-serif">
                    Live Firestore Real-Time Synchronized
                  </span>
                </div>

                {users.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl glass-panel border border-slate-800">
                    <p className="text-sm font-semibold text-slate-300">None</p>
                    <p className="text-xs text-slate-500 mt-1">
                      No users currently registered in Cloud Firestore. As soon as a reader registers or logs in with Google, their profile will appear here in real-time.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {users.map((u) => (
                      <div
                        key={u.uid}
                        className="p-4 rounded-xl glass-panel border border-slate-800 hover:border-slate-700 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3.5">
                          {u.photoURL ? (
                            <img
                              src={u.photoURL}
                              alt={u.name}
                              className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-500/40 shrink-0"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-[#1e1f23] flex items-center justify-center font-bold text-amber-400 border border-[#2e2a24] shrink-0">
                              {u.name?.charAt(0) || 'U'}
                            </div>
                          )}
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-white text-sm">{u.name}</h4>
                              {u.isVerified && (
                                <span
                                  className="inline-flex items-center justify-center w-4 h-4 bg-sky-500 text-white rounded-full"
                                  title="Verified Blue Tick"
                                >
                                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                                </span>
                              )}
                              <span
                                className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                                  u.role === 'admin'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                    : 'bg-slate-800 text-slate-300'
                                }`}
                              >
                                {u.role}
                              </span>
                            </div>
                            <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                              <span>{u.email}</span>
                              <span>·</span>
                              <span>Joined {new Date(u.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 self-start md:self-auto">
                          {/* Give or Revoke Blue Tick */}
                          <button
                            onClick={async () => {
                              const nextStatus = !u.isVerified;
                              await toggleVerifiedBadge(u.uid, nextStatus);
                              addToast({
                                type: 'success',
                                title: nextStatus ? 'Blue Tick Granted' : 'Blue Tick Revoked',
                                message: `${u.name} status updated.`,
                              });
                            }}
                            className={`py-1.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                              u.isVerified
                                ? 'bg-rose-950/40 border border-rose-500/40 text-rose-300 hover:bg-rose-900/60'
                                : 'bg-sky-500 hover:bg-sky-400 text-white shadow-sm'
                            }`}
                          >
                            <Check className="w-3 h-3 stroke-[3]" />
                            <span>{u.isVerified ? 'Revoke Tick' : 'Give Blue Tick'}</span>
                          </button>

                          {/* Inspect Profile & Uploads */}
                          <button
                            onClick={() => setInspectingUser(u)}
                            className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
                          >
                            View Profile & Uploads
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: SITE SETTINGS & ANNOUNCEMENTS */}
            {(activeTab === 'settings' || activeTab === 'announcements') && (
              <div className="max-w-2xl">
                <h3 className="text-lg font-black text-white font-display mb-4">Global Site Settings</h3>
                <form onSubmit={handleSaveSettings} className="space-y-5 glass-panel p-6 rounded-2xl border border-slate-800">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Publication Name</label>
                    <input
                      type="text"
                      value={settingsSiteName}
                      onChange={(e) => setSettingsSiteName(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Publication Description</label>
                    <textarea
                      rows={2}
                      value={settingsSiteDesc}
                      onChange={(e) => setSettingsSiteDesc(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Hero Subtitle / Notice</label>
                    <input
                      type="text"
                      value={settingsNotice}
                      onChange={(e) => setSettingsNotice(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Platform Banner Announcement</label>
                    <input
                      type="text"
                      value={settingsAnnouncement}
                      onChange={(e) => setSettingsAnnouncement(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                    />
                    <label className="flex items-center gap-2 mt-2 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settingsAnnounceActive}
                        onChange={(e) => setSettingsAnnounceActive(e.target.checked)}
                        className="rounded"
                      />
                      <span>Show announcement ticker at top of website</span>
                    </label>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Contact Email</label>
                    <input
                      type="email"
                      value={settingsContact}
                      onChange={(e) => setSettingsContact(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={savingSettings}
                    className="py-3 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider transition-colors"
                  >
                    {savingSettings ? 'Saving to Firestore...' : 'Save Site Settings'}
                  </button>
                </form>
              </div>
            )}
          </>
        )}
      </div>

      {/* ARTICLE EDITOR MODAL */}
      {isEditorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 sm:p-8 rounded-2xl glass-panel border border-amber-500/40 shadow-2xl relative my-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
              <div>
                <h3 className="text-xl font-black text-white font-display uppercase">
                  {editingArticle ? 'Edit Article' : 'Compose New Article'}
                </h3>
                <p className="text-xs text-slate-400">Editor-in-Chief Publishing Console</p>
              </div>
              <button
                onClick={() => setIsEditorOpen(false)}
                className="text-slate-400 hover:text-white p-2 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveArticle} className="space-y-5">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Title *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.slug}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Type</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                  >
                    <option value="news">News</option>
                    <option value="analysis">Analysis</option>
                    <option value="opinion">Opinion</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Status</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                  >
                    <option value="published">Published</option>
                    <option value="pending">Pending</option>
                    <option value="draft">Draft</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Subtitle</label>
                <input
                  type="text"
                  value={formSubtitle}
                  onChange={(e) => setFormSubtitle(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Summary / Excerpt *</label>
                <textarea
                  rows={2}
                  required
                  value={formSummary}
                  onChange={(e) => setFormSummary(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Content (Markdown Supported) *</label>
                <textarea
                  rows={10}
                  required
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Image URL or Local Path</label>
                  <input
                    type="text"
                    value={formImageUrl}
                    onChange={(e) => setFormImageUrl(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                  />
                  <div className="mt-2">
                    <label className="text-[11px] text-slate-400 block mb-1">Or upload new image to Firebase Storage:</label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files?.[0]) setFormImageFile(e.target.files[0]);
                      }}
                      className="text-xs text-slate-400"
                    />
                    {uploadProgress !== null && (
                      <span className="text-xs text-amber-400 block mt-1">Uploading: {uploadProgress}%</span>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-300 mb-1">Tags (Comma separated)</label>
                  <input
                    type="text"
                    value={formTags}
                    onChange={(e) => setFormTags(e.target.value)}
                    placeholder="Sindh, Agriculture, Politics"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-6 pt-2">
                <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsFeatured}
                    onChange={(e) => setFormIsFeatured(e.target.checked)}
                    className="rounded"
                  />
                  <span>Mark as Featured Article (Hero Spotlight)</span>
                </label>
                <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formIsTrending}
                    onChange={(e) => setFormIsTrending(e.target.checked)}
                    className="rounded"
                  />
                  <span>Mark as Trending Story</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsEditorOpen(false)}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 text-slate-300 font-medium text-xs hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingArticle}
                  className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider"
                >
                  {savingArticle ? 'Saving to Firestore...' : editingArticle ? 'Update Article' : 'Publish Article'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE DIALOG */}
      {deleteConfirmArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="max-w-md w-full p-6 rounded-2xl glass-panel border border-rose-500/40 text-center">
            <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mx-auto mb-3 text-rose-400 text-xl font-bold">
              ⚠️
            </div>
            <h3 className="text-lg font-black text-white font-display">Delete Publication?</h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Are you sure you want to permanently delete <strong className="text-white">"{deleteConfirmArticle.title}"</strong> from Cloud Firestore? This action cannot be undone.
            </p>
            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={() => setDeleteConfirmArticle(null)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-slate-800 text-slate-300 font-semibold text-xs hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REJECT MODAL */}
      {rejectModalArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="max-w-md w-full p-6 rounded-2xl glass-panel border border-amber-500/40">
            <h3 className="text-lg font-black text-white font-display mb-1">Reject Submission</h3>
            <p className="text-xs text-slate-400 mb-4">
              Provide feedback for the author so they know what revisions are required.
            </p>
            <textarea
              rows={3}
              value={rejectionReasonText}
              onChange={(e) => setRejectionReasonText(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs mb-4"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setRejectModalArticle(null)}
                className="py-2 px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReject}
                className="py-2 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Profile & Avatar Modal */}
      <ProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      {/* User Profile & Uploads Inspector Modal */}
      <UserProfileInspectorModal
        user={inspectingUser}
        isOpen={!!inspectingUser}
        onClose={() => setInspectingUser(null)}
        onSelectArticle={(slug) => onNavigate({ type: 'article', slug })}
      />
    </div>
  );
};
