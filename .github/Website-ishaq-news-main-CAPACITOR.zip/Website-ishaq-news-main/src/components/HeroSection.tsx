import React from 'react';
import { Article } from '../types';
import { Clock, ArrowRight, Bookmark } from 'lucide-react';

interface HeroSectionProps {
  featuredArticle: Article;
  companionArticles: Article[];
  onSelectArticle: (slug: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  featuredArticle,
  companionArticles,
  onSelectArticle
}) => {
  if (!featuredArticle) return null;

  const formattedDate = new Date(featuredArticle.publishedAt || featuredArticle.createdAt).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  const authorName = featuredArticle.authorName || featuredArticle.author || 'Ishaq Turk';

  return (
    <section className="mb-14">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Main Hero Card (8 cols) */}
        <div
          onClick={() => onSelectArticle(featuredArticle.slug || featuredArticle.id)}
          className="lg:col-span-8 group cursor-pointer relative rounded-2xl overflow-hidden glass-panel glass-panel-hover flex flex-col justify-end min-h-[460px] sm:min-h-[520px] border border-[#d4af37]/20"
        >
          {/* Background Image with rich warm black & espresso scrim */}
          <div className="absolute inset-0 z-0 bg-[#0c0d0e]">
            <img
              src={featuredArticle.imageUrl}
              alt={featuredArticle.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
            />
            {/* Scrim gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0c0d0e] via-[#0c0d0e]/75 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0c0d0e]/85 via-[#0c0d0e]/30 to-transparent hidden md:block" />
            <div className="absolute inset-0 ring-1 ring-inset ring-[#d4af37]/20 rounded-2xl pointer-events-none" />
          </div>

          {/* Hero Content */}
          <div className="relative z-10 p-6 sm:p-8 md:p-10 max-w-3xl">
            {/* Unboxed Metadata without static pills */}
            <div className="flex items-center gap-2 text-xs tracking-wider font-semibold text-[#d4af37] mb-3 uppercase">
              <span className="text-[11px] font-bold text-[#e6cf84] tracking-widest">
                Lead Story
              </span>
              <span aria-hidden="true" className="text-[#686358]">·</span>
              <span className="capitalize text-[#cfcac0]">{featuredArticle.category}</span>
              <span aria-hidden="true" className="text-[#686358]">·</span>
              <span className="text-[#a09a8e]">{formattedDate}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white leading-tight font-display tracking-tight group-hover:text-[#f3e7b8] transition-colors mb-3">
              {featuredArticle.title}
            </h1>

            <p className="text-sm sm:text-base text-[#cfcac0] line-clamp-3 leading-relaxed mb-6 max-w-2xl font-normal font-editorial">
              {featuredArticle.summary}
            </p>

            <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-[#33302a]">
              <div className="flex items-center gap-3">
                <img
                  src={featuredArticle.authorAvatar || '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg'}
                  alt={authorName}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-[#d4af37]/50"
                />
                <div>
                  <div className="text-sm font-semibold text-[#f5f2eb] leading-tight">
                    {authorName}
                  </div>
                  <div className="text-xs text-[#a09a8e]">{featuredArticle.authorRole}</div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5 text-xs text-[#b8b3a7]">
                  <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                  {featuredArticle.readTime}
                </span>

                <button
                  type="button"
                  className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-[#0c0d0e] bg-gradient-to-r from-[#d4af37] via-[#c59b27] to-[#b38820] hover:brightness-110 rounded-xl shadow-lg shadow-[#d4af37]/15 transition-all transform group-hover:translate-x-1 cursor-pointer uppercase tracking-wider"
                >
                  Read Dispatch
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Secondary Spotlights (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          <div className="text-xs font-bold tracking-widest text-[#d4af37] uppercase px-1 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Bookmark className="w-3.5 h-3.5" />
              Editor's Despatches
            </span>
            <span className="text-[11px] text-[#706c62] font-normal">Daily Insights</span>
          </div>

          {companionArticles.slice(0, 3).map((article) => {
            const cAuthor = article.authorName || article.author || 'Ishaq Turk';
            return (
              <div
                key={article.id}
                onClick={() => onSelectArticle(article.slug || article.id)}
                className="group cursor-pointer p-4 sm:p-5 rounded-2xl glass-panel glass-panel-hover flex-1 flex flex-col justify-between border border-[#d4af37]/15"
              >
                <div>
                  <div className="flex items-center gap-2 text-xs text-[#8c887e] mb-2">
                    <span className="font-semibold text-[#d4af37] uppercase tracking-wider">
                      {article.type}
                    </span>
                    <span aria-hidden="true" className="text-[#524e47]">·</span>
                    <span className="capitalize text-[#b8b3a7]">{article.category}</span>
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-[#f5f2eb] group-hover:text-[#f3e7b8] transition-colors line-clamp-2 leading-snug font-display">
                    {article.title}
                  </h3>
                </div>

                <div className="mt-3 flex items-center justify-between text-xs text-[#8c887e] pt-2.5 border-t border-[#292723]">
                  <span>By {cAuthor}</span>
                  <span className="flex items-center gap-1 text-[#b8b3a7]">
                    <Clock className="w-3 h-3 text-[#d4af37]" />
                    {article.readTime}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
