import React from 'react';
import { Article, Category } from '../types';
import { ArticleCard } from './ArticleCard';
import { ArrowRight, Compass, Globe, Landmark, Cpu, MessageSquareQuote, MapPin } from 'lucide-react';

interface CategorySectionProps {
  category: Category;
  title: string;
  subtitle: string;
  actionText: string;
  articles: Article[];
  onSelectCategory: (category: Category) => void;
  onSelectArticle: (slug: string) => void;
  sophisticated?: boolean;
}

export const CategorySection: React.FC<CategorySectionProps> = ({
  category,
  title,
  subtitle,
  actionText,
  articles,
  onSelectCategory,
  onSelectArticle,
  sophisticated = false
}) => {
  if (!articles || articles.length === 0) return null;

  const categoryIcons: Record<Category, React.ReactNode> = {
    sindh: <MapPin className="w-5 h-5 text-[#d4af37]" />,
    pakistan: <Landmark className="w-5 h-5 text-[#e5c46b]" />,
    world: <Globe className="w-5 h-5 text-[#d4af37]" />,
    geopolitics: <Compass className="w-5 h-5 text-[#f5e6b3]" />,
    technology: <Cpu className="w-5 h-5 text-[#d4af37]" />,
    opinion: <MessageSquareQuote className="w-5 h-5 text-[#e5c46b]" />
  };

  const leadArticle = articles[0];
  const sideArticles = articles.slice(1, 4);

  return (
    <section className={`my-16 ${sophisticated ? 'p-6 sm:p-8 rounded-2xl border border-[#d4af37]/20 bg-gradient-to-b from-[#211f1a]/40 via-[#141412]/50 to-transparent' : ''}`}>
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-4 mb-6 border-b border-[#d4af37]/15">
        <div>
          <div className="flex items-center gap-2 mb-1">
            {categoryIcons[category] || <Globe className="w-5 h-5 text-[#d4af37]" />}
            <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-white font-display">
              {title}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-[#a09a8e] max-w-xl font-editorial">
            {subtitle}
          </p>
        </div>

        <button
          onClick={() => onSelectCategory(category)}
          className="text-xs font-semibold text-[#d4af37] hover:text-[#f5e6b3] transition-colors inline-flex items-center gap-1.5 self-start sm:self-auto py-1 px-2.5 rounded-lg hover:bg-[#1a1918]/80 cursor-pointer"
        >
          <span>{actionText}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Grid Layout: Lead story + Secondary stories */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {leadArticle && (
          <div className="lg:col-span-7">
            <ArticleCard
              article={leadArticle}
              onClick={() => onSelectArticle(leadArticle.slug || leadArticle.id)}
              variant="standard"
            />
          </div>
        )}

        <div className="lg:col-span-5 flex flex-col gap-4">
          {sideArticles.map((article) => (
            <ArticleCard
              key={article.id}
              article={article}
              onClick={() => onSelectArticle(article.slug || article.id)}
              variant="compact"
            />
          ))}

          {sideArticles.length === 0 && leadArticle && (
            <div className="p-6 rounded-xl glass-panel text-center text-[#8c887e] text-xs">
              More updates from {title} arriving shortly.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
