import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { firebaseData } from '../services/firebaseDataService';
import { FeedPost, AppLanguage, ViewRoute } from '../types';
import {
  ThumbsUp,
  MessageCircle,
  Share2,
  MapPin,
  Clock,
  Sparkles,
  Send,
  Image as ImageIcon,
  Check,
  AlertTriangle,
  Flame,
  Globe,
  Languages,
  CheckCircle2,
  Bookmark,
} from 'lucide-react';

interface NewsFeedViewProps {
  onNavigate: (route: ViewRoute) => void;
  currentLanguage: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
}

export const NewsFeedView: React.FC<NewsFeedViewProps> = ({
  onNavigate,
  currentLanguage,
  onLanguageChange,
}) => {
  const { currentUser, userProfile, isAdmin, isRegistered } = useAuth();
  const { addToast } = useToast();

  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<'all' | 'sindh' | 'breaking' | 'incident' | 'verified'>('all');
  const [activeLanguageFilter, setActiveLanguageFilter] = useState<'all' | 'sd' | 'en' | 'ur'>('all');

  // Composer state
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState('sindh');
  const [newPostType, setNewPostType] = useState<'news' | 'incident' | 'breaking' | 'photo' | 'opinion'>('news');
  const [newLanguage, setNewLanguage] = useState<AppLanguage>(currentLanguage);
  const [newLocation, setNewLocation] = useState('');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showImageInput, setShowImageInput] = useState(false);

  // Active comments open per post ID
  const [openComments, setOpenComments] = useState<Record<string, boolean>>({});
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [submittingComment, setSubmittingComment] = useState<Record<string, boolean>>({});

  useEffect(() => {
    // Subscribe to realtime feed posts
    const unsub = firebaseData.subscribeToFeedPosts((updatedPosts) => {
      setPosts(updatedPosts);
      setLoading(false);
    });

    return () => unsub();
  }, []);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) {
      addToast({ type: 'error', title: 'Content required', message: 'Please write your news dispatch or incident update.' });
      return;
    }

    if (!isRegistered) {
      addToast({ type: 'info', title: 'Sign In Required', message: 'Please log in or register to publish dispatches.' });
      onNavigate({ type: 'login' });
      return;
    }

    try {
      setIsSubmitting(true);
      const authorName = userProfile?.name || currentUser?.displayName || 'Citizen Reporter';
      const authorAvatar = userProfile?.photoURL || currentUser?.photoURL || (isAdmin ? '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg' : undefined);
      const isVerified = !!(userProfile?.isVerified || isAdmin);

      await firebaseData.createFeedPost({
        content: newContent.trim(),
        category: newCategory,
        postType: newPostType,
        language: newLanguage,
        location: newLocation.trim() || undefined,
        imageUrl: newImageUrl.trim() || undefined,
        authorId: currentUser?.uid || userProfile?.uid || 'user_anon',
        authorName,
        authorEmail: currentUser?.email || userProfile?.email,
        authorAvatar,
        authorRole: isAdmin ? 'Founder & Editor' : 'Verified Contributor',
        isVerified,
      });

      addToast({
        type: 'success',
        title: 'Dispatch Published',
        message: 'Your update is now live on the realtime News Feed!',
      });

      setNewContent('');
      setNewLocation('');
      setNewImageUrl('');
      setShowImageInput(false);
    } catch (err: any) {
      console.error('Error creating feed post:', err);
      addToast({ type: 'error', title: 'Post Failed', message: err.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLike = async (postId: string) => {
    const userId = currentUser?.uid || userProfile?.uid || 'guest_user';
    try {
      const result = await firebaseData.likeFeedPost(postId, userId);
      // Local optimistic update
      setPosts((prev) =>
        prev.map((p) =>
          p.id === postId
            ? {
                ...p,
                likesCount: result.likesCount,
                likedBy: result.isLiked
                  ? [...(p.likedBy || []), userId]
                  : (p.likedBy || []).filter((id) => id !== userId),
              }
            : p
        )
      );
    } catch (err: any) {
      addToast({ type: 'error', title: 'Like failed', message: err.message });
    }
  };

  const handleAddComment = async (postId: string) => {
    const text = commentInputs[postId]?.trim();
    if (!text) return;

    const authorName = userProfile?.name || currentUser?.displayName || 'Reader';
    const authorAvatar = userProfile?.photoURL || currentUser?.photoURL;
    const isVerified = !!(userProfile?.isVerified || isAdmin);

    try {
      setSubmittingComment((prev) => ({ ...prev, [postId]: true }));
      const newComment = await firebaseData.addFeedComment(postId, {
        authorId: currentUser?.uid || userProfile?.uid || 'guest_anon',
        authorName,
        authorAvatar,
        isVerified,
        content: text,
      });

      // Clear input
      setCommentInputs((prev) => ({ ...prev, [postId]: '' }));

      // Optimistic state
      setPosts((prev) =>
        prev.map((p) =>
          p.id === postId
            ? {
                ...p,
                commentsCount: (p.commentsCount || 0) + 1,
                comments: [...(p.comments || []), newComment],
              }
            : p
        )
      );

      addToast({ type: 'success', title: 'Comment Posted', message: 'Your comment was shared.' });
    } catch (err: any) {
      addToast({ type: 'error', title: 'Comment Failed', message: err.message });
    } finally {
      setSubmittingComment((prev) => ({ ...prev, [postId]: false }));
    }
  };

  const handleShare = (post: FeedPost) => {
    const shareUrl = window.location.href.split('#')[0] + `#/feed`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`${post.content.slice(0, 100)}... Read on News By Ishaq: ${shareUrl}`);
      addToast({ type: 'info', title: 'Link Copied', message: 'Post link copied to clipboard!' });
    }
  };

  // Filter posts
  const filteredPosts = posts.filter((post) => {
    if (activeFilter === 'sindh' && post.category.toLowerCase() !== 'sindh') return false;
    if (activeFilter === 'breaking' && post.postType !== 'breaking') return false;
    if (activeFilter === 'incident' && post.postType !== 'incident') return false;
    if (activeFilter === 'verified' && !post.isVerified) return false;
    if (activeLanguageFilter !== 'all' && post.language !== activeLanguageFilter) return false;
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-10 animate-in fade-in duration-300">
      {/* Feed Banner / Multi-language bar */}
      <div className="mb-6 p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white font-display tracking-tight uppercase">
              Live News Feed & Incidents
            </h1>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Realtime Firestore Live" />
          </div>
          <p className="text-xs text-slate-500 dark:text-[#a09a8e] mt-1 font-editorial">
            Real-time multi-language dispatches, ground incidents across Sindh, breaking news & citizen reporting.
          </p>
        </div>

        {/* Language Filter Chips */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <Languages className="w-4 h-4 text-amber-500 shrink-0 hidden sm:inline" />
          <button
            onClick={() => setActiveLanguageFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeLanguageFilter === 'all'
                ? 'bg-amber-500 text-stone-950 font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            All Languages
          </button>
          <button
            onClick={() => setActiveLanguageFilter('sd')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeLanguageFilter === 'sd'
                ? 'bg-amber-500 text-stone-950 font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            سنڌي (Sindhi)
          </button>
          <button
            onClick={() => setActiveLanguageFilter('en')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeLanguageFilter === 'en'
                ? 'bg-amber-500 text-stone-950 font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            English
          </button>
          <button
            onClick={() => setActiveLanguageFilter('ur')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeLanguageFilter === 'ur'
                ? 'bg-amber-500 text-stone-950 font-bold'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            اردو (Urdu)
          </button>
        </div>
      </div>

      {/* Facebook-style Dispatch Composer */}
      <div className="mb-8 p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723] shadow-md">
        <div className="flex items-start gap-3.5 mb-3">
          <img
            src={
              userProfile?.photoURL ||
              currentUser?.photoURL ||
              (isAdmin ? '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg' : '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg')
            }
            alt=""
            className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/40 shrink-0"
          />
          <div className="flex-1">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                {userProfile?.name || 'Citizen Reporter'}
              </span>
              {(userProfile?.isVerified || isAdmin) && (
                <span
                  className="inline-flex items-center justify-center w-4 h-4 bg-sky-500 text-white rounded-full"
                  title="Verified Blue Tick Account"
                >
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-[#a09a8e]">
              Publish an incident report, breaking flash, or public observation across Sindh.
            </p>
          </div>
        </div>

        <form onSubmit={handleCreatePost} className="space-y-3.5">
          <textarea
            rows={3}
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            dir={newLanguage === 'sd' || newLanguage === 'ur' ? 'rtl' : 'ltr'}
            placeholder={
              newLanguage === 'sd'
                ? 'سنڌ جي ڪنهن واقعي يا خبر بابت ڇا اپڊيٽ آهي؟ هتي لکو...'
                : newLanguage === 'ur'
                ? 'سندھ یا دیگر علاقوں کے کسی واقعے کی تازہ ترین تفصیلات یہاں لکھیں...'
                : "What's happening in Sindh or around the world? Share news, incident alert, or analysis..."
            }
            className={`w-full p-3.5 rounded-xl bg-slate-50 dark:bg-[#0c0d0e] border border-slate-300 dark:border-[#2a2723] text-sm text-slate-900 dark:text-[#f4efe6] placeholder-slate-400 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500/50 transition-all ${
              newLanguage === 'sd' || newLanguage === 'ur' ? 'font-serif leading-loose' : 'font-sans'
            }`}
          />

          {/* Optional Image URL Input Drawer */}
          {showImageInput && (
            <div className="p-3 rounded-xl bg-slate-100 dark:bg-[#1a1b1e] border border-slate-200 dark:border-[#2e2b26] space-y-2 animate-in fade-in duration-200">
              <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                Image or Photo Story URL
              </label>
              <input
                type="url"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                placeholder="https://example.com/incident-photo.jpg"
                className="w-full px-3 py-2 rounded-lg bg-white dark:bg-[#0c0d0e] border border-slate-300 dark:border-[#2a2723] text-xs text-slate-900 dark:text-white"
              />
              {newImageUrl && (
                <img
                  src={newImageUrl}
                  alt="Preview"
                  className="w-full max-h-48 object-cover rounded-lg border border-slate-300 dark:border-slate-700"
                />
              )}
            </div>
          )}

          {/* Post metadata bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-[#22211e]">
            <div className="flex flex-wrap items-center gap-2">
              {/* Type Select */}
              <select
                value={newPostType}
                onChange={(e: any) => setNewPostType(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                <option value="news">📰 News Flash</option>
                <option value="incident">🚨 Incident Report</option>
                <option value="breaking">⚡ Breaking Alert</option>
                <option value="photo">📸 Photo Story</option>
                <option value="opinion">💡 Public Opinion</option>
              </select>

              {/* Language Select */}
              <select
                value={newLanguage}
                onChange={(e: any) => setNewLanguage(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                <option value="sd">سنڌي (Sindhi)</option>
                <option value="en">English</option>
                <option value="ur">اردو (Urdu)</option>
              </select>

              {/* Location Input */}
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <input
                  type="text"
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  placeholder="Location (e.g. Sukkur, Karachi, M9)"
                  className="bg-transparent text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none w-32 sm:w-44"
                />
              </div>

              {/* Photo toggle button */}
              <button
                type="button"
                onClick={() => setShowImageInput(!showImageInput)}
                className={`p-1.5 rounded-lg border text-xs font-medium flex items-center gap-1 cursor-pointer transition-colors ${
                  showImageInput
                    ? 'bg-amber-500/10 border-amber-500/40 text-amber-600 dark:text-amber-400'
                    : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                }`}
                title="Add photo"
              >
                <ImageIcon className="w-4 h-4" />
                <span className="hidden sm:inline">Photo</span>
              </button>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !newContent.trim()}
              className="py-2 px-5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5 cursor-pointer ml-auto"
            >
              {isSubmitting ? (
                <span>Publishing...</span>
              ) : (
                <>
                  <span>Publish</span>
                  <Send className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Filter Tabs Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 border-b border-slate-200 dark:border-[#2a2723] scrollbar-none text-xs font-semibold">
        {[
          { id: 'all', label: 'All Dispatches' },
          { id: 'sindh', label: '🌾 Sindh Affairs (سنڌ)' },
          { id: 'incident', label: '🚨 Incident Reports' },
          { id: 'breaking', label: '⚡ Breaking Updates' },
          { id: 'verified', label: '✓ Verified Blue Tick Accounts' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFilter(tab.id as any)}
            className={`py-2 px-3.5 rounded-xl whitespace-nowrap transition-all cursor-pointer ${
              activeFilter === tab.id
                ? 'bg-amber-500 text-stone-950 font-bold shadow-sm'
                : 'bg-white dark:bg-[#141517] text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#1c1d21] border border-slate-200 dark:border-[#2a2723]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Feed Stream */}
      {loading ? (
        <div className="py-20 text-center">
          <div className="inline-block w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-xs text-slate-500 uppercase tracking-widest">Loading Live Dispatches...</p>
        </div>
      ) : filteredPosts.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723]">
          <Flame className="w-8 h-8 text-amber-500 mx-auto mb-2 opacity-60" />
          <h3 className="text-base font-bold text-slate-800 dark:text-white">No posts match this filter</h3>
          <p className="text-xs text-slate-500 mt-1">Be the first to publish a report or switch language filters above.</p>
        </div>
      ) : (
        <div className="space-y-5">
          {filteredPosts.map((post) => {
            const isSindhiOrUrdu = post.language === 'sd' || post.language === 'ur';
            const userLiked = post.likedBy?.includes(currentUser?.uid || userProfile?.uid || '');
            const commentsList = post.comments || [];
            const commentsOpen = !!openComments[post.id];

            return (
              <article
                key={post.id}
                className="bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723] rounded-2xl p-5 sm:p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                {/* Header: Author & verified badge */}
                <div className="flex items-center justify-between gap-3 mb-3.5">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.authorAvatar || '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg'}
                      alt=""
                      className="w-11 h-11 rounded-full object-cover ring-2 ring-amber-500/30 shrink-0"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
                      }}
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-slate-900 dark:text-white">
                          {post.authorName}
                        </span>
                        {/* Verified Blue Tick like Facebook / Instagram */}
                        {post.isVerified && (
                          <span
                            className="inline-flex items-center justify-center w-4 h-4 bg-sky-500 text-white rounded-full shadow-sm"
                            title="Verified Account (Blue Tick)"
                          >
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </span>
                        )}
                        <span className="text-[11px] text-slate-400">·</span>
                        <span className="text-[11px] text-slate-500 dark:text-slate-400">
                          {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 dark:text-[#a09a8e]">
                        {post.authorRole && <span>{post.authorRole}</span>}
                        {post.location && (
                          <>
                            <span>·</span>
                            <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                              <MapPin className="w-3 h-3" />
                              {post.location}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Post Type Badge */}
                  <div className="flex items-center gap-1.5">
                    {post.postType === 'incident' && (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Incident
                      </span>
                    )}
                    {post.postType === 'breaking' && (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/40 flex items-center gap-1">
                        <Flame className="w-3 h-3" />
                        Breaking
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold uppercase bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                      {post.language === 'sd' ? 'سنڌي' : post.language === 'ur' ? 'اردو' : 'EN'}
                    </span>
                  </div>
                </div>

                {/* Main Post Content */}
                <div
                  dir={isSindhiOrUrdu ? 'rtl' : 'ltr'}
                  className={`text-slate-800 dark:text-[#e8e4dc] leading-relaxed mb-4 ${
                    isSindhiOrUrdu
                      ? 'text-base sm:text-lg font-serif tracking-normal leading-loose font-medium'
                      : 'text-sm sm:text-base font-sans'
                  }`}
                >
                  <p className="whitespace-pre-line">{post.content}</p>
                </div>

                {/* Optional Photo Attachment */}
                {post.imageUrl && (
                  <div className="mb-4 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900">
                    <img
                      src={post.imageUrl}
                      alt="Dispatch Attachment"
                      className="w-full max-h-96 object-cover hover:scale-[1.01] transition-transform duration-300"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                )}

                {/* Social Counter Counts */}
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-[#8e8a80] pb-2 mb-2 border-b border-slate-100 dark:border-[#201f1c]">
                  <div className="flex items-center gap-1.5">
                    <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-blue-500 text-white text-[9px]">
                      👍
                    </span>
                    <span>{post.likesCount || 0}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span>{post.commentsCount || 0} comments</span>
                    <span>·</span>
                    <span>{post.sharesCount || 0} shares</span>
                  </div>
                </div>

                {/* Facebook-style Action Bar */}
                <div className="grid grid-cols-3 gap-1 pt-1">
                  <button
                    onClick={() => handleLike(post.id)}
                    className={`py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-xs font-semibold transition-all cursor-pointer ${
                      userLiked
                        ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/30'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#1f2024]'
                    }`}
                  >
                    <ThumbsUp className={`w-4 h-4 ${userLiked ? 'fill-current' : ''}`} />
                    <span>Like</span>
                  </button>

                  <button
                    onClick={() => setOpenComments((prev) => ({ ...prev, [post.id]: !prev[post.id] }))}
                    className="py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#1f2024] transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Comment</span>
                  </button>

                  <button
                    onClick={() => handleShare(post)}
                    className="py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#1f2024] transition-all cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>Share</span>
                  </button>
                </div>

                {/* Expandable Comments Drawer */}
                {commentsOpen && (
                  <div className="mt-4 pt-4 border-t border-slate-100 dark:border-[#201f1c] space-y-3 animate-in fade-in duration-200">
                    {/* Add Comment Input */}
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={commentInputs[post.id] || ''}
                        onChange={(e) =>
                          setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                        }
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddComment(post.id);
                          }
                        }}
                        placeholder="Write a comment..."
                        className="flex-1 py-2 px-3.5 rounded-xl bg-slate-100 dark:bg-[#0c0d0e] border border-slate-300 dark:border-[#2a2723] text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
                      />
                      <button
                        onClick={() => handleAddComment(post.id)}
                        disabled={submittingComment[post.id] || !commentInputs[post.id]?.trim()}
                        className="p-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 transition-colors disabled:opacity-50 cursor-pointer"
                        title="Send comment"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Comments List */}
                    {commentsList.length > 0 ? (
                      <div className="space-y-2.5 pt-2">
                        {commentsList.map((cmt) => (
                          <div
                            key={cmt.id}
                            className="p-3 rounded-xl bg-slate-50 dark:bg-[#0f1012] border border-slate-200/60 dark:border-[#1e2024] text-xs space-y-1"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1.5">
                                <span className="font-bold text-slate-900 dark:text-white">
                                  {cmt.authorName}
                                </span>
                                {cmt.isVerified && (
                                  <span
                                    className="inline-flex items-center justify-center w-3.5 h-3.5 bg-sky-500 text-white rounded-full"
                                    title="Verified Account"
                                  >
                                    <Check className="w-2 h-2 stroke-[3]" />
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-slate-400">
                                {new Date(cmt.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p className="text-slate-700 dark:text-slate-300">{cmt.content}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-400 text-center py-2">
                        No comments yet. Start the conversation!
                      </p>
                    )}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
