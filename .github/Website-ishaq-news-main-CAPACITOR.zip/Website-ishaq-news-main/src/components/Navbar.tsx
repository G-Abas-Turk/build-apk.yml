import React, { useState, useEffect } from 'react';
import { ViewRoute, AppLanguage } from '../types';
import { useAuth } from '../context/AuthContext';
import { ProfileModal } from './ProfileModal';
import {
  Search,
  Sun,
  Moon,
  Lock,
  Menu,
  X,
  LogIn,
  LogOut,
  FileText,
  Send,
  Camera,
  Check,
  Languages,
  Radio,
} from 'lucide-react';

interface NavbarProps {
  currentRoute: ViewRoute;
  onNavigate: (route: ViewRoute) => void;
  onOpenSearch: () => void;
  isDarkTheme: boolean;
  onToggleTheme: () => void;
  currentLanguage: AppLanguage;
  onLanguageChange: (lang: AppLanguage) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRoute,
  onNavigate,
  onOpenSearch,
  isDarkTheme,
  onToggleTheme,
  currentLanguage,
  onLanguageChange,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const { currentUser, userProfile, isAdmin, isRegistered, signOut } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Multi-language nav labels
  const getNavLabel = (key: string): string => {
    if (currentLanguage === 'sd') {
      const labels: Record<string, string> = {
        home: 'هوم',
        feed: 'نيوز فيڊ',
        sindh: 'سنڌ',
        pakistan: 'پاڪستان',
        world: 'دنيا',
        geopolitics: 'جيوپوليٽڪس',
        technology: 'ٽيڪنالاجي',
        opinion: 'راءِ',
        about: 'بابت',
        submit: 'خبر اماڻيو',
        login: 'لاگ ان',
      };
      return labels[key] || key;
    }
    if (currentLanguage === 'ur') {
      const labels: Record<string, string> = {
        home: 'ہوم',
        feed: 'نیوز فیڈ',
        sindh: 'سندھ',
        pakistan: 'پاکستان',
        world: 'دنیا',
        geopolitics: 'خارجہ امور',
        technology: 'ٹیکنالوجی',
        opinion: 'اداریہ',
        about: 'تعارف',
        submit: 'خبر بھیجیں',
        login: 'لاگ ان',
      };
      return labels[key] || key;
    }
    const enLabels: Record<string, string> = {
      home: 'Home',
      feed: 'Feed',
      sindh: 'Sindh',
      pakistan: 'Pakistan',
      world: 'World',
      geopolitics: 'Geopolitics',
      technology: 'Technology',
      opinion: 'Opinion',
      about: 'About',
      submit: 'Submit',
      login: 'Login',
    };
    return enLabels[key] || key;
  };

  const navLinks: Array<{ key: string; label: string; route: ViewRoute; badge?: string }> = [
    { key: 'home', label: getNavLabel('home'), route: { type: 'home' } },
    { key: 'feed', label: getNavLabel('feed'), route: { type: 'feed' }, badge: 'Live' },
    { key: 'sindh', label: getNavLabel('sindh'), route: { type: 'category', category: 'sindh' } },
    { key: 'pakistan', label: getNavLabel('pakistan'), route: { type: 'category', category: 'pakistan' } },
    { key: 'world', label: getNavLabel('world'), route: { type: 'category', category: 'world' } },
    { key: 'geopolitics', label: getNavLabel('geopolitics'), route: { type: 'category', category: 'geopolitics' } },
    { key: 'technology', label: getNavLabel('technology'), route: { type: 'category', category: 'technology' } },
    { key: 'opinion', label: getNavLabel('opinion'), route: { type: 'category', category: 'opinion' } },
    { key: 'about', label: getNavLabel('about'), route: { type: 'about' } },
  ];

  const isRouteActive = (route: ViewRoute): boolean => {
    if (route.type === 'home' && currentRoute.type === 'home') return true;
    if (route.type === 'feed' && currentRoute.type === 'feed') return true;
    if (route.type === 'about' && currentRoute.type === 'about') return true;
    if (
      route.type === 'category' &&
      currentRoute.type === 'category' &&
      route.category === currentRoute.category
    ) {
      return true;
    }
    return false;
  };

  const userAvatar =
    userProfile?.photoURL ||
    currentUser?.photoURL ||
    (isAdmin ? '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg' : null);

  const isVerifiedUser = !!(userProfile?.isVerified || isAdmin);

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isDarkTheme
            ? isScrolled
              ? 'bg-[#0c0d0e]/95 backdrop-blur-md shadow-xl border-b border-[#2a2723]'
              : 'bg-[#0c0d0e] border-b border-[#1f1e1b]'
            : isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-md border-b border-slate-200'
            : 'bg-white border-b border-slate-200'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Brand Identity / Founder Crest */}
            <button
              onClick={() => onNavigate({ type: 'home' })}
              className="flex items-center gap-3 text-left group cursor-pointer"
            >
              <div className="relative">
                <img
                  src={
                    isAdmin && userProfile?.photoURL
                      ? userProfile.photoURL
                      : '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg'
                  }
                  alt="Ishaq Turk"
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-500/60 group-hover:ring-amber-500 transition-all shadow-md shrink-0"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
                  }}
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 border-2 border-white dark:border-[#0c0d0e]" />
              </div>
              <div>
                <span className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-white font-display group-hover:text-amber-600 dark:group-hover:text-[#e8cf78] transition-colors uppercase leading-none block">
                  NEWS BY ISHAQ
                </span>
                <span className="text-[10px] uppercase tracking-widest text-amber-600 dark:text-[#d4af37] font-semibold hidden sm:block mt-0.5">
                  By Ishaq Turk · Masu Bhurgari, Sindh
                </span>
              </div>
            </button>

            {/* Navigation Links (Desktop) */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-[#a8a49c]">
              {navLinks.map((item) => {
                const active = isRouteActive(item.route);
                return (
                  <button
                    key={item.key}
                    onClick={() => onNavigate(item.route)}
                    className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                      active
                        ? 'text-amber-700 dark:text-[#f5e6b3] bg-amber-500/15 dark:bg-[#22211c] border border-amber-500/35 shadow-sm font-bold'
                        : 'hover:text-slate-900 dark:hover:text-[#f5e6b3] hover:bg-slate-100 dark:hover:bg-[#1a1918]/60'
                    }`}
                  >
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase bg-emerald-500 text-white">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Action Tools */}
            <div className="flex items-center gap-2">
              {/* Language Switcher */}
              <div className="relative">
                <button
                  onClick={() => setLangMenuOpen(!langMenuOpen)}
                  title="Switch Language (سنڌي / اردو / English)"
                  className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-100 dark:bg-[#1a1918] hover:bg-slate-200 dark:hover:bg-[#232220] border border-slate-200 dark:border-[#2b2825] text-slate-700 dark:text-[#cfcac2] text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <Languages className="w-3.5 h-3.5 text-amber-500" />
                  <span className="font-bold">
                    {currentLanguage === 'sd' ? 'سنڌي' : currentLanguage === 'ur' ? 'اردو' : 'EN'}
                  </span>
                </button>

                {langMenuOpen && (
                  <div className="absolute right-0 mt-2 w-36 rounded-xl bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723] shadow-xl py-1 z-50 animate-in fade-in duration-150">
                    <button
                      onClick={() => {
                        onLanguageChange('en');
                        setLangMenuOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 ${
                        currentLanguage === 'en' ? 'font-bold text-amber-600 dark:text-amber-400' : 'text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span>English</span>
                      {currentLanguage === 'en' && <Check className="w-3 h-3 text-amber-500" />}
                    </button>
                    <button
                      onClick={() => {
                        onLanguageChange('sd');
                        setLangMenuOpen(false);
                      }}
                      className={`w-full text-right px-3.5 py-2 text-xs font-serif flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 ${
                        currentLanguage === 'sd' ? 'font-bold text-amber-600 dark:text-amber-400' : 'text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span>سنڌي (Sindhi)</span>
                      {currentLanguage === 'sd' && <Check className="w-3 h-3 text-amber-500" />}
                    </button>
                    <button
                      onClick={() => {
                        onLanguageChange('ur');
                        setLangMenuOpen(false);
                      }}
                      className={`w-full text-right px-3.5 py-2 text-xs font-serif flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 ${
                        currentLanguage === 'ur' ? 'font-bold text-amber-600 dark:text-amber-400' : 'text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span>اردو (Urdu)</span>
                      {currentLanguage === 'ur' && <Check className="w-3 h-3 text-amber-500" />}
                    </button>
                  </div>
                )}
              </div>

              {/* Search Action */}
              <button
                onClick={onOpenSearch}
                title="Search articles & feed (Ctrl+K)"
                className="p-2 text-slate-600 dark:text-[#a8a49c] hover:text-amber-600 dark:hover:text-[#d4af37] hover:bg-slate-100 dark:hover:bg-[#1a1918] rounded-xl transition-colors flex items-center gap-1.5 text-xs font-medium cursor-pointer"
              >
                <Search className="w-4 h-4" />
                <span className="hidden sm:inline font-serif">Search</span>
              </button>

              {/* Feed Dispatch Shortcut */}
              <button
                onClick={() => onNavigate({ type: 'feed' })}
                title="News Feed"
                className="hidden sm:flex items-center gap-1 py-1.5 px-3 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30 text-xs font-bold transition-all cursor-pointer"
              >
                <Radio className="w-3.5 h-3.5 text-blue-500" />
                <span>Feed</span>
              </button>

              {/* Submit Article Action */}
              <button
                onClick={() => onNavigate({ type: 'submit-article' })}
                className="hidden sm:flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs font-semibold transition-all cursor-pointer font-serif"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{getNavLabel('submit')}</span>
              </button>

              {/* Dark / Light Mode Toggle Button */}
              <button
                onClick={onToggleTheme}
                title={isDarkTheme ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                className="p-2 text-slate-600 dark:text-[#a8a49c] hover:text-amber-600 dark:hover:text-[#d4af37] hover:bg-slate-100 dark:hover:bg-[#1a1918] rounded-xl transition-colors cursor-pointer"
              >
                {isDarkTheme ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
              </button>

              {/* User Authenticated Actions */}
              {isRegistered && (currentUser || userProfile || isAdmin) ? (
                <div className="hidden md:flex items-center gap-2">
                  <button
                    onClick={() => onNavigate({ type: 'my-submissions' })}
                    title="My Submissions"
                    className="py-1.5 px-2.5 rounded-xl bg-slate-100 dark:bg-[#1a1918] hover:bg-slate-200 dark:hover:bg-[#252320] text-slate-700 dark:text-[#cfcac2] text-xs font-medium flex items-center gap-1 cursor-pointer border border-slate-200 dark:border-[#2b2825]"
                  >
                    <FileText className="w-3.5 h-3.5 text-amber-500" />
                    <span>My Stories</span>
                  </button>

                  {isAdmin && (
                    <button
                      onClick={() => onNavigate({ type: 'admin', subSection: 'dashboard' })}
                      title="Admin Executive Console"
                      className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 text-stone-950 text-xs font-bold flex items-center gap-1.5 shadow-md shadow-amber-500/20 hover:brightness-110 transition-all cursor-pointer"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Admin</span>
                    </button>
                  )}

                  {/* Profile Picture & PFP Edit Trigger */}
                  <button
                    onClick={() => setProfileModalOpen(true)}
                    title={`Edit ${userProfile?.name || 'Profile'} Picture`}
                    className="relative group p-0.5 rounded-full ring-2 ring-amber-500/40 hover:ring-amber-500 transition-all cursor-pointer flex items-center justify-center bg-white dark:bg-[#141517]"
                  >
                    {userAvatar ? (
                      <img
                        src={userAvatar}
                        alt="Profile"
                        className="w-8 h-8 rounded-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
                        }}
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-xs font-bold text-amber-600 dark:text-amber-400">
                        {userProfile?.name?.charAt(0) || 'U'}
                      </div>
                    )}
                    {isVerifiedUser && (
                      <span
                        className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-sky-500 text-white flex items-center justify-center ring-1 ring-white dark:ring-[#0c0d0e]"
                        title="Verified Blue Tick"
                      >
                        <Check className="w-2 h-2 stroke-[3]" />
                      </span>
                    )}
                  </button>

                  <button
                    onClick={() => signOut()}
                    title="Sign Out"
                    className="p-2 text-slate-500 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-[#1a1918] rounded-xl transition-colors cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="hidden sm:flex items-center gap-1.5">
                  <button
                    onClick={() => onNavigate({ type: 'login' })}
                    className="py-1.5 px-3 rounded-xl bg-slate-100 dark:bg-[#1a1918] hover:bg-slate-200 dark:hover:bg-[#252320] text-slate-800 dark:text-[#cfcac2] text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer border border-slate-200 dark:border-[#2a2723]"
                  >
                    <LogIn className="w-3.5 h-3.5 text-amber-500" />
                    <span>{getNavLabel('login')}</span>
                  </button>
                  <button
                    onClick={() => onNavigate({ type: 'admin-login' })}
                    title="Editorial Admin Login"
                    className="p-1.5 text-slate-500 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-[#1a1918] rounded-xl transition-colors cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Mobile Menu Toggle Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-slate-700 dark:text-[#cfcac2] hover:bg-slate-100 dark:hover:bg-[#1a1918] rounded-xl cursor-pointer"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Drawer */}
          {mobileMenuOpen && (
            <div className="lg:hidden border-t border-slate-200 dark:border-[#2a2723] bg-white/95 dark:bg-[#0c0d0e]/95 backdrop-blur-xl px-4 py-4 space-y-1 animate-in slide-in-from-top-2 duration-200">
              {navLinks.map((item) => {
                const active = isRouteActive(item.route);
                return (
                  <button
                    key={item.key}
                    onClick={() => {
                      onNavigate(item.route);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold uppercase tracking-wider flex items-center justify-between cursor-pointer ${
                      active
                        ? 'text-amber-700 dark:text-[#f5e6b3] bg-amber-500/15 dark:bg-[#22211c] border border-amber-500/35 font-bold'
                        : 'text-slate-700 dark:text-[#cfcac2] hover:bg-slate-100 dark:hover:bg-[#1a1918]'
                    }`}
                  >
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-emerald-500 text-white">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}

              <div className="pt-3 mt-2 border-t border-slate-200 dark:border-[#232220] space-y-2">
                <button
                  onClick={() => {
                    onNavigate({ type: 'feed' });
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-blue-500/15 text-blue-700 dark:text-blue-300 flex items-center gap-2 cursor-pointer"
                >
                  <Radio className="w-4 h-4 text-blue-500" />
                  <span>Open News Feed (Facebook Style)</span>
                </button>

                <button
                  onClick={() => {
                    onNavigate({ type: 'submit-article' });
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-amber-500/15 text-amber-700 dark:text-amber-300 flex items-center gap-2 cursor-pointer font-serif"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{getNavLabel('submit')}</span>
                </button>

                {isRegistered && (currentUser || userProfile || isAdmin) ? (
                  <>
                    <button
                      onClick={() => {
                        setProfileModalOpen(true);
                        setMobileMenuOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-[#1a1918] border border-slate-200 dark:border-[#2b2825] text-amber-600 dark:text-[#d4af37] flex items-center gap-2.5 cursor-pointer"
                    >
                      <Camera className="w-4 h-4 text-amber-500" />
                      <span>Change Profile Picture & Details</span>
                    </button>

                    <button
                      onClick={() => {
                        onNavigate({ type: 'my-submissions' });
                        setMobileMenuOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-[#cfcac2] hover:bg-slate-100 dark:hover:bg-[#1a1918] flex items-center gap-2 cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5 text-amber-500" />
                      <span>My Submissions</span>
                    </button>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          onNavigate({ type: 'admin', subSection: 'dashboard' });
                          setMobileMenuOpen(false);
                        }}
                        className="w-full text-left px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-500/20 text-amber-700 dark:text-amber-300 flex items-center gap-2 cursor-pointer"
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>Admin Executive Console</span>
                      </button>
                    )}

                    <button
                      onClick={async () => {
                        await signOut();
                        setMobileMenuOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2 cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out ({userProfile?.name || 'User'})</span>
                    </button>
                  </>
                ) : (
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => {
                        onNavigate({ type: 'login' });
                        setMobileMenuOpen(false);
                      }}
                      className="flex-1 py-2 text-center rounded-xl bg-slate-100 dark:bg-[#1a1918] text-xs text-slate-800 dark:text-white font-semibold cursor-pointer border border-slate-200 dark:border-[#2b2825]"
                    >
                      Log In
                    </button>
                    <button
                      onClick={() => {
                        onNavigate({ type: 'register' });
                        setMobileMenuOpen(false);
                      }}
                      className="flex-1 py-2 text-center rounded-xl bg-amber-500 text-xs text-stone-950 font-bold cursor-pointer shadow-sm"
                    >
                      Register
                    </button>
                    <button
                      onClick={() => {
                        onNavigate({ type: 'admin-login' });
                        setMobileMenuOpen(false);
                      }}
                      className="p-2 text-center rounded-xl bg-amber-500/15 text-amber-700 dark:text-amber-300 text-xs font-bold border border-amber-500/35 cursor-pointer"
                      title="Admin"
                    >
                      <Lock className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Global Profile & Picture Modal */}
      <ProfileModal
        isOpen={profileModalOpen}
        onClose={() => setProfileModalOpen(false)}
      />
    </>
  );
};
