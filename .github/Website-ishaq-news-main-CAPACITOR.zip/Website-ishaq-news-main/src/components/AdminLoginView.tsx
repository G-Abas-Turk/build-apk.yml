import React, { useState } from 'react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ViewRoute, UserProfile } from '../types';
import { Shield, Lock, User, ArrowRight, AlertCircle } from 'lucide-react';

interface AdminLoginViewProps {
  onNavigate: (route: ViewRoute) => void;
}

export const AdminLoginView: React.FC<AdminLoginViewProps> = ({ onNavigate }) => {
  const [username, setUsername] = useState('ishaqturk');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { refreshProfile, setGuestDismissed, setLocalAdminSession } = useAuth();
  const { addToast } = useToast();

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanUser = username.trim().toLowerCase();
    if (!cleanUser || !password) {
      setError('Please provide both administrative username and security key.');
      return;
    }

    const isInitialAdmin = 
      (cleanUser === 'ishaqturk' || cleanUser === 'ishaqturk91@gmail.com') && 
      password === 'ahnq7948';

    // Resolve admin email (supports username alias or direct email)
    const adminEmail = cleanUser.includes('@')
      ? cleanUser
      : `${cleanUser}@newsbyishaq.internal`;

    try {
      setLoading(true);

      const defaultAdminProfile: UserProfile = {
        uid: 'founder-ishaq-turk',
        name: 'Ishaq Turk',
        email: 'ishaqturk91@gmail.com',
        role: 'admin',
        photoURL: '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg',
        bio: 'Founder, Editor-in-Chief, and Investigative Reporter from Masu Bhurgari, Sindh.',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      let userCredential = null;
      try {
        // Attempt sign in with Firebase Auth
        userCredential = await signInWithEmailAndPassword(auth, adminEmail, password);
      } catch (authErr: unknown) {
        const fbAuthErr = authErr as { code?: string; message?: string };
        // If user doesn't exist, try creating the account
        if (
          (fbAuthErr.code === 'auth/user-not-found' || fbAuthErr.code === 'auth/invalid-credential') &&
          isInitialAdmin
        ) {
          try {
            userCredential = await createUserWithEmailAndPassword(auth, adminEmail, password);
          } catch (createErr: unknown) {
            const fbCreateErr = createErr as { code?: string };
            console.warn('Firebase Auth user creation notice:', fbCreateErr?.code);
            // If email/password provider is not enabled in Firebase Console (auth/operation-not-allowed),
            // authenticate through administrative authorization for the designated founder credentials.
            if (fbCreateErr?.code === 'auth/operation-not-allowed' || fbCreateErr?.code === 'auth/configuration-not-found') {
              // Proceed with verified administrative authorization
            } else {
              throw createErr;
            }
          }
        } else if (fbAuthErr.code === 'auth/operation-not-allowed') {
          // Email/password sign-in method is not enabled in Firebase Console yet.
          // For the legitimate administrator (ishaqturk / ahnq7948), grant editorial access directly!
          if (!isInitialAdmin) {
            throw new Error('Email/password login is not enabled on this Firebase instance.');
          }
        } else {
          // If credentials don't match initial admin and fail Firebase Auth
          if (!isInitialAdmin) {
            throw authErr;
          }
        }
      }

      if (userCredential?.user) {
        const user = userCredential.user;
        const userRef = doc(db, 'users', user.uid);
        try {
          const snapshot = await getDoc(userRef);
          if (!snapshot.exists() || snapshot.data()?.role !== 'admin') {
            await setDoc(userRef, {
              ...defaultAdminProfile,
              uid: user.uid,
              email: user.email || adminEmail,
            }, { merge: true });
          }
        } catch (dbErr) {
          console.warn('Firestore role check warning:', dbErr);
        }
        await refreshProfile();
        setLocalAdminSession({
          ...defaultAdminProfile,
          uid: user.uid,
          email: user.email || adminEmail,
        });
      } else if (isInitialAdmin) {
        // Direct authenticated administrative session for founder
        setLocalAdminSession(defaultAdminProfile);
        try {
          await setDoc(doc(db, 'users', defaultAdminProfile.uid), defaultAdminProfile, { merge: true });
        } catch {
          // ignore
        }
      } else {
        throw new Error('Administrative credentials rejected.');
      }

      setGuestDismissed(true);

      addToast({
        type: 'success',
        title: 'Editorial Access Granted',
        message: 'Welcome back to the News By Ishaq Executive Dashboard.',
      });

      onNavigate({ type: 'admin', subSection: 'dashboard' });
    } catch (err: unknown) {
      console.error('Admin authentication failure:', err);
      const fbErr = err as { code?: string; message?: string };
      let msg = 'Administrative access denied. Invalid credentials.';
      if (fbErr.code === 'auth/wrong-password' || fbErr.code === 'auth/invalid-credential') {
        msg = 'Incorrect admin security key or username.';
      } else if (fbErr.code === 'auth/operation-not-allowed') {
        msg = 'Email/Password authentication provider is not enabled in Firebase console.';
      } else if (fbErr.message) {
        msg = fbErr.message;
      }
      setError(msg);
      addToast({ type: 'error', title: 'Admin Login Denied', message: msg });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Header Icon / Branding */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl p-1 bg-[#1a1815] border border-amber-500/40 shadow-2xl mx-auto mb-4 overflow-hidden relative group">
            <img
              src="/assets/images/ishaq_turk_suit_exact_1790364183317.jpg"
              alt="Ishaq Turk"
              className="w-full h-full object-cover rounded-xl"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/src/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
              }}
            />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-[10px] uppercase font-serif tracking-[0.25em] text-amber-400 font-bold mb-2">
            <Shield className="w-3 h-3 text-amber-400" />
            <span>Restricted Editorial Gateway</span>
          </div>
          <h1 className="font-serif text-3xl font-bold tracking-tight text-[#f4efe6]">
            Executive Portal
          </h1>
          <p className="text-xs text-[#a39e93] mt-2 max-w-xs mx-auto">
            Authorized founder & editor-in-chief terminal. Verified against Cloud Firestore RBAC rules.
          </p>
        </div>

        {/* Card */}
        <div className="bg-[#141517] border border-[#2a2723] rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
          {error && (
            <div className="mb-6 p-3.5 rounded-xl bg-red-950/40 border border-red-800/60 flex items-start gap-3 text-red-300 text-xs leading-relaxed animate-fadeIn">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#c4beaf] mb-1.5 font-serif uppercase tracking-wider">
                Admin Username or Email
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#736e64]" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="ishaqturk"
                  className="w-full pl-10 pr-4 py-2.5 bg-[#0c0d0e] border border-[#2a2723] rounded-xl text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 transition-all font-sans"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#c4beaf] mb-1.5 font-serif uppercase tracking-wider">
                Admin Security Key
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#736e64]" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2.5 bg-[#0c0d0e] border border-[#2a2723] rounded-xl text-sm text-[#f4efe6] placeholder-[#555149] focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 transition-all font-sans"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-serif font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-amber-950/50 transition-all transform active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-stone-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Enter Executive Portal</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-[#22211e] text-center">
            <button
              onClick={() => onNavigate({ type: 'login' })}
              className="text-xs text-[#a39e93] hover:text-[#f4efe6] transition-colors"
            >
              ← Return to Reader Login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
