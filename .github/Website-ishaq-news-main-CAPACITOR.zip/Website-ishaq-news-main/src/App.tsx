import React, { useState, useEffect } from 'react';
import { ViewRoute, Article, SiteSettings, AppLanguage } from './types';
import { firebaseData } from './services/firebaseDataService';
import { useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { TrendingBar } from './components/TrendingBar';
import { ArticleCard } from './components/ArticleCard';
import { CategorySection } from './components/CategorySection';
import { ArticleView } from './components/ArticleView';
import { CategoryView } from './components/CategoryView';
import { AboutView } from './components/AboutView';
import { ContactView } from './components/ContactView';
import { LegalView } from './components/LegalView';
import { SearchModal } from './components/SearchModal';
import { Footer } from './components/Footer';
import { LoginView } from './components/LoginView';
import { RegisterView } from './components/RegisterView';
import { AdminLoginView } from './components/AdminLoginView';
import { SubmitArticleView } from './components/SubmitArticleView';
import { MySubmissionsView } from './components/MySubmissionsView';
import { AdminDashboardView } from './components/AdminDashboardView';
import { GuestWelcomeModal } from './components/GuestWelcomeModal';
import { NewsFeedView } from './components/NewsFeedView';
import { Analytics } from '@vercel/analytics/react';
import { ArrowRight, Bell, Newspaper, Radio } from 'lucide-react';

export default function App() {
  const [route, setRoute] = useState<ViewRoute>({ type: 'home' });
  const [homeViewTab, setHomeViewTab] = useState<'articles' | 'feed'>('articles');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // DEFAULT LIGHT MODE: false unless 'dark' explicitly stored
  const [isDarkTheme, setIsDarkTheme] = useState(() => {
    return localStorage.getItem('news_by_ishaq_theme') === 'dark';
  });

  // MULTI-LANGUAGE: defaults to 'en' or saved choice
  const [currentLanguage, setCurrentLanguage] = useState<AppLanguage>(() => {
    return (localStorage.getItem('news_by_ishaq_lang') as AppLanguage) || 'en';
  });

  const { currentUser, guestDismissed, isRegistered } = useAuth();
  const [isGuestModalOpen, setIsGuestModalOpen] = useState(false);

  // Firestore live state
  const [articles, setArticles] = useState<Article[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);

  // Load Firestore data
  const loadData = async () => {
    try {
      const [artList, settings] = await Promise.all([
        firebaseData.getPublishedArticles(),
        firebaseData.getSiteSettings(),
      ]);
      setArticles(artList);
      setSiteSettings(settings);
    } catch (err) {
      console.error('Failed to load published articles:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Show Guest Welcome popup for first-time visitors who are not logged in
  useEffect(() => {
    if (!loading && !isRegistered && !currentUser && !guestDismissed) {
      const timer = setTimeout(() => {
        setIsGuestModalOpen(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [loading, isRegistered, currentUser, guestDismissed]);

  // Theme application (Default light mode)
  useEffect(() => {
    if (isDarkTheme) {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
      localStorage.setItem('news_by_ishaq_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
      localStorage.setItem('news_by_ishaq_theme', 'light');
    }
  }, [isDarkTheme]);

  const handleLanguageChange = (lang: AppLanguage) => {
    setCurrentLanguage(lang);
    localStorage.setItem('news_by_ishaq_lang', lang);
  };

  // URL Hash routing listener & synchronization
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace(/^#\/?/, '');
      if (!hash) {
        setRoute({ type: 'home' });
        document.title = 'NEWS BY ISHAQ — Independent News, Geopolitics & Sindh Affairs';
        return;
      }

      if (hash === 'feed') {
        setRoute({ type: 'feed' });
        document.title = 'Live News Feed & Incidents — NEWS BY ISHAQ';
        return;
      }

      if (hash.startsWith('article/')) {
        const slug = hash.replace('article/', '');
        setRoute({ type: 'article', slug });
        return;
      }

      if (hash.startsWith('category/')) {
        const cat = hash.replace('category/', '');
        setRoute({ type: 'category', category: cat });
        document.title = `${cat.toUpperCase()} — NEWS BY ISHAQ`;
        return;
      }

      const validCategories = ['sindh', 'pakistan', 'world', 'geopolitics', 'technology', 'opinion'];
      if (validCategories.includes(hash)) {
        setRoute({ type: 'category', category: hash });
        document.title = `${hash.toUpperCase()} — NEWS BY ISHAQ`;
        return;
      }

      if (hash === 'about') {
        setRoute({ type: 'about' });
        document.title = 'About Ishaq Turk — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'contact') {
        setRoute({ type: 'contact' });
        document.title = 'Contact — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'login') {
        setRoute({ type: 'login' });
        document.title = 'Reader Sign In — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'register') {
        setRoute({ type: 'register' });
        document.title = 'Create Reader Account — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'admin-login') {
        setRoute({ type: 'admin-login' });
        document.title = 'Editorial Admin Login — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'submit-article') {
        setRoute({ type: 'submit-article' });
        document.title = 'Submit Article — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'my-submissions') {
        setRoute({ type: 'my-submissions' });
        document.title = 'My Submissions — NEWS BY ISHAQ';
        return;
      }

      if (hash.startsWith('admin')) {
        setRoute({ type: 'admin' });
        document.title = 'Executive Publishing Console — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'privacy') {
        setRoute({ type: 'privacy' });
        document.title = 'Privacy Policy — NEWS BY ISHAQ';
        return;
      }

      if (hash === 'terms') {
        setRoute({ type: 'terms' });
        document.title = 'Terms of Service — NEWS BY ISHAQ';
        return;
      }

      setRoute({ type: 'home' });
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateTo = (newRoute: ViewRoute) => {
    setRoute(newRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });

    let hash = '';
    switch (newRoute.type) {
      case 'home':
        hash = '';
        document.title = 'NEWS BY ISHAQ — Independent News, Geopolitics & Sindh Affairs';
        break;
      case 'feed':
        hash = '#/feed';
        document.title = 'Live News Feed & Incidents — NEWS BY ISHAQ';
        break;
      case 'category':
        hash = `#/${newRoute.category}`;
        document.title = `${newRoute.category.toUpperCase()} — NEWS BY ISHAQ`;
        break;
      case 'article':
        hash = `#/article/${newRoute.slug}`;
        break;
      case 'about':
        hash = '#/about';
        document.title = 'About Ishaq Turk — NEWS BY ISHAQ';
        break;
      case 'contact':
        hash = '#/contact';
        document.title = 'Contact — NEWS BY ISHAQ';
        break;
      case 'login':
        hash = '#/login';
        document.title = 'Reader Sign In — NEWS BY ISHAQ';
        break;
      case 'register':
        hash = '#/register';
        document.title = 'Create Reader Account — NEWS BY ISHAQ';
        break;
      case 'admin-login':
        hash = '#/admin-login';
        document.title = 'Editorial Admin Login — NEWS BY ISHAQ';
        break;
      case 'submit-article':
        hash = '#/submit-article';
        document.title = 'Submit Article — NEWS BY ISHAQ';
        break;
      case 'my-submissions':
        hash = '#/my-submissions';
        document.title = 'My Submissions — NEWS BY ISHAQ';
        break;
      case 'admin':
        hash = '#/admin';
        document.title = 'Executive Publishing Console — NEWS BY ISHAQ';
        break;
      case 'privacy':
        hash = '#/privacy';
        document.title = 'Privacy Policy — NEWS BY ISHAQ';
        break;
      case 'terms':
        hash = '#/terms';
        document.title = 'Terms of Service — NEWS BY ISHAQ';
        break;
    }

    if (window.location.hash !== hash) {
      window.history.pushState(null, '', hash || window.location.pathname);
    }
  };

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filter articles for homepage
  const featuredArticle = articles.find((a) => a.isFeatured) || articles[0];
  const topCompanionArticles = articles.filter((a) => a.id !== featuredArticle?.id).slice(0, 3);
  const trendingArticles = articles.filter((a) => a.isTrending).slice(0, 5);
  const latestArticles = articles.filter((a) => a.id !== featuredArticle?.id).slice(0, 4);

  // Category specific articles
  const sindhArticles = articles.filter((a) => a.category.toLowerCase() === 'sindh');
  const pakistanArticles = articles.filter((a) => a.category.toLowerCase() === 'pakistan');
  const geopoliticsArticles = articles.filter((a) => a.category.toLowerCase() === 'geopolitics');
  const worldArticles = articles.filter((a) => a.category.toLowerCase() === 'world');
  const techArticles = articles.filter((a) => a.category.toLowerCase() === 'technology');
  const opinionArticles = articles.filter((a) => a.category.toLowerCase() === 'opinion' || a.type === 'opinion' || a.type === 'analysis');

  return (
    <div
      className={`min-h-screen ${
        isDarkTheme ? 'bg-[#0c0d0e] text-[#e6e2d8]' : 'bg-[#f4f6f8] text-[#1c1e21]'
      } flex flex-col liquid-mesh transition-colors duration-200`}
    >
      {/* Site-wide Live Announcement Banner */}
      {siteSettings?.announcementActive && siteSettings?.announcement && (
        <div
          className={`py-1.5 px-4 text-center text-xs flex items-center justify-center gap-2 ${
            isDarkTheme
              ? 'bg-gradient-to-r from-[#1c1a16] via-[#141412] to-[#1c1a16] border-b border-[#d4af37]/20 text-[#f5e6b3]'
              : 'bg-amber-100/90 border-b border-amber-200 text-amber-950 font-medium'
          }`}
        >
          <Bell className="w-3.5 h-3.5 text-amber-600 dark:text-[#d4af37] shrink-0" />
          <span>{siteSettings.announcement}</span>
        </div>
      )}

      {/* Sticky Top Header */}
      <Navbar
        currentRoute={route}
        onNavigate={navigateTo}
        onOpenSearch={() => setIsSearchOpen(true)}
        isDarkTheme={isDarkTheme}
        onToggleTheme={() => setIsDarkTheme((prev) => !prev)}
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {route.type === 'home' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8 animate-in fade-in duration-300">
            {/* Facebook-style Feed vs Major Stories Switcher Bar */}
            <div className="flex items-center justify-center mb-8">
              <div className="p-1 rounded-2xl bg-white dark:bg-[#141517] border border-slate-200 dark:border-[#2a2723] shadow-sm flex items-center gap-1">
                <button
                  onClick={() => setHomeViewTab('articles')}
                  className={`py-2 px-4 sm:px-6 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                    homeViewTab === 'articles'
                      ? 'bg-amber-500 text-stone-950 shadow-md font-extrabold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Newspaper className="w-4 h-4" />
                  <span>Feature Stories & Investigations</span>
                </button>
                <button
                  onClick={() => setHomeViewTab('feed')}
                  className={`py-2 px-4 sm:px-6 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                    homeViewTab === 'feed'
                      ? 'bg-amber-500 text-stone-950 shadow-md font-extrabold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Radio className="w-4 h-4 text-blue-500" />
                  <span>Live News Feed (Facebook Style)</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </button>
              </div>
            </div>

            {homeViewTab === 'feed' ? (
              <NewsFeedView
                onNavigate={navigateTo}
                currentLanguage={currentLanguage}
                onLanguageChange={handleLanguageChange}
              />
            ) : (
              <>
                {/* Top Hero News Area */}
                {featuredArticle && (
                  <HeroSection
                    featuredArticle={featuredArticle as any}
                    companionArticles={topCompanionArticles as any}
                    onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                  />
                )}

                {/* Trending Section (01 - 05) */}
                {trendingArticles.length > 0 && (
                  <TrendingBar
                    articles={trendingArticles as any}
                    onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                  />
                )}

                {/* Section: LATEST NEWS */}
                <section className="my-14">
                  <div className="flex items-center justify-between pb-3 mb-6 border-b border-amber-500/20">
                    <div>
                      <h2 className="text-xl sm:text-2xl font-black uppercase text-slate-900 dark:text-white font-display tracking-tight">
                        LATEST NEWS & DISPATCHES
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-[#a09a8e] mt-0.5 font-editorial">
                        Live reporting from Cloud Firestore across Sindh, Pakistan, and international corridors.
                      </p>
                    </div>
                  </div>

                  {/* Varied Card Sizes News Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {latestArticles.map((article, idx) => (
                      <div key={article.id} className={idx === 0 ? 'md:col-span-2' : ''}>
                        <ArticleCard
                          article={article as any}
                          onClick={() => navigateTo({ type: 'article', slug: article.slug || article.id })}
                          variant={idx === 0 ? 'horizontal' : 'standard'}
                        />
                      </div>
                    ))}
                  </div>
                </section>

                {/* Section: SINDH */}
                <CategorySection
                  category="sindh"
                  title="SINDH REPORTING & REGIONAL AFFAIRS"
                  subtitle="Ground coverage from Hyderabad, Karachi, Matiari, agrarian reforms, water conservation, and cultural heritage."
                  actionText="View all Sindh news →"
                  articles={sindhArticles as any}
                  onSelectCategory={(cat) => navigateTo({ type: 'category', category: cat })}
                  onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                />

                {/* Section: GEOPOLITICS */}
                <CategorySection
                  category="geopolitics"
                  title="GEOPOLITICS & MARITIME STRATEGY"
                  subtitle="Examining alliances, naval choke points, trade corridors, and how middle powers navigate multipolar competition."
                  actionText="Explore geopolitics →"
                  articles={geopoliticsArticles as any}
                  onSelectCategory={(cat) => navigateTo({ type: 'category', category: cat })}
                  onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                  sophisticated={true}
                />

                {/* Section: PAKISTAN */}
                <CategorySection
                  category="pakistan"
                  title="PAKISTAN NATIONAL AFFAIRS"
                  subtitle="Federal policies, energy grid transformations, economic structural shifts, and governance reforms."
                  actionText="View all Pakistan news →"
                  articles={pakistanArticles as any}
                  onSelectCategory={(cat) => navigateTo({ type: 'category', category: cat })}
                  onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                />

                {/* Section: WORLD */}
                <CategorySection
                  category="world"
                  title="WORLD & INTERNATIONAL AFFAIRS"
                  subtitle="Global diplomatic summits, United Nations developments, multilateral accords, and continental shifts."
                  actionText="View all World news →"
                  articles={worldArticles as any}
                  onSelectCategory={(cat) => navigateTo({ type: 'category', category: cat })}
                  onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                />

                {/* Section: TECHNOLOGY */}
                <CategorySection
                  category="technology"
                  title="TECHNOLOGY & SOVEREIGN SILICON"
                  subtitle="Artificial intelligence, semiconductor architecture, open computing weights, and regional digital hubs."
                  actionText="Explore technology →"
                  articles={techArticles as any}
                  onSelectCategory={(cat) => navigateTo({ type: 'category', category: cat })}
                  onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                />

                {/* Section: OPINION & ANALYSIS */}
                <CategorySection
                  category="opinion"
                  title="OPINION & STRATEGIC ANALYSIS"
                  subtitle="Personal essays and rigorous structural analyses clearly distinguished from factual dispatches."
                  actionText="Read all opinions & analyses →"
                  articles={opinionArticles as any}
                  onSelectCategory={(cat) => navigateTo({ type: 'category', category: cat })}
                  onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
                />

                {/* Independent Founder Spotlight Strip */}
                <section className="my-16 p-8 rounded-2xl glass-panel border border-amber-500/25 flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 max-w-2xl text-center sm:text-left">
                    <img
                      src="/assets/images/ishaq_turk_suit_exact_1790364183317.jpg"
                      alt="Ishaq Turk"
                      className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-2 ring-amber-500/60 shadow-xl shrink-0"
                    />
                    <div>
                      <span className="text-[11px] font-bold text-amber-600 dark:text-[#d4af37] uppercase tracking-widest block mb-1">
                        Masu Bhurgari, Sindh · Independent Platform
                      </span>
                      <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white font-display">
                        "News By Ishaq is created to deliver grounded, serious journalism without corporate noise."
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 dark:text-[#b8b3a7] mt-2 font-editorial">
                        Founded and curated by Ishaq Turk to explore Sindh, Pakistan, international geopolitics, and emerging technology through an authentic, independent lens.
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => navigateTo({ type: 'about' })}
                    className="shrink-0 px-5 py-2.5 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:brightness-110 text-stone-950 rounded-xl text-xs font-bold uppercase tracking-wider shadow-md transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <span>Read Ishaq's Story</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </section>
              </>
            )}
          </div>
        )}

        {/* Dedicated News Feed Route */}
        {route.type === 'feed' && (
          <NewsFeedView
            onNavigate={navigateTo}
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
          />
        )}

        {/* Dedicated Article Page */}
        {route.type === 'article' && (
          <ArticleView
            slug={route.slug}
            onNavigate={navigateTo}
          />
        )}

        {/* Dedicated Category Page */}
        {route.type === 'category' && (
          <CategoryView
            category={route.category}
            onNavigate={navigateTo}
          />
        )}

        {/* About Page */}
        {route.type === 'about' && (
          <AboutView
            onNavigate={navigateTo}
          />
        )}

        {/* Contact Page */}
        {route.type === 'contact' && (
          <ContactView
            onNavigate={navigateTo}
          />
        )}

        {/* Reader Sign In */}
        {route.type === 'login' && (
          <LoginView
            onNavigate={navigateTo}
          />
        )}

        {/* Reader Registration */}
        {route.type === 'register' && (
          <RegisterView
            onNavigate={navigateTo}
          />
        )}

        {/* Admin Login Gateway */}
        {route.type === 'admin-login' && (
          <AdminLoginView
            onNavigate={navigateTo}
          />
        )}

        {/* User Submit Article */}
        {route.type === 'submit-article' && (
          <SubmitArticleView
            onNavigate={navigateTo}
          />
        )}

        {/* User My Submissions */}
        {route.type === 'my-submissions' && (
          <MySubmissionsView
            onNavigate={navigateTo}
          />
        )}

        {/* Full Admin Publishing Console */}
        {route.type === 'admin' && (
          <AdminDashboardView
            initialSubSection={route.subSection}
            onNavigate={navigateTo}
          />
        )}

        {/* Legal Pages */}
        {(route.type === 'privacy' || route.type === 'terms') && (
          <LegalView
            type={route.type}
            onNavigate={navigateTo}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer onNavigate={navigateTo} />

      {/* Instant Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectArticle={(slug) => navigateTo({ type: 'article', slug })}
      />

      {/* Guest Welcome Modal */}
      <GuestWelcomeModal
        isOpen={isGuestModalOpen}
        onClose={() => setIsGuestModalOpen(false)}
        onNavigate={navigateTo}
      />

      {/* Vercel Web Analytics */}
      <Analytics />
    </div>
  );
}
