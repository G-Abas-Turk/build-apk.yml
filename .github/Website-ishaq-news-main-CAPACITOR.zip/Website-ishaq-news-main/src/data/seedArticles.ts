import { Article } from '../types';

export const ishaqPortraitUrl = '/assets/images/ishaq_turk_suit_exact_1790364183317.jpg';
export const geopoliticsSummitImg = '/assets/images/hero_geopolitics_summit_1790362774883.jpg';
export const sindhHeritageImg = '/assets/images/sindh_culture_heritage_1790362792202.jpg';
export const techSemiconductorImg = '/assets/images/tech_semiconductor_ai_1790362808002.jpg';

export const SEED_ARTICLES: Article[] = [
  {
    id: 'geo-summit-2026-multipolar-alliances',
    slug: 'multipolar-diplomacy-and-the-reimagined-indian-ocean-corridors',
    title: 'The Indian Ocean Chessboard: Strategic Corridors, Gwadar, and Middle-Power Diplomacy',
    subtitle: 'As traditional maritime alliances pivot towards multipolar economic corridors, South and Central Asia find themselves at the center of maritime negotiations.',
    summary: 'A deep exploration into shifting naval doctrines, port infrastructure investments, and how regional transit hubs from the Arabian Sea to the Gulf are quietly redrawing international trade pacts.',
    content: `## The Strategic Awakening of Maritime Chokepoints

For decades, international observers viewed global trade through the prism of established post-war maritime lanes. Today, however, strategic competition in the Indian Ocean basin has transformed commercial ports into active instruments of geopolitical negotiation.

From the Strait of Hormuz to the Bab-el-Mandeb, and extending along the coastline of Balochistan and Sindh, coastal infrastructure is no longer merely logistical—it is sovereign leverage.

> "The true test of modern statecraft is not the declaration of formal treaties, but the quiet resilience of energy transit routes and undersea data conduits that link continental interiors with global waters."

### Gwadar and the Central Asian Transit Bridge

At the crux of this transformation lies the connectivity between landlocked Central Asian republics and deep-water warm ports. For economies in Uzbekistan, Kazakhstan, and Turkmenistan, reaching world markets depends on viable southern egress points.

Key diplomatic developments include:

* **Bilateral transit accords** standardizing customs clearance protocols across western borders.
* **Modernized rail corridors** linking mineral extraction hubs directly to coastal shipping container terminals.
* **Diversification of energy corridors**, reducing single-point vulnerability during geopolitical escalations.

### Middle Powers and the Art of Strategic Autonomy

Rather than aligning rigidly with any single global hegemon, regional powers across Asia and the Middle East are engaging in transactional, issue-specific diplomacy. They negotiate trade pacts with Eastern consortiums while maintaining security dialogues with Western partners.

This deliberate balancing strategy affords developing economies greater room for negotiation, ensuring that infrastructural sovereignty remains firmly in domestic hands.

### What Lies Ahead for Regional Policy

As maritime defense budgets increase and green shipping corridors become standardized international requirements, coastal states that invest in transparent logistics, renewable port power, and regional customs treaties will emerge as indispensable linchpins of the global economy.`,
    category: 'geopolitics',
    type: 'analysis',
    author: 'Ishaq Turk',
    authorRole: 'Founder & Editor',
    authorAvatar: ishaqPortraitUrl,
    publishedAt: '2026-09-24T08:30:00Z',
    readTime: '6 min read',
    imageUrl: geopoliticsSummitImg,
    imageCaption: 'Delegates convene during international maritime diplomacy roundtables in the region.',
    sources: [
      { name: 'Maritime Geostrategy Institute Report 2026', url: 'https://example.com/reports/maritime-2026' },
      { name: 'Regional Port Infrastructure Review', url: 'https://example.com/ports-data' }
    ],
    tags: ['Geopolitics', 'Indian Ocean', 'Gwadar', 'Diplomacy', 'Maritime Trade'],
    status: 'published',
    isFeatured: true,
    isTrending: true,
    trendingRank: 1,
    isSample: true
  },
  {
    id: 'sindh-matiari-agriculture-water',
    slug: 'rethinking-water-management-and-sustainable-agriculture-in-rural-sindh',
    title: 'From Matiari to the Indus Delta: Innovating Agricultural Resilience Across Rural Sindh',
    subtitle: 'How generational farming communities in Sindh are blending time-tested water-conservation wisdom with modern laser-leveling and solar irrigation.',
    summary: 'A look at local community-driven agricultural reforms across Matiari, Hyderabad, and rural districts, proving that grassroots conservation can revitalize the provincial agrarian economy.',
    content: `## A Generational Bond With the Indus Waters

In the agricultural belt stretching through Matiari, Masu Bhurgari, and the fertile plains surrounding Hyderabad, the lifeblood of every household has always been the River Indus. Yet erratic rainfall cycles and canal seepage have demanded bold, pragmatic transformations in how water is preserved.

Local growers are no longer waiting for distant administrative answers; instead, a quiet revolution of micro-irrigation and communal water accounting is taking root.

### The Rise of Precision Land Leveling

One of the most effective interventions has been the widespread adoption of laser-guided land leveling. By ensuring fields are flat within millimeter tolerances, farmers report:

1. **A 25% to 30% reduction in water application volumes** per acre.
2. **More uniform seed germination**, avoiding waterlogged root pockets.
3. **Reduced expenditure on diesel fuel** for irrigation tube-wells.

> "When water flows evenly across every furrow, the soil breathes. We are harvesting not just cotton and wheat, but our children's future security."

### Solar-Powered Micro Drip Adoption

In addition to leveling, localized solar-pump systems combined with low-pressure drip pipes are enabling vegetable and banana growers to cultivate higher-yield cash crops on previously underutilized soil.

Younger agriculturists are utilizing mobile weather alerts and soil moisture sensors to time irrigation cycles precisely during cooler evening hours, drastically cutting evaporation losses.

### The Road to Provincial Food Security

Sindh's agrarian future relies on empowering district farmers with low-cost technology, transparent canal distribution records, and direct farm-to-market logistics that bypass predatory middle-tier markups. The models tested in Matiari offer a blueprint for the entire Indus basin.`,
    category: 'sindh',
    type: 'news',
    author: 'Ishaq Turk',
    authorRole: 'Founder & Editor',
    authorAvatar: ishaqPortraitUrl,
    publishedAt: '2026-09-23T14:15:00Z',
    readTime: '5 min read',
    imageUrl: sindhHeritageImg,
    imageCaption: 'The historic plains and canal networks of rural Sindh during early twilight.',
    sources: [
      { name: 'Sindh Agrarian Water Census', url: 'https://example.com/sindh-water' },
      { name: 'Matiari Farmers Collective Field Data', url: 'https://example.com/matiari-farming' }
    ],
    tags: ['Sindh', 'Matiari', 'Agriculture', 'Water Conservation', 'Indus River'],
    status: 'published',
    isFeatured: false,
    isTrending: true,
    trendingRank: 2,
    isSample: true
  },
  {
    id: 'tech-semiconductor-ai-sovereignty',
    slug: 'silicon-sovereignty-and-open-weight-ai-for-emerging-nations',
    title: 'Silicon Sovereignty: Why Emerging Economies Are Investing in Open Hardware and Local AI Models',
    subtitle: 'The race for sovereign computational infrastructure is moving beyond closed mega-labs into distributed regional data centers.',
    summary: 'An investigative analysis of how open-weight AI architectures and fabless silicon initiatives give developing countries independence from global tech monopolies.',
    content: `## Beyond the Black-Box Monopoly

In the initial wave of artificial intelligence adoption, most governments and enterprises were passive consumers of hosted proprietary APIs. That era is rapidly closing.

Today, data sovereignty laws and foreign currency preservation have made locally hosted, open-weight models an urgent national security priority for emerging nations.

### Why On-Premise and Open Weights Matter

Relying exclusively on overseas cloud compute exposes a nation's judicial, educational, and defense data to foreign jurisdiction and unexpected API service terminations. 

* **Linguistic Independence**: Off-the-shelf Western models often fail on regional languages like Sindhi, Urdu, and Pashto. Fine-tuning compact 7B and 14B parameter models with localized corpora produces far superior domain accuracy.
* **Cost Predictability**: Local servers eliminate fluctuating dollar-denominated API bills, creating stable operational costs for provincial hospitals, tax offices, and universities.
* **Latency & Offline Resilience**: In rural health centers where high-speed broadband can be intermittent, lightweight edge models can diagnose medical scans without internet connectivity.

> "A country that does not control its foundational data and computational models will soon discover that its strategic decisions are constrained by another nation's software updates."

### The Rise of Fabless Silicon Consortia

While manufacturing 2nm wafers remains concentrated in Taiwan and South Korea, mature 28nm and 65nm microcontrollers—sufficient for smart electrical grids, drone navigation, and industrial IoT—are now accessible to regional design houses using open RISC-V standards.

By pairing sovereign hardware design with open-source neural software, emerging digital hubs are securing their place in the 21st-century technological economy.`,
    category: 'technology',
    type: 'analysis',
    author: 'Ishaq Turk',
    authorRole: 'Founder & Editor',
    authorAvatar: ishaqPortraitUrl,
    publishedAt: '2026-09-22T11:00:00Z',
    readTime: '7 min read',
    imageUrl: techSemiconductorImg,
    imageCaption: 'Optical interconnects and silicon wafer architecture inside high-performance compute labs.',
    sources: [
      { name: 'Open Architecture Semiconductor Alliance', url: 'https://example.com/risc-v-report' },
      { name: 'Global Data Sovereignty Monitor', url: 'https://example.com/data-sovereignty' }
    ],
    tags: ['Technology', 'AI', 'Semiconductors', 'Data Sovereignty', 'Open Source'],
    status: 'published',
    isFeatured: false,
    isTrending: true,
    trendingRank: 3,
    isSample: true
  },
  {
    id: 'opinion-rural-lens-on-world-affairs',
    slug: 'why-masu-bhurgari-quiet-roads-gave-me-a-global-lens-on-geopolitics',
    title: 'View From Masu Bhurgari: Why Quiet Rural Roads Offer the Clearest Perspective on Global Affairs',
    subtitle: 'When you observe geopolitics from outside the media echo chambers, power dynamics become stark, authentic, and human.',
    summary: 'A personal reflection on growing up in a Sindh village, reading international history by lantern light, and founding an independent platform to dissect world affairs.',
    content: `## The Distance That Sharpens Sight

I grew up in Masu Bhurgari, a small, proud village in Sindh, Pakistan. In metropolitan capitals like London, Washington, or Islamabad, politics is often discussed in soundbites, press releases, and televised screaming matches.

In a village, however, politics is not abstract theory; it is tangible reality.

When fertilizer prices spike because of a conflict thousands of miles away in Eastern Europe, or when diesel costs surge due to negotiations in the Persian Gulf, the impact is felt directly in the fields and households of ordinary families.

> "The true measure of any international treaty is not the applause in diplomatic banquet rooms, but whether the farmer in Sindh or the artisan in Cairo can afford seed and power next season."

### Rejecting Corporate News Fatigue

I created **News By Ishaq** because I grew frustrated by two extremes:

1. **Corporate Western media**, which frequently treats developing nations as tragic backdrops or peripheral statistics rather than active, thinking civilizations.
2. **Sensationalist domestic TV channels**, which prioritize shouting matches and partisan gossip over substantive economic and geopolitical education.

We deserve a platform that speaks with clarity, dignity, and intellectual curiosity. A place that takes local Sindh issues as seriously as United Nations votes, and treats global strategic developments with the nuance they demand.

### The Commitment of News By Ishaq

Here, we will never pretend that opinion is news. When we report facts, we cite sources. When we write analytical context, we show both sides. And when I write personal commentary like this, it will always be labeled plainly as **OPINION**.

Thank you for joining me on this journey. Whether you are reading this in Hyderabad, Karachi, Lahore, or across the world—welcome to an independent voice.`,
    category: 'opinion',
    type: 'opinion',
    author: 'Ishaq Turk',
    authorRole: 'Founder & Editor',
    authorAvatar: ishaqPortraitUrl,
    publishedAt: '2026-09-21T18:00:00Z',
    readTime: '4 min read',
    imageUrl: ishaqPortraitUrl,
    imageCaption: 'Ishaq Turk, founder and editor of News By Ishaq.',
    sources: [
      { name: 'News By Ishaq Editorial Charter', url: 'https://newsbyishaq.com/#/about' }
    ],
    tags: ['Opinion', 'Ishaq Turk', 'Sindh', 'Journalism', 'Masu Bhurgari'],
    status: 'published',
    isFeatured: false,
    isTrending: true,
    trendingRank: 4,
    isSample: true
  },
  {
    id: 'pakistan-energy-grid-solar-transition',
    slug: 'pakistan-clean-energy-transition-and-grid-modernization',
    title: 'The Great Solar Shift: How Decentralized Clean Power Is Rewiring Pakistan’s National Grid',
    subtitle: 'With rooftop solar installations surging across residential and industrial sectors, national grid operators face both financial disruption and unprecedented opportunity.',
    summary: 'An in-depth investigation into Pakistan’s net-metering boom, capacity payment dilemmas, and the engineering upgrades required to balance a modern distributed power network.',
    content: `## A Solar Boom Driven by Necessity

Skyrocketing electricity tariffs over the past three years catalyzed a remarkable consumer behavior shift across Pakistan. From Karachi industrial zones to domestic rooftops in Lahore and Rawalpindi, homeowners and factory operators embraced solar photovoltaics at record velocity.

What began as an emergency measure to bypass volatile fuel surcharges has evolved into an irreversible structural revolution in national energy generation.

### The Balancing Act for Distribution Companies

While decentralized solar reduces daytime peak strain and saves foreign exchange on imported furnace oil and liquefied natural gas (LNG), it poses unique operational questions for transmission grids:

* **Base-Load Minimums**: Thermal power stations bound by take-or-pay capacity payment contracts cannot simply be powered down when solar peaks at noon.
* **Grid Stability & Inverters**: Integrating hundreds of thousands of asynchronous rooftop inverters requires automated substations to prevent frequency oscillations.
* **Equitable Wheeling Charges**: Ensuring that low-income households without rooftop capital do not disproportionately shoulder the fixed costs of maintaining national transmission cables.

> "Decentralized solar has democratized energy generation. The challenge now is transforming our transmission wires from a one-way highway into a dynamic, two-way smart grid."

### The Next Frontier: Battery Energy Storage Systems (BESS)

Energy experts agree that the missing catalyst is grid-scale battery storage. By co-locating utility batteries near high-voltage transformer stations, surplus midday solar power can be stored and discharged during the evening peak (7:00 PM to 10:00 PM), eliminating the need for expensive peaker gas turbines.

With smart tariffs and regional battery assembly partnerships underway, Pakistan has the opportunity to pioneer a decentralized energy model for South Asia.`,
    category: 'pakistan',
    type: 'news',
    author: 'Ishaq Turk',
    authorRole: 'Founder & Editor',
    authorAvatar: ishaqPortraitUrl,
    publishedAt: '2026-09-20T10:45:00Z',
    readTime: '6 min read',
    imageUrl: techSemiconductorImg,
    imageCaption: 'Modern electrical infrastructure and smart grid monitoring consoles.',
    sources: [
      { name: 'National Electric Power Regulatory Authority (NEPRA) Annual Data', url: 'https://example.com/nepra-data' },
      { name: 'Renewable Energy Institute South Asia', url: 'https://example.com/re-south-asia' }
    ],
    tags: ['Pakistan', 'Energy', 'Solar Power', 'Economy', 'Infrastructure'],
    status: 'published',
    isFeatured: false,
    isTrending: true,
    trendingRank: 5,
    isSample: true
  },
  {
    id: 'world-multilateral-reforms-un-security-council',
    slug: 'the-battle-to-reform-the-united-nations-security-council-in-2026',
    title: 'The Permanent Seat Deadlock: Why the Global South Demands Concrete UN Security Council Reform',
    subtitle: 'With international conflicts exposing the paralysis of the veto power, an emerging coalition of nations is pushing for structural veto abolitions.',
    summary: 'Examining the renewed momentum behind United Nations reform and why representation for Africa, Latin America, and South Asia can no longer be deferred.',
    content: `## An Institution Built for 1945, Straining in 2026

The United Nations Security Council remains anchored to the geopolitical realities of the immediate post-World War II landscape. Five permanent members possess the unilateral power to halt resolutions, regardless of overwhelming consensus in the General Assembly.

As crises in the Middle East, Eastern Europe, and the Indo-Pacific expose the structural limits of this veto privilege, calls for comprehensive restructuring have reached a historic tipping point.

### The Demands of the Global South

Coalitions across Africa, Latin America, and South Asia have unified around three fundamental demands:

1. **Abolition or Strict Restriction of the Veto**: Preventing permanent members from vetoing actions addressing confirmed humanitarian catastrophes and war crimes.
2. **Permanent Representation for Africa and Latin America**: Continents encompassing over two billion citizens currently lack a single permanent voting seat.
3. **Transparent Voting Mechanisms**: Mandating that whenever a veto is exercised, the member state must justify its decision before a mandatory plenary session of the General Assembly.

> "Peace is not sustained by silencing the voices of the majority; it is forged by ensuring that justice is blind to imperial heritage."

### Resistance and Realpolitik

While broad consensus exists that the current structure is antiquated, the amendment process itself is subject to the very veto power it seeks to reform. 

Nevertheless, emerging regional dialogues—such as the BRICS+ summits and non-aligned multilateral forums—are creating alternative diplomatic frameworks that increasingly challenge the Security Council's exclusive monopoly on global crisis resolution.`,
    category: 'world',
    type: 'analysis',
    author: 'Ishaq Turk',
    authorRole: 'Founder & Editor',
    authorAvatar: ishaqPortraitUrl,
    publishedAt: '2026-09-19T09:00:00Z',
    readTime: '5 min read',
    imageUrl: geopoliticsSummitImg,
    imageCaption: 'The United Nations General Assembly and diplomatic deliberations in session.',
    sources: [
      { name: 'UN General Assembly Archives & Procedural Rules', url: 'https://example.com/un-records' },
      { name: 'Global Governance Reform Initiative', url: 'https://example.com/governance-reform' }
    ],
    tags: ['World', 'United Nations', 'Diplomacy', 'Global South', 'International Law'],
    status: 'published',
    isFeatured: false,
    isTrending: false,
    isSample: true
  },
  {
    id: 'sindh-hyderabad-tech-corridor',
    slug: 'hyderabad-sindh-nascent-software-and-freelancing-ecosystem',
    title: 'Hyderabad’s Tech Horizon: How Co-Working Spaces and Fiber Networks Are Powering Sindh’s Youth',
    subtitle: 'Young engineers and remote specialists in Hyderabad and Latifabad are building high-value software for international clients while staying close to home.',
    summary: 'A ground report on the expanding digital economy across urban Sindh, where high-speed broadband and collaborative hubs are turning university graduates into global tech contributors.',
    content: `## A Quiet Transformation in Sindh’s Second City

For decades, young graduates from the universities in Jamshoro and Hyderabad faced a difficult choice: relocate to the congested suburbs of Karachi or abandon technical careers altogether.

Today, high-speed fiber internet and community-run co-working hubs across Qasimabad, Latifabad, and Autobahn Road have disrupted that old narrative.

### The Rise of Distributed Teams

Over twelve thousand active freelancers and remote engineers now work from Hyderabad, servicing clients across North America, Europe, and the Gulf. Their expertise spans:

* Full-stack web and mobile application engineering
* Cloud architecture and DevOps automation
* Data annotation and regional language processing
* Digital media and UI/UX design

> "We have world-class computer science talent coming out of Mehran and Sindh University every single year. When you give them uninterrupted power, fast fiber, and a collaborative workspace, geographic borders vanish."

### The Multiplier Effect on Local Commerce

The influx of foreign exchange earnings into Hyderabad’s local economy is visible in new bookshops, specialized coffee roasters, and hardware repair cooperatives. Furthermore, experienced tech veterans are mentoring high school students in free evening coding circles, fostering a self-sustaining cycle of digital literacy.

With municipal plans to designate an official digital innovation district, Hyderabad is signaling that technological excellence in Sindh is no longer confined to the megacity.`,
    category: 'sindh',
    type: 'news',
    author: 'Ishaq Turk',
    authorRole: 'Founder & Editor',
    authorAvatar: ishaqPortraitUrl,
    publishedAt: '2026-09-18T16:20:00Z',
    readTime: '4 min read',
    imageUrl: sindhHeritageImg,
    imageCaption: 'Young engineers collaborating in modern work hubs in Hyderabad, Sindh.',
    sources: [
      { name: 'Sindh IT Board Employment Metrics', url: 'https://example.com/sindh-it' }
    ],
    tags: ['Sindh', 'Hyderabad', 'Technology', 'Youth', 'Economy'],
    status: 'published',
    isFeatured: false,
    isTrending: false,
    isSample: true
  }
];
