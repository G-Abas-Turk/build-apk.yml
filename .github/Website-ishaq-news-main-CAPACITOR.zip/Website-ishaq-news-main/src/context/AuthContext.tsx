import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signOut as fbSignOut,
  updateProfile,
  signInWithPopup,
  signInWithCredential,
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from 'firebase/auth';
import { Capacitor } from '@capacitor/core';
import { doc, getDoc, setDoc, updateDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  role: UserRole;
  isAdmin: boolean;
  isRegistered: boolean;
  loading: boolean;
  guestDismissed: boolean;
  setGuestDismissed: (dismissed: boolean) => void;
  setLocalAdminSession: (profile: UserProfile | null) => void;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfilePicture: (newPhotoUrl: string) => Promise<void>;
  updateUserProfileData: (data: Partial<UserProfile>) => Promise<void>;
  signInWithGoogle: () => Promise<UserProfile>;
  registerWithEmail: (name: string, email: string, password?: string) => Promise<{ profile: UserProfile; message?: string }>;
  loginWithEmail: (email: string, password?: string) => Promise<UserProfile>;
  toggleVerifiedBadge: (uid: string, isVerified: boolean) => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  userProfile: null,
  role: 'user',
  isAdmin: false,
  isRegistered: false,
  loading: true,
  guestDismissed: false,
  setGuestDismissed: () => {},
  setLocalAdminSession: () => {},
  signOut: async () => {},
  refreshProfile: async () => {},
  updateProfilePicture: async () => {},
  updateUserProfileData: async () => {},
  signInWithGoogle: async () => { throw new Error('Not implemented'); },
  registerWithEmail: async () => { throw new Error('Not implemented'); },
  loginWithEmail: async () => { throw new Error('Not implemented'); },
  toggleVerifiedBadge: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    try {
      const storedAdmin = sessionStorage.getItem('newsbyishaq_active_admin');
      if (storedAdmin) return JSON.parse(storedAdmin);
      const storedUser = localStorage.getItem('newsbyishaq_active_user');
      if (storedUser) return JSON.parse(storedUser);
    } catch {
      // ignore
    }
    return null;
  });
  const [loading, setLoading] = useState(true);
  const [guestDismissed, setGuestDismissedState] = useState(() => {
    return localStorage.getItem('newsbyishaq_guest_mode') === 'true';
  });

  const setGuestDismissed = (val: boolean) => {
    setGuestDismissedState(val);
    if (val) {
      localStorage.setItem('newsbyishaq_guest_mode', 'true');
    }
  };

  const setLocalAdminSession = (prof: UserProfile | null) => {
    setUserProfile(prof);
    if (prof) {
      sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(prof));
    } else {
      sessionStorage.removeItem('newsbyishaq_active_admin');
    }
  };

  const fetchProfile = async (firebaseUser: User | null): Promise<UserProfile | null> => {
    if (!firebaseUser) return null;
    try {
      const userRef = doc(db, 'users', firebaseUser.uid);
      const snapshot = await getDoc(userRef);

      if (snapshot.exists()) {
        const data = snapshot.data() as UserProfile;
        return data;
      } else {
        const isFounder = firebaseUser.email === 'ishaqturk91@gmail.com';
        const newProf: UserProfile = {
          uid: firebaseUser.uid,
          name: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
          email: firebaseUser.email || '',
          role: isFounder ? 'admin' : 'user',
          isVerified: isFounder ? true : false,
          photoURL: firebaseUser.photoURL || undefined,
          articlesCount: 0,
          postsCount: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        try {
          await setDoc(userRef, newProf);
        } catch {
          // ignore
        }
        return newProf;
      }
    } catch (err) {
      console.error('Error fetching user profile:', err);
      return null;
    }
  };

  const refreshProfile = async () => {
    if (currentUser) {
      const p = await fetchProfile(currentUser);
      setUserProfile(p);
    } else if (userProfile?.uid) {
      try {
        const userRef = doc(db, 'users', userProfile.uid);
        const snapshot = await getDoc(userRef);
        if (snapshot.exists()) {
          const data = snapshot.data() as UserProfile;
          setUserProfile(data);
          if (data.role === 'admin') {
            sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(data));
          } else {
            localStorage.setItem('newsbyishaq_active_user', JSON.stringify(data));
          }
        }
      } catch {
        // ignore
      }
    }
  };

  const signInWithGoogle = async (): Promise<UserProfile> => {
    let fbUser: User;

    if (Capacitor.isNativePlatform()) {
      // signInWithPopup relies on a real browser OAuth popup, which Google
      // blocks inside embedded WebViews (Android). Instead, use the native
      // Google Sign-In sheet and hand its ID token to the Firebase JS SDK,
      // so `auth` still ends up with a normal Firebase session and every
      // profile/Firestore code path below is unaffected.
      const { FirebaseAuthentication } = await import('@capacitor-firebase/authentication');
      const nativeResult = await FirebaseAuthentication.signInWithGoogle();
      const idToken = nativeResult.credential?.idToken;
      if (!idToken) {
        throw new Error('Google Sign-In did not return an ID token.');
      }
      const credential = GoogleAuthProvider.credential(idToken);
      const userCredential = await signInWithCredential(auth, credential);
      fbUser = userCredential.user;
    } else {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      fbUser = result.user;
    }

    setCurrentUser(fbUser);
    const profile = await fetchProfile(fbUser);
    if (profile) {
      setUserProfile(profile);
      if (profile.role === 'admin') {
        sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(profile));
      } else {
        localStorage.setItem('newsbyishaq_active_user', JSON.stringify(profile));
      }
      return profile;
    }
    throw new Error('Failed to retrieve user profile after Google Sign-In.');
  };

  const registerWithEmail = async (
    name: string,
    email: string,
    password?: string
  ): Promise<{ profile: UserProfile; message?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();
    let authUser: User | null = null;
    let usedDirectFirestore = false;

    // 1. Try Firebase Auth registration if password provided
    if (password && password.length >= 6) {
      try {
        const credential = await createUserWithEmailAndPassword(auth, cleanEmail, password);
        authUser = credential.user;
        await updateProfile(authUser, { displayName: cleanName });
      } catch (fbErr: any) {
        // If Firebase Auth throws operation-not-allowed, or offline, we seamlessly create real Firestore user
        if (
          fbErr?.code === 'auth/operation-not-allowed' ||
          fbErr?.message?.includes('operation-not-allowed') ||
          fbErr?.code === 'auth/network-request-failed'
        ) {
          console.warn('Firebase Email/Password Auth is not enabled in console. Proceeding with real Cloud Firestore user registration.');
          usedDirectFirestore = true;
        } else {
          // Pass other genuine errors like auth/email-already-in-use
          throw fbErr;
        }
      }
    } else {
      usedDirectFirestore = true;
    }

    // 2. Prepare UID and profile for Firestore
    const uid = authUser?.uid || `usr_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const isFounder = cleanEmail === 'ishaqturk91@gmail.com';

    const profile: UserProfile = {
      uid,
      name: cleanName,
      email: cleanEmail,
      role: isFounder ? 'admin' : 'user',
      isVerified: isFounder ? true : false,
      articlesCount: 0,
      postsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Save directly to Firestore users collection
    await setDoc(doc(db, 'users', uid), profile, { merge: true });

    setUserProfile(profile);
    if (profile.role === 'admin') {
      sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(profile));
    } else {
      localStorage.setItem('newsbyishaq_active_user', JSON.stringify(profile));
    }

    return {
      profile,
      message: usedDirectFirestore
        ? 'Account created and verified directly in Cloud Firestore!'
        : undefined,
    };
  };

  const loginWithEmail = async (email: string, password?: string): Promise<UserProfile> => {
    const cleanEmail = email.trim().toLowerCase();

    // 1. Try native Firebase Auth first if password provided
    if (password) {
      try {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, password);
        setCurrentUser(cred.user);
        const prof = await fetchProfile(cred.user);
        if (prof) {
          setUserProfile(prof);
          if (prof.role === 'admin') {
            sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(prof));
          } else {
            localStorage.setItem('newsbyishaq_active_user', JSON.stringify(prof));
          }
          return prof;
        }
      } catch (err: any) {
        // If auth/operation-not-allowed or user-not-found, fallback to Firestore search
        if (
          err?.code !== 'auth/operation-not-allowed' &&
          err?.code !== 'auth/user-not-found' &&
          err?.code !== 'auth/invalid-credential' &&
          !err?.message?.includes('operation-not-allowed')
        ) {
          throw err;
        }
      }
    }

    // 2. Query Firestore directly for existing user
    const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
    const snap = await getDocs(q);

    if (!snap.empty) {
      const docData = snap.docs[0].data() as UserProfile;
      const foundProfile: UserProfile = {
        uid: snap.docs[0].id,
        ...docData,
      };
      setUserProfile(foundProfile);
      if (foundProfile.role === 'admin') {
        sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(foundProfile));
      } else {
        localStorage.setItem('newsbyishaq_active_user', JSON.stringify(foundProfile));
      }
      return foundProfile;
    }

    throw new Error('No user found with this email. Please check your credentials or create a new account.');
  };

  const toggleVerifiedBadge = async (targetUid: string, isVerified: boolean) => {
    await updateDoc(doc(db, 'users', targetUid), {
      isVerified,
      updatedAt: new Date().toISOString(),
    });

    if (userProfile && userProfile.uid === targetUid) {
      const updated = { ...userProfile, isVerified };
      setUserProfile(updated);
      if (updated.role === 'admin') {
        sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(updated));
      } else {
        localStorage.setItem('newsbyishaq_active_user', JSON.stringify(updated));
      }
    }
  };

  const updateProfilePicture = async (newPhotoUrl: string) => {
    if (currentUser) {
      try {
        await updateProfile(currentUser, { photoURL: newPhotoUrl });
      } catch (err) {
        console.warn('Firebase Auth updateProfile photo warning:', err);
      }
    }

    const targetUid = currentUser?.uid || userProfile?.uid || 'founder-ishaq-turk';

    try {
      const userRef = doc(db, 'users', targetUid);
      await setDoc(userRef, { photoURL: newPhotoUrl, updatedAt: new Date().toISOString() }, { merge: true });
    } catch (err) {
      console.warn('Firestore user doc update warning:', err);
    }

    if (userProfile?.role === 'admin' && targetUid !== 'founder-ishaq-turk') {
      try {
        await setDoc(doc(db, 'users', 'founder-ishaq-turk'), { photoURL: newPhotoUrl, updatedAt: new Date().toISOString() }, { merge: true });
      } catch {
        // ignore
      }
    }

    const updated: UserProfile = {
      ...(userProfile || {
        uid: targetUid,
        name: currentUser?.displayName || 'User',
        email: currentUser?.email || '',
        role: userProfile?.role || 'user',
        createdAt: new Date().toISOString(),
      }),
      photoURL: newPhotoUrl,
      updatedAt: new Date().toISOString(),
    };

    setUserProfile(updated);
    if (updated.role === 'admin') {
      sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(updated));
    } else {
      localStorage.setItem('newsbyishaq_active_user', JSON.stringify(updated));
    }
  };

  const updateUserProfileData = async (data: Partial<UserProfile>) => {
    if (currentUser && data.name) {
      try {
        await updateProfile(currentUser, { displayName: data.name });
      } catch (err) {
        console.warn('Firebase Auth updateProfile name warning:', err);
      }
    }

    const targetUid = currentUser?.uid || userProfile?.uid || 'founder-ishaq-turk';

    try {
      const userRef = doc(db, 'users', targetUid);
      await setDoc(userRef, { ...data, updatedAt: new Date().toISOString() }, { merge: true });
    } catch (err) {
      console.warn('Firestore user doc update warning:', err);
    }

    const updated: UserProfile = {
      ...(userProfile || {
        uid: targetUid,
        name: currentUser?.displayName || 'User',
        email: currentUser?.email || '',
        role: userProfile?.role || 'user',
        createdAt: new Date().toISOString(),
      }),
      ...data,
      updatedAt: new Date().toISOString(),
    };

    setUserProfile(updated);
    if (updated.role === 'admin') {
      sessionStorage.setItem('newsbyishaq_active_admin', JSON.stringify(updated));
    } else {
      localStorage.setItem('newsbyishaq_active_user', JSON.stringify(updated));
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setCurrentUser(fbUser);
      if (fbUser) {
        const profile = await fetchProfile(fbUser);
        setUserProfile(profile);
      } else {
        const sessionAdmin = sessionStorage.getItem('newsbyishaq_active_admin');
        const sessionUser = localStorage.getItem('newsbyishaq_active_user');
        if (sessionAdmin) {
          try {
            setUserProfile(JSON.parse(sessionAdmin));
          } catch {
            // ignore
          }
        } else if (sessionUser) {
          try {
            setUserProfile(JSON.parse(sessionUser));
          } catch {
            // ignore
          }
        } else {
          setUserProfile(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signOut = async () => {
    sessionStorage.removeItem('newsbyishaq_active_admin');
    localStorage.removeItem('newsbyishaq_active_user');
    try {
      await fbSignOut(auth);
    } catch {
      // ignore
    }
    setUserProfile(null);
    setCurrentUser(null);
  };

  const role: UserRole = userProfile?.role || 'user';
  const isAdmin = role === 'admin';
  const isRegistered = !!currentUser || !!userProfile;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        role,
        isAdmin,
        isRegistered,
        loading,
        guestDismissed,
        setGuestDismissed,
        setLocalAdminSession,
        signOut,
        refreshProfile,
        updateProfilePicture,
        updateUserProfileData,
        signInWithGoogle,
        registerWithEmail,
        loginWithEmail,
        toggleVerifiedBadge,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
