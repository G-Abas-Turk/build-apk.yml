export type Category = 'sindh' | 'pakistan' | 'world' | 'geopolitics' | 'technology' | 'opinion' | string;

export type CategorySlug = Category;

export type ArticleType = 'news' | 'analysis' | 'opinion';

export type ArticleStatus = 'published' | 'pending' | 'draft' | 'rejected';

export type UserRole = 'user' | 'admin';

export interface ArticleSource {
  name: string;
  url: string;
}

export type AppLanguage = 'en' | 'sd' | 'ur';

export interface FeedComment {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  isVerified?: boolean;
  content: string;
  createdAt: string;
}

export interface FeedPost {
  id: string;
  content: string;
  category: Category;
  postType: 'news' | 'incident' | 'breaking' | 'photo' | 'opinion';
  language: AppLanguage;
  location?: string;
  imageUrl?: string;
  authorId: string;
  authorName: string;
  authorEmail?: string;
  authorAvatar?: string;
  authorRole?: string;
  isVerified?: boolean;
  likesCount: number;
  likedBy?: string[];
  commentsCount: number;
  comments?: FeedComment[];
  sharesCount: number;
  createdAt: string;
  updatedAt?: string;
}

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  photoURL?: string;
  bio?: string;
  isVerified?: boolean;
  articlesCount?: number;
  postsCount?: number;
  createdAt: string;
  updatedAt?: string;
}

export interface CategoryItem {
  id: string;
  slug: string;
  name: string;
  description?: string;
  order?: number;
  articleCount?: number;
  createdAt?: string;
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  subtitle?: string;
  summary: string;
  content: string;
  category: Category;
  type: ArticleType;
  authorId?: string;
  authorName?: string;
  author?: string;
  authorEmail?: string;
  authorRole: string;
  authorAvatar?: string;
  publishedAt?: string;
  createdAt?: string;
  updatedAt?: string;
  readTime: string;
  imageUrl: string;
  imageCaption?: string;
  sources?: ArticleSource[];
  tags: string[];
  status: ArticleStatus;
  isFeatured?: boolean;
  isTrending?: boolean;
  trendingRank?: number;
  views?: number;
  rejectionReason?: string;
  isSample?: boolean;
}

export interface SiteSettings {
  siteName: string;
  siteDescription: string;
  announcement?: string;
  announcementActive?: boolean;
  heroNotice?: string;
  contactEmail: string;
  updatedAt?: string;
}

export type ViewRoute = 
  | { type: 'home' }
  | { type: 'feed' }
  | { type: 'category'; category: string }
  | { type: 'article'; slug: string }
  | { type: 'about' }
  | { type: 'contact' }
  | { type: 'login' }
  | { type: 'register' }
  | { type: 'admin-login' }
  | { type: 'submit-article' }
  | { type: 'my-submissions' }
  | { type: 'admin'; subSection?: 'dashboard' | 'articles' | 'pending' | 'published' | 'drafts' | 'rejected' | 'users' | 'categories' | 'media' | 'settings' | 'announcements' }
  | { type: 'privacy' }
  | { type: 'terms' };
